# PF-04 DNS Walkthrough — Muhammad Sufiyan

## What DNS does

DNS (Domain Name System) translates a human-readable website address into the network address needed to reach the hosting service. Instead of remembering an IP address, a visitor can type a domain such as `example.com`.

## What happens when someone opens a website

1. The visitor enters a website address in a browser.
2. The browser/operating system checks whether it already knows the DNS answer from a cache.
3. If it needs an answer, a DNS resolver looks up the domain.
4. The resolver communicates with the domain's authoritative nameserver, which holds the DNS records for that domain.
5. The nameserver returns the relevant record, such as an A record containing an IP address or a CNAME pointing one hostname to another hostname.
6. The resolver returns the answer to the visitor's device and may cache it for the record's TTL.
7. The browser then connects to the hosting service. With HTTPS, the server also completes TLS/SSL negotiation so the connection is encrypted.
8. The hosting platform returns the website files, and the browser renders the page.

## What is a CNAME?

A CNAME (Canonical Name) record creates an alias from one hostname to another hostname. For example, `www.example.com` can point to a hosting provider's hostname. The DNS system follows that alias to find where the website should be served.

A CNAME is normally used for a hostname such as `www`. The root/apex domain is handled differently by many DNS providers and may use an A/AAAA record or the provider's equivalent of an alias record.

## Netlify in this assignment

For PF-04, the site can first use Netlify's free HTTPS URL, so no custom domain or DNS configuration is required. If I connect a custom domain later, I would add the DNS records recommended by the hosting provider, wait for DNS propagation, and then verify HTTPS.

The important point is that DNS does not contain the website itself. DNS tells the browser where the website should be reached; the hosting platform actually serves the website files.
