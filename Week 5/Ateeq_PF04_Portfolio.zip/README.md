# PF-04 — Muhammad Sufiyan Personal Website

## Files
- `index.html` — page structure and content.
- `style.css` — responsive visual design.
- `DNS_WALKTHROUGH.md` — PF-04 DNS deliverable.
- `CV.pdf` — optional placeholder; replace with your real CV before deploying.

## Deploy on Netlify
1. Open Netlify Drop.
2. Drag the entire project folder onto the page.
3. Wait for deployment.
4. Open the generated HTTPS URL.
5. In Netlify, rename the site under Site configuration → Change site name.
6. Test the public URL in a private/incognito window.
7. Add the final URL to LinkedIn and your CV.

## Before submission
Replace the CV placeholder with your actual CV if you have one.
Add a booking link when you have one. The current site clearly marks these as pending rather than inventing links.
