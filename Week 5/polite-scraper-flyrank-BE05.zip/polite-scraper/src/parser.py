from bs4 import BeautifulSoup
from urllib.parse import urljoin
from src.utils import clean_text

def parse_catalogue_page(html: str, page_url: str):
    soup = BeautifulSoup(html, "html.parser")
    product_urls = []
    for article in soup.select("article.product_pod h3 a"):
        href = article.get("href")
        if href:
            product_urls.append(urljoin(page_url, href))

    next_link = soup.select_one("li.next a")
    next_url = urljoin(page_url, next_link["href"]) if next_link and next_link.get("href") else None
    return product_urls, next_url

def parse_book_page(html: str, product_url: str, source_page: str, fetched_at: str):
    soup = BeautifulSoup(html, "html.parser")
    product_main = soup.select_one("div.product_main")
    if product_main is None:
        raise ValueError("Product section not found")

    title_el = product_main.select_one("h1")
    price_el = product_main.select_one("p.price_color")
    availability_el = product_main.select_one("p.availability")
    rating_el = product_main.select_one("p.star-rating")

    if not all([title_el, price_el, availability_el, rating_el]):
        raise ValueError("One or more required product fields are missing")

    rating_words = {"One", "Two", "Three", "Four", "Five"}
    rating_text = next((c for c in rating_el.get("class", []) if c in rating_words), None)
    if rating_text is None:
        raise ValueError("Rating value not found")

    description = None
    description_heading = soup.select_one("#product_description")
    if description_heading:
        description_el = description_heading.find_next("p")
        if description_el:
            description = clean_text(description_el.get_text())

    return {
        "title": clean_text(title_el.get_text()),
        "product_url": product_url,
        "price_text": clean_text(price_el.get_text()),
        "availability_text": clean_text(availability_el.get_text()),
        "rating_text": rating_text,
        "description": description,
        "source_page": source_page,
        "fetched_at": fetched_at,
    }
