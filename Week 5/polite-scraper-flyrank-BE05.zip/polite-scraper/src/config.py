from pathlib import Path

BASE_DIR = Path(__file__).resolve().parent.parent
CACHE_DIR = BASE_DIR / "cache"
OUTPUT_DIR = BASE_DIR / "output"

BASE_URL = "https://books.toscrape.com/"
START_URL = BASE_URL
CATALOGUE_PAGE_LIMIT = 3
REQUEST_DELAY_SECONDS = 0.5
REQUEST_TIMEOUT_SECONDS = 10

USER_AGENT = (
    "FlyRankInternship-A9/1.0 "
    "(+https://github.com/YOUR_USERNAME/polite-scraper)"
)

BOOKS_FILE = OUTPUT_DIR / "books.json"
ERRORS_FILE = OUTPUT_DIR / "errors.json"
REPORT_FILE = OUTPUT_DIR / "run-report.json"

def ensure_directories():
    CACHE_DIR.mkdir(parents=True, exist_ok=True)
    OUTPUT_DIR.mkdir(parents=True, exist_ok=True)
