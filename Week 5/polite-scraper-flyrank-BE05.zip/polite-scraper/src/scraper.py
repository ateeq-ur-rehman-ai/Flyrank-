import hashlib
import time
from pathlib import Path
import requests
from pydantic import ValidationError

from src.config import CACHE_DIR, REQUEST_DELAY_SECONDS, REQUEST_TIMEOUT_SECONDS, USER_AGENT
from src.models import BookRecord
from src.parser import parse_book_page, parse_catalogue_page
from src.utils import normalize_price, utc_now_iso

class PoliteScraper:
    def __init__(self):
        self.session = requests.Session()
        self.session.headers.update({"User-Agent": USER_AGENT})
        self.pages_fetched = 0
        self.cache_hits = 0
        self.failed_pages = []
        self.invalid_records = []
        self.last_real_request_time = None

    def _cache_filename(self, url: str, prefix: str) -> Path:
        digest = hashlib.md5(url.encode("utf-8")).hexdigest()
        return CACHE_DIR / f"{prefix}-{digest}.html"

    def _wait_before_request(self):
        if self.last_real_request_time is not None:
            elapsed = time.time() - self.last_real_request_time
            remaining = REQUEST_DELAY_SECONDS - elapsed
            if remaining > 0:
                time.sleep(remaining)

    def fetch(self, url: str, cache_prefix: str, allow_retry: bool = True) -> str:
        cache_file = self._cache_filename(url, cache_prefix)
        if cache_file.exists():
            self.cache_hits += 1
            print(f"CACHE HIT | {url}")
            return cache_file.read_text(encoding="utf-8")

        attempts = 2 if allow_retry else 1
        last_error = None

        for attempt in range(1, attempts + 1):
            try:
                self._wait_before_request()
                print(f"FETCH | attempt={attempt} | {url}")
                response = self.session.get(url, timeout=REQUEST_TIMEOUT_SECONDS)
                self.last_real_request_time = time.time()
                self.pages_fetched += 1

                if response.status_code == 200:
                    cache_file.write_text(response.text, encoding="utf-8")
                    return response.text

                if response.status_code in (403, 404):
                    raise requests.HTTPError(f"HTTP {response.status_code}")

                if response.status_code >= 500 and attempt < attempts:
                    last_error = f"HTTP {response.status_code}"
                    time.sleep(1)
                    continue

                raise requests.HTTPError(f"HTTP {response.status_code}")

            except (requests.Timeout, requests.ConnectionError, requests.HTTPError) as error:
                last_error = str(error)
                if attempt < attempts:
                    time.sleep(1)
                    continue

        raise RuntimeError(f"Failed to fetch {url}: {last_error}")

    def discover_books(self, start_url: str, page_limit: int):
        current_url = start_url
        catalogue_pages = []
        discovered = []
        page_number = 1

        while current_url and page_number <= page_limit:
            html = self.fetch(current_url, f"catalogue-page-{page_number}")
            urls, next_url = parse_catalogue_page(html, current_url)
            catalogue_pages.append(current_url)
            discovered.extend({"product_url": url, "source_page": current_url} for url in urls)
            current_url = next_url
            page_number += 1

        unique = {item["product_url"]: item for item in discovered}
        unique_items = list(unique.values())

        print(f"catalogue_pages={len(catalogue_pages)}")
        print(f"discovered={len(discovered)}")
        print(f"unique_urls={len(unique_items)}")
        return catalogue_pages, unique_items

    def scrape_books(self, discovered_books):
        valid_records = []

        for index, item in enumerate(discovered_books, start=1):
            url = item["product_url"]
            print(f"[{index}/{len(discovered_books)}] Processing book")
            try:
                html = self.fetch(url, "book")
                raw = parse_book_page(html, url, item["source_page"], utc_now_iso())
                normalized = {**raw, "price_gbp": normalize_price(raw["price_text"])}
                record = BookRecord(**normalized)
                valid_records.append(record.model_dump(mode="json"))
            except ValidationError as error:
                self.invalid_records.append({"url": url, "error": str(error)})
                print(f"INVALID RECORD | {url}")
            except Exception as error:
                self.failed_pages.append({"url": url, "error": str(error)})
                print(f"FAILED | {url} | {error}")

        unique = {record["product_url"]: record for record in valid_records}
        return list(unique.values())

    def test_broken_page(self):
        fake_url = "https://books.toscrape.com/catalogue/this-book-does-not-exist/index.html"
        print("Testing intentionally broken URL...")
        try:
            self.fetch(fake_url, "broken-test")
        except Exception as error:
            self.failed_pages.append({"url": fake_url, "error": str(error)})
            print(f"BROKEN PAGE SKIPPED | {fake_url}")
