import sys
import time

from src.config import (
    BOOKS_FILE, CATALOGUE_PAGE_LIMIT, ERRORS_FILE,
    REPORT_FILE, START_URL, ensure_directories
)
from src.scraper import PoliteScraper
from src.utils import utc_now_iso, write_json

def main():
    ensure_directories()
    run_started_at = utc_now_iso()
    start_time = time.time()
    scraper = PoliteScraper()

    try:
        print("=" * 60)
        print("FlyRank Internship - The Polite Scraper")
        print("=" * 60)

        catalogue_pages, discovered_books = scraper.discover_books(
            START_URL, CATALOGUE_PAGE_LIMIT
        )

        valid_records = scraper.scrape_books(discovered_books)
        scraper.test_broken_page()

        books = list({r["product_url"]: r for r in valid_records}.values())
        write_json(BOOKS_FILE, books)

        errors = {
            "invalid_records": scraper.invalid_records,
            "failed_pages": scraper.failed_pages,
        }
        write_json(ERRORS_FILE, errors)

        duration_seconds = round(time.time() - start_time, 2)
        report = {
            "start_time": run_started_at,
            "duration_seconds": duration_seconds,
            "catalogue_pages": len(catalogue_pages),
            "detail_pages": len(discovered_books),
            "pages_fetched": scraper.pages_fetched,
            "cache_hits": scraper.cache_hits,
            "valid_records": len(books),
            "invalid_records": len(scraper.invalid_records),
            "failed_pages": len(scraper.failed_pages),
        }
        write_json(REPORT_FILE, report)

        print("\nRUN COMPLETE")
        print(f"Valid records: {len(books)}")
        print(f"Invalid records: {len(scraper.invalid_records)}")
        print(f"Failed pages: {len(scraper.failed_pages)}")
        print(f"Cache hits: {scraper.cache_hits}")
        print(f"Duration: {duration_seconds}s")

        if len(books) != 60:
            print("WARNING: Expected 60 records.")
            sys.exit(1)

    except Exception as error:
        duration_seconds = round(time.time() - start_time, 2)
        write_json(REPORT_FILE, {
            "start_time": run_started_at,
            "duration_seconds": duration_seconds,
            "fatal_error": str(error),
            "pages_fetched": scraper.pages_fetched,
            "cache_hits": scraper.cache_hits,
        })
        print(f"FATAL ERROR: {error}")
        sys.exit(1)

if __name__ == "__main__":
    main()
