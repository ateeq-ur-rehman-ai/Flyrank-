# The Polite Scraper

FlyRank Internship — Backend Track — Week 5.

A polite scraping pipeline for the first three catalogue pages of Books to Scrape.

## Features
- Identifying User-Agent
- Timeout
- 500ms delay between real requests
- HTML caching
- Three catalogue pages
- 60 unique book URLs
- Raw extraction and price normalization
- Pydantic validation
- books.json and errors.json
- Broken page handling
- run-report.json
- Idempotent output

## Target Classification
Books to Scrape is a public practice sandbox designed for learning web scraping. Only the first three catalogue pages are processed.

I will not reuse this code on another site without checking its rules and terms first.

## Installation

```bash
python -m venv venv
```

Windows:

```bash
venv\Scripts\activate
```

Install:

```bash
pip install -r requirements.txt
```

## Run

```bash
python -m src.main
```

## Tests

```bash
pytest
```

## Output

- `output/books.json`
- `output/errors.json`
- `output/run-report.json`

## Ethics

Prefer official APIs where available. Never bypass authentication, paywalls, or access restrictions. Collect only what is necessary.
