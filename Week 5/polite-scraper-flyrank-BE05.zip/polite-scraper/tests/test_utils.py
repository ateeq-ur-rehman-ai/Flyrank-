import pytest
from src.utils import normalize_price

def test_normalize_price():
    assert normalize_price("£51.77") == 51.77

def test_normalize_price_with_spaces():
    assert normalize_price("  £10.50  ") == 10.50

def test_normalize_price_invalid():
    with pytest.raises(ValueError):
        normalize_price("invalid")
