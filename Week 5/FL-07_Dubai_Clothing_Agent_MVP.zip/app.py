
from flask import Flask, request, jsonify, render_template_string
import csv, re, os, requests
from datetime import datetime

app = Flask(__name__)
DATA_FILE = os.path.join(os.path.dirname(__file__), "data", "factory_data.csv")

HTML = """
<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Dubai Clothing — Operations Agent</title>
<meta name="viewport" content="width=device-width,initial-scale=1">
<style>
body{font-family:Arial,sans-serif;background:#f5f7fb;margin:0;color:#18202a}
.wrap{max-width:1050px;margin:40px auto;padding:0 18px}
.card{background:white;border:1px solid #e4e8ef;border-radius:14px;padding:22px;margin-bottom:18px;box-shadow:0 4px 18px #00000008}
h1{margin:0 0 8px}.muted{color:#667085}.row{display:flex;gap:10px;flex-wrap:wrap}
input{flex:1;min-width:280px;padding:13px;border:1px solid #ccd3dd;border-radius:9px;font-size:15px}
button{padding:13px 18px;border:0;border-radius:9px;background:#111827;color:white;cursor:pointer}
pre{white-space:pre-wrap;line-height:1.55;background:#f8fafc;padding:16px;border-radius:10px}
.chips button{background:#eef2ff;color:#273469;margin:4px}
</style>
</head>
<body><div class="wrap">
<div class="card">
<h1>Dubai Clothing Operations Agent</h1>
<p class="muted">Vendor payments • containers • monthly summary • live currency conversion</p>
<div class="row"><input id="q" placeholder="e.g. Show unpaid vendors this month"><button onclick="ask()">Ask Agent</button></div>
<div class="chips">
<button onclick="setq('Show all unpaid vendors')">Unpaid vendors</button>
<button onclick="setq('Show container status')">Containers</button>
<button onclick="setq('Show total monthly payments')">Monthly payments</button>
<button onclick="setq('Convert 12500 CNY to PKR')">CNY → PKR</button>
<button onclick="setq('Convert 5000 AED to PKR')">AED → PKR</button>
</div>
</div>
<div class="card"><h3>Agent result</h3><pre id="out">Ask a question to begin.</pre></div>
</div>
<script>
function setq(x){document.getElementById('q').value=x}
async function ask(){
 const q=document.getElementById('q').value;
 document.getElementById('out').textContent='Processing...';
 const r=await fetch('/agent',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({message:q})});
 const d=await r.json(); document.getElementById('out').textContent=d.answer||d.error;
}
</script>
</body></html>
"""

def rows():
    with open(DATA_FILE, newline="", encoding="utf-8") as f:
        return list(csv.DictReader(f))

def money(n):
    return f"{float(n):,.2f}"

def payment_summary(data):
    total = sum(float(x["payment_amount_usd"]) for x in data)
    paid = sum(float(x["payment_amount_usd"]) for x in data if x["payment_status"].lower()=="paid")
    pending = total-paid
    return total, paid, pending

def currency_to_pkr(amount, currency):
    currency = currency.upper()
    if currency == "PKR":
        return amount, "PKR"
    # Live public exchange-rate source. We fetch PKR base and invert the rate.
    url = "https://open.er-api.com/v6/latest/PKR"
    try:
        data = requests.get(url, timeout=8).json()
        rate = data["rates"][currency]  # 1 PKR = rate source-currency
        return amount / rate, "live"
    except Exception:
        # Demo fallback so the core workflow remains testable offline.
        fallback = {
            "CNY": 39.0, "AED": 76.0, "SAR": 74.5, "QAR": 77.0,
            "KWD": 910.0, "BHD": 740.0, "OMR": 735.0, "USD": 280.0
        }
        if currency not in fallback:
            raise ValueError(f"Currency {currency} is not available.")
        return amount * fallback[currency], "fallback"

def agent(message):
    m = message.lower().strip()
    data = rows()

    # Currency intent
    cur = re.search(r'convert\s+([\d,.]+)\s*([a-z]{3})\s*(?:to\s*)?(pkr)?', m, re.I)
    if not cur:
        cur = re.search(r'([\d,.]+)\s*([a-z]{3})\s*(?:to|into)\s*pkr', m, re.I)
    if cur:
        amount = float(cur.group(1).replace(",", ""))
        currency = cur.group(2).upper()
        try:
            result, source = currency_to_pkr(amount, currency)
            label = "live exchange-rate API" if source=="live" else "demo fallback rate"
            return f"{amount:,.2f} {currency} ≈ {result:,.2f} PKR\nRate source: {label}."
        except Exception as e:
            return str(e)

    # Vendor / payment intent
    if any(k in m for k in ["unpaid", "pending payment", "who to pay", "due payment"]):
        pending = [x for x in data if x["payment_status"].lower() != "paid"]
        if not pending:
            return "No unpaid vendors found."
        lines = [f"Unpaid vendors: {len(pending)}"]
        for x in pending:
            lines.append(f"- {x['vendor_name']} — ${money(x['payment_amount_usd'])} — Due {x['payment_due_date']}")
        total = sum(float(x["payment_amount_usd"]) for x in pending)
        lines.append(f"Total pending: ${money(total)}")
        return "\n".join(lines)

    if "vendor" in m:
        lines = ["Vendors:"]
        for x in data:
            lines.append(f"- {x['vendor_name']} | {x['country']} | {x['payment_status']} | Due {x['payment_due_date']}")
        return "\n".join(lines)

    # Container intent
    if "container" in m or "shipment" in m:
        lines = ["Container status:"]
        for x in data:
            lines.append(
                f"- {x['container_number']} | ETA {x['container_arrival_date']} | "
                f"Unloaded {x['unloading_date']} | {x['container_status']}"
            )
        return "\n".join(lines)

    # Monthly payment intent
    if "monthly" in m or "total payment" in m or "payment summary" in m:
        total, paid, pending = payment_summary(data)
        return (f"Monthly payment summary:\n"
                f"- Total vendor payments: ${money(total)}\n"
                f"- Paid: ${money(paid)}\n"
                f"- Pending: ${money(pending)}")

    return ("I can handle 5 core jobs: vendor lookup, unpaid-payment tracking, "
            "container tracking, monthly payment summary, and currency conversion to PKR. "
            "Try: 'Show unpaid vendors' or 'Convert 12500 CNY to PKR'.")

@app.get("/")
def home():
    return render_template_string(HTML)

@app.post("/agent")
def run_agent():
    payload = request.get_json(silent=True) or {}
    msg = payload.get("message","")
    if not msg:
        return jsonify({"error":"Message is required."}), 400
    return jsonify({"answer": agent(msg)})

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=5000, debug=True)
