# FL-07 — Dubai Clothing Operations Agent

## Core MVP
The agent performs five jobs:
1. Vendor lookup
2. Unpaid/vendor payment tracking
3. Container tracking
4. Monthly payment summary
5. Currency conversion to PKR

## Live connection
The currency converter calls a public exchange-rate API at runtime. If the API is unavailable, the app uses a clearly labelled demo fallback rate so the MVP remains testable.

## Run locally
```bash
python -m venv .venv
# Windows:
.venv\Scripts\activate
pip install -r requirements.txt
python app.py
```
Open http://127.0.0.1:5000

## Demo prompts
- Show unpaid vendors
- Show all vendors
- Show container status
- Show total monthly payments
- Convert 12500 CNY to PKR
- Convert 5000 AED to PKR

## Recording flow
1. Open the agent.
2. Ask "Show unpaid vendors".
3. Ask "Show container status".
4. Ask "Convert 12500 CNY to PKR".
5. Stop after the successful results. Keep the recording raw/unedited.

## Data connection
`data/factory_data.csv` is the connected operational data source for the MVP.
