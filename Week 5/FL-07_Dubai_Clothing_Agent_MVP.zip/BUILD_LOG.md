# FL-07 Build Log — Dubai Clothing Operations Agent

## Initial scope
The original system concept included vendor records, payment dates/amounts, containers, unloading dates, monthly totals, and currency conversion. For FL-07, the build was intentionally kept to five core capabilities.

## Iteration 1 — Data model
Created a single CSV data source containing:
- vendor details
- payment amount/status/due date
- container number
- ETA
- unloading date
- container status

## Iteration 2 — Agent routing
Added a lightweight intent router so natural-language requests are mapped to the five core jobs. This avoids requiring the user to manually manipulate the data during a run.

## Iteration 3 — Currency connection
Added a live exchange-rate API call for currency → PKR conversion. China and Gulf currencies are included in the supported demo prompts (CNY, AED, SAR, QAR, KWD, BHD, OMR). A fallback rate is used only if the live API is unavailable and is labelled as such.

## What broke / what changed
- Live APIs can fail because of network availability. A fallback was added so the MVP can still demonstrate the workflow.
- Instead of building a large ERP-style interface, the scope was cut to five agent jobs to match the narrow-MVP requirement.

## What was cut
- Authentication/roles
- Purchase-order management
- Inventory management
- Advanced analytics/charts
- Automated payment execution
- Email/WhatsApp notifications

Reason: these are outside the narrow FL-07 core job and would increase build time without improving the first end-to-end demonstration.

## End-to-end acceptance tests
- "Show unpaid vendors" → returns pending vendors and total pending amount.
- "Show container status" → returns container ETA, unloading date and status.
- "Show total monthly payments" → returns total, paid and pending amounts.
- "Convert 12500 CNY to PKR" → calls live exchange-rate service when available.
