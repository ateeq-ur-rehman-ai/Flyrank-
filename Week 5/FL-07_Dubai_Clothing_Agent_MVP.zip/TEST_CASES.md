# FL-07 Test Cases

| Test | Input | Expected |
|---|---|---|
| Vendor | Show all vendors | Vendor list |
| Payment | Show unpaid vendors | Pending vendors + total |
| Container | Show container status | ETA/unloading/status |
| Summary | Show total monthly payments | Total/paid/pending |
| Currency | Convert 12500 CNY to PKR | PKR result + source |

## Recording recommendation
Use the three strongest tests for the ~2 minute raw recording:
1. Show unpaid vendors
2. Show container status
3. Convert 12500 CNY to PKR
