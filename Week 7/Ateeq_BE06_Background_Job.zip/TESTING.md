# BE-06 Test Checklist

## 1. Health

`GET /health`

Expected: HTTP 200 and Redis connected.

## 2. Fast acceptance

`POST /jobs`

Expected: HTTP 202, not a long-running HTTP request.

## 3. Status

`GET /jobs/:id`

Expected: queued/active/completed/failed state.

## 4. Idempotency

Send the same `Idempotency-Key` twice.

Expected: the same job ID is returned; a duplicate job is not created.

## 5. Slow work

Use the local demo mode.

Expected: worker takes a few seconds while the API remains free to answer other requests.

## 6. Retry

Set an invalid OpenAI key or otherwise force the AI operation to fail.

Expected: BullMQ retries the job up to the configured maximum.

## 7. Timeout

Set `JOB_TIMEOUT_MS=1` temporarily.

Expected: the worker reports a timeout and the job retries.

## 8. Alert

After all attempts fail, check `alerts.log`.

Expected: a permanent-failure alert is written.

## Suggested screen-recording sequence

1. Show the API and worker running.
2. Submit one job and show `202 Accepted`.
3. Copy the returned job ID.
4. Poll the status endpoint.
5. Show the worker processing the job.
6. Poll again and show `completed` plus the result.
7. Repeat the same request with the same idempotency key and show that no duplicate job is created.
