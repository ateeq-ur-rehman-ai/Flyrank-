require("dotenv").config();

const express = require("express");
const { v4: uuidv4 } = require("uuid");
const { queue, connection } = require("./queue");

const app = express();
app.use(express.json({ limit: "64kb" }));

const PORT = Number(process.env.PORT || 3000);

app.get("/", (_req, res) => {
  res.json({
    service: "BE-06 Background Job API",
    status: "ok",
    endpoints: {
      create: "POST /jobs",
      status: "GET /jobs/:id"
    }
  });
});

// Fast request: accepts work and immediately returns HTTP 202.
app.post("/jobs", async (req, res) => {
  const prompt = typeof req.body?.prompt === "string" ? req.body.prompt.trim() : "";
  const idempotencyKey =
    req.header("Idempotency-Key") ||
    (typeof req.body?.idempotencyKey === "string" ? req.body.idempotencyKey.trim() : "");

  if (!prompt) {
    return res.status(400).json({ error: "prompt is required" });
  }

  if (!idempotencyKey) {
    return res.status(400).json({
      error: "Idempotency-Key header is required"
    });
  }

  // Idempotency is enforced with a deterministic jobId.
  const jobId = `ai-${Buffer.from(idempotencyKey).toString("base64url").slice(0, 80)}`;

  try {
    const existing = await queue.getJob(jobId);
    if (existing) {
      return res.status(202).json({
        jobId: existing.id,
        statusUrl: `/jobs/${existing.id}`,
        message: "Job already accepted; idempotent replay."
      });
    }

    await queue.add(
      "ai-decision",
      {
        prompt,
        requestedAt: new Date().toISOString()
      },
      { jobId }
    );

    return res.status(202).json({
      jobId,
      status: "queued",
      statusUrl: `/jobs/${jobId}`
    });
  } catch (error) {
    console.error("enqueue_error", error);
    return res.status(503).json({
      error: "Could not enqueue job"
    });
  }
});

app.get("/jobs/:id", async (req, res) => {
  try {
    const job = await queue.getJob(req.params.id);

    if (!job) {
      return res.status(404).json({ error: "Job not found" });
    }

    const state = await job.getState();
    const result = job.returnvalue || null;

    const payload = {
      jobId: job.id,
      state,
      attemptsMade: job.attemptsMade,
      progress: job.progress,
      createdAt: new Date(job.timestamp).toISOString()
    };

    if (state === "completed") {
      payload.result = result;
      payload.finishedAt = job.finishedOn
        ? new Date(job.finishedOn).toISOString()
        : null;
    }

    if (state === "failed") {
      payload.error = job.failedReason || "Job failed";
      payload.failedAt = job.finishedOn
        ? new Date(job.finishedOn).toISOString()
        : null;
    }

    return res.json(payload);
  } catch (error) {
    console.error("status_error", error);
    return res.status(500).json({ error: "Could not read job status" });
  }
});

app.get("/health", async (_req, res) => {
  try {
    await connection.ping();
    res.json({ status: "healthy", redis: "connected" });
  } catch {
    res.status(503).json({ status: "unhealthy", redis: "disconnected" });
  }
});

app.listen(PORT, () => {
  console.log(`API listening on http://localhost:${PORT}`);
});