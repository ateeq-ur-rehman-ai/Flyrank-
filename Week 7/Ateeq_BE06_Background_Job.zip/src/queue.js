const { Queue } = require("bullmq");
const IORedis = require("ioredis");

const redisUrl = process.env.REDIS_URL || "redis://localhost:6379";
const connection = new IORedis(redisUrl, {
  maxRetriesPerRequest: null
});

const queue = new Queue("ai-background-jobs", {
  connection,
  defaultJobOptions: {
    attempts: Number(process.env.MAX_ATTEMPTS || 3),
    backoff: {
      type: "exponential",
      delay: 1000
    },
    removeOnComplete: { count: 1000 },
    removeOnFail: { count: 1000 }
  }
});

module.exports = { connection, queue };