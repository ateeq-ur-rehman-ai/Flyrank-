require("dotenv").config();

const { Worker } = require("bullmq");
const OpenAI = require("openai");
const { connection } = require("./queue");
const fs = require("fs");
const path = require("path");

const TIMEOUT_MS = Number(process.env.JOB_TIMEOUT_MS || 20000);
const alertsFile = path.join(__dirname, "..", "alerts.log");

const openai = process.env.OPENAI_API_KEY
  ? new OpenAI({ apiKey: process.env.OPENAI_API_KEY })
  : null;

function alert(message) {
  const line = `[${new Date().toISOString()}] ${message}\n`;
  fs.appendFileSync(alertsFile, line);
  console.error(line.trim());
}

function withTimeout(promise, ms) {
  return Promise.race([
    promise,
    new Promise((_, reject) =>
      setTimeout(() => reject(new Error(`AI operation timed out after ${ms}ms`)), ms)
    )
  ]);
}

async function runAI(prompt) {
  if (!openai) {
    // Local demo fallback so the complete background-job flow works without paid API credits.
    await new Promise((resolve) => setTimeout(resolve, 2500));
    return {
      provider: "local-demo",
      decision: /refund|bug|support|error|issue|help/i.test(prompt)
        ? "SUPPORT"
        : "OTHER",
      text: "Demo worker completed the slow AI-style operation."
    };
  }

  const response = await withTimeout(
    openai.chat.completions.create({
      model: process.env.OPENAI_MODEL || "gpt-4o-mini",
      temperature: 0,
      messages: [
        {
          role: "system",
          content:
            "Classify the user's message. Return exactly one label: SUPPORT or OTHER."
        },
        { role: "user", content: prompt }
      ]
    }),
    TIMEOUT_MS
  );

  const text = response.choices?.[0]?.message?.content?.trim() || "";
  const decision = text.toUpperCase().includes("SUPPORT") ? "SUPPORT" : "OTHER";

  return {
    provider: "openai",
    decision,
    text
  };
}

const worker = new Worker(
  "ai-background-jobs",
  async (job) => {
    await job.updateProgress(10);
    const started = Date.now();

    const result = await runAI(job.data.prompt);

    await job.updateProgress(100);

    return {
      ...result,
      durationMs: Date.now() - started,
      processedAt: new Date().toISOString()
    };
  },
  {
    connection,
    concurrency: 2
  }
);

worker.on("completed", (job) => {
  console.log(`completed job=${job.id} attempts=${job.attemptsMade}`);
});

worker.on("failed", (job, error) => {
  const attempts = job?.attemptsMade || 0;
  const maxAttempts = Number(process.env.MAX_ATTEMPTS || 3);

  if (attempts >= maxAttempts) {
    alert(`ALERT: permanent failure job=${job?.id} reason=${error.message}`);
  } else {
    console.error(`retrying job=${job?.id} attempt=${attempts}: ${error.message}`);
  }
});

worker.on("error", (error) => {
  alert(`WORKER ERROR: ${error.message}`);
});

console.log("Background worker started.");
