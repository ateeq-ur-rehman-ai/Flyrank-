# Muhammad Sufiyan — FlyRank BE-06

## Your first background job

This project implements the professional background-job pattern:

1. Client submits slow work.
2. API validates the request and puts a job into Redis.
3. API immediately returns **HTTP 202 Accepted** with a job ID.
4. A separate worker consumes the job.
5. The worker performs the slow AI operation.
6. Failed jobs retry automatically with exponential backoff.
7. The client polls `GET /jobs/:id` for the current state and final result.
8. Permanently failed jobs create an entry in `alerts.log`.

## Tech stack

- Node.js + Express
- BullMQ
- Redis
- OpenAI SDK (optional real provider)
- Local demo fallback so the workflow can be tested without paid API credits

## Run locally

### 1. Start Redis

```bash
docker compose up -d redis
```

### 2. Install packages

```bash
npm install
```

### 3. Configure environment

Copy `.env.example` to `.env`.

For a no-cost demo, leave `OPENAI_API_KEY` empty. The worker uses a local simulated slow operation.

To use a real OpenAI model, set:

```env
OPENAI_API_KEY=your_key
OPENAI_MODEL=gpt-4o-mini
```

### 4. Start API

```bash
npm start
```

### 5. Start worker in another terminal

```bash
npm run worker
```

## Test the complete flow

Create a job:

```bash
curl -i -X POST http://localhost:3000/jobs \
  -H "Content-Type: application/json" \
  -H "Idempotency-Key: demo-001" \
  -d "{\"prompt\":\"Customer says their payment failed and asks for help\"}"
```

The API returns `202 Accepted`, for example:

```json
{
  "jobId": "ai-ZGVtby0wMDE",
  "status": "queued",
  "statusUrl": "/jobs/ai-ZGVtby0wMDE"
}
```

Then poll:

```bash
curl http://localhost:3000/jobs/ai-ZGVtby0wMDE
```

The state moves through `waiting`/`active` to `completed` (or `failed`).

## Idempotency

The `Idempotency-Key` is converted into a deterministic BullMQ `jobId`. Sending the same request twice does not create duplicate work; the existing job is returned.

This matters because clients can retry a request after a network timeout. The backend should not accidentally perform the same expensive operation twice.

## Retries

BullMQ is configured for three attempts with exponential backoff. A temporary worker error can therefore be retried automatically. Once the maximum number of attempts is reached, the worker writes an alert to `alerts.log`.

## Timeout

The real OpenAI operation is wrapped in a timeout. If the model call takes longer than `JOB_TIMEOUT_MS`, the job fails and BullMQ applies the retry policy.

## Architecture

```text
Client
  |
  | POST /jobs
  v
Express API
  |
  | 202 + jobId
  v
Redis / BullMQ Queue
  |
  v
Background Worker
  |
  | slow AI operation
  v
OpenAI API / local demo
  |
  v
Job result in Redis
  ^
  |
GET /jobs/:id
  |
Client polls status
```

## What I learned

The important design change is that the HTTP request is no longer responsible for waiting for slow work. The API only accepts the job and responds quickly. The worker owns the long-running operation.

This makes the system more reliable because slow work can retry independently, clients can check status later, and permanent failures can be surfaced through an alert.

## Files

- `src/server.js` — HTTP API and job submission/status endpoints
- `src/worker.js` — background worker, AI call, timeout, retries and alerts
- `src/queue.js` — BullMQ/Redis queue configuration
- `docker-compose.yml` — local Redis service
- `.env.example` — configuration template
- `alerts.log` — generated only when a permanent failure occurs
