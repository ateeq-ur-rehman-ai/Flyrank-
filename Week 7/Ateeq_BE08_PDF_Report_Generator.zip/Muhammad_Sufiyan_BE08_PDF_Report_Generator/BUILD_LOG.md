# Build Log — BE-08

## Stage 0 — Setup
- Chose JavaScript/Node.js lane.
- Added Express and Playwright.
- Used Node 22's built-in `node:sqlite`, keeping the database setup small.

## Stage 1 — Seed
- Created `orders` and `reports` tables.
- Seed script inserts exactly 200 shop orders.
- Seed starts with `DELETE FROM orders`, so running it twice leaves 200 orders instead of 400.

## Stage 2 — Aggregation
- Added a single `getReportData()` function.
- It returns totals, average order value, top five products, and category breakdown.

## Stage 3 — Render
- Built an HTML report template.
- Added print CSS: repeating `thead`, `break-inside: avoid`, A4 page sizing.
- PDF generation uses Playwright + Chromium.

## Stage 4 — Store and serve
- `POST /reports` queries data, renders the PDF, saves it under `reports/`, and returns a link.
- `GET /reports/:id` returns metadata.
- `GET /reports/:id/file` serves the PDF bytes.
- JSON responses never include the PDF bytes.

## Stage 5 — Idempotency
- Same-day POST returns the existing report instead of creating another file.
- `force: true` intentionally creates a fresh report for testing.

## Stage 6 — Documentation
- Added README, API proof, SQL, setup commands, `.gitignore`, and suggested seven-stage commit history.

## What I cut / why
- Background jobs, cron, and email are not part of the required core assignment; they are stretch goals. Keeping them out makes the core pipeline smaller and easier to verify. The assignment explicitly says background jobs are optional. 
