# Muhammad Sufiyan — FlyRank BE-08 PDF Report Generator

A small backend report pipeline built for the FlyRank Backend Engineering assignment:

**SQLite data → SQL aggregation → HTML → headless Chromium PDF → disk artifact → download link.**

The assignment requires a real PDF made from real data, at least two clean pages, clean page breaks with repeating table headers, report metadata endpoints, file-by-link serving, and an idempotency rule so repeated requests on the same day do not create duplicate reports.

## Dataset

I chose the **shop** lane and seed exactly **200 orders**. The seed script is safe to run repeatedly because it clears the orders table first and then recreates the 200-row dataset.

## Requirements covered

- `report.db` + repeat-safe seed: 200 orders
- Four report data sections: two totals, top 5, grouped category breakdown
- HTML-to-PDF through Playwright/Chromium
- PDF is designed for 2+ pages with repeating table headers and `break-inside: avoid`
- `POST /reports` → `201` with `id` and file link
- `GET /reports/:id` → report record; unknown id → `404`
- `GET /reports/:id/file` → PDF bytes only from the download endpoint
- Same-day duplicate POST → existing id with `200`; `{ "force": true }` creates a fresh report
- `reports/` and `report.db` are gitignored
- Simple browser demo at `/`

These map directly to the assignment's required pipeline and checkpoints. The assignment explicitly says the required version can run inside the request; background jobs are a stretch goal.

## Setup

Requirements: Node.js 22+.

```bash
npm install
npx playwright install chromium
npm run seed
npm start
```

Open `http://localhost:3000` or use curl.

If Chromium is already installed system-wide, you can set:

```bash
PLAYWRIGHT_EXECUTABLE_PATH=/usr/bin/chromium
```

On Windows, leave the variable unset and use the browser installed by `npx playwright install chromium`.

## API proof

Generate:

```bash
curl -i -X POST http://localhost:3000/reports -H "Content-Type: application/json" -d "{}"
```

Expected shape:

```json
{
  "id": 1,
  "status": "done",
  "file": "/reports/1/file"
}
```

Inspect metadata:

```bash
curl http://localhost:3000/reports/1
```

Download the actual PDF:

```bash
curl -o my-report.pdf http://localhost:3000/reports/1/file
```

The assignment checkpoint specifically asks for a `201` plus link, followed by a PDF download that opens as a real PDF.

## Idempotency proof

Run two normal POST requests on the same day:

```bash
curl -X POST http://localhost:3000/reports -H "Content-Type: application/json" -d "{}"
curl -X POST http://localhost:3000/reports -H "Content-Type: application/json" -d "{}"
```

The first creates a report (`201`). The second returns the same report id (`200`) and does not create another PDF.

To intentionally create a new report:

```bash
curl -X POST http://localhost:3000/reports -H "Content-Type: application/json" -d '{"force":true}'
```

This is the business idempotency rule required by Stage 5: same request twice → one effect/file, while `force` explicitly bypasses it.

## Aggregation SQL

The report uses one `getReportData()` function with these aggregation queries:

```sql
SELECT COUNT(*) AS total_orders, ROUND(SUM(total), 2) AS total_revenue
FROM orders;

SELECT ROUND(AVG(total), 2) AS average_order_value
FROM orders;

SELECT product, category, SUM(quantity) AS units_sold,
       ROUND(SUM(total), 2) AS revenue
FROM orders
GROUP BY product, category
ORDER BY revenue DESC
LIMIT 5;

SELECT category, COUNT(*) AS orders, SUM(quantity) AS units_sold,
       ROUND(SUM(total), 2) AS revenue
FROM orders
GROUP BY category
ORDER BY revenue DESC;
```

The assignment describes this as two totals, a top 5, and a grouped breakdown, and asks for the aggregation SQL in the README.

## Why store and link?

The PDF is an artifact. It is saved once on disk and the API returns an address such as `/reports/1/file`. JSON never contains the PDF bytes; only the download endpoint serves the file. This follows the assignment's “store and link” rule.

## Stage 4 note

The PDF generation happens inside the HTTP request for the required version. I would move it to a background job when the report becomes slow enough to hurt request latency or when report generation needs retries, concurrency control, or scheduled execution. The assignment intentionally keeps background jobs optional.

## Stage 5 note

The same-day check protects against accidental duplicate reports caused by double-clicks, retries, or repeated client requests. In a real system, the same idea prevents costly duplicate side effects such as charging a customer twice or sending the same notification twice.

## AI vs me

### Prompt used

> Build a small JavaScript backend that stores 200 seeded shop orders in SQLite. Create four SQL aggregations: total order count and total revenue, average order value, top five products by revenue, and revenue grouped by category. Generate an A4 PDF from an HTML template with Playwright/Chromium. The PDF must be at least two pages, repeat table headers across pages, and never split a table row. Add POST /reports, GET /reports/:id and GET /reports/:id/file. Store the PDF on disk and return only a link in JSON. Add same-day idempotency so repeated POSTs return the same report; accept force=true to bypass it. Include a repeat-safe seed script, .gitignore, README, and simple browser page.

### Concrete differences found during review

1. I kept the generated PDFs and database outside Git through `.gitignore`, because they are produced artifacts rather than source code.
2. I explicitly kept the file bytes out of JSON and made `/reports/:id/file` the only download path.
3. I added a visible short delay to make the synchronous request behavior easy to demonstrate in the Stage 4 checkpoint.
4. I added a `force` escape hatch so the idempotency behavior can be tested without waiting for the next day.

### Rematch

The second pass made the idempotency behavior explicit in the API and README instead of treating repeated generation as an accidental edge case.

## Screenshot

A generated PDF page screenshot is included in `screenshots/page-1.png` after running the local verification script.

## GitHub publishing

Create a public repository, then commit the stages separately. The assignment asks for at least seven meaningful commits and a README containing the run commands, SQL, download proof, Stage 4/5 notes, and a PDF screenshot.

Suggested commit sequence:

```text
Stage 0: project setup
Stage 1: seeded report.db
Stage 2: aggregation queries
Stage 3: HTML to PDF with clean page breaks
Stage 4: generate and serve by link
Stage 5: duplicate requests make one report
Stage 6: publish and docs
Stage 7: AI vs me
```

## Stretch ideas

If this were extended, generation could move into Inngest as a background job, a Monday 08:00 cron could generate reports automatically, and Mailpit could send a report link by email. Those are explicitly optional stretches in the assignment.
