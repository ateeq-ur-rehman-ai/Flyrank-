#!/usr/bin/env bash
set -e
npm run seed
node src/test-report-data.js >/tmp/be08-report-data.json
node src/server.js >/tmp/be08-server.log 2>&1 &
PID=$!
trap 'kill $PID 2>/dev/null || true' EXIT
sleep 1
curl -fsS -X POST http://localhost:3000/reports -H 'Content-Type: application/json' -d '{}' > /tmp/be08-first.json
curl -fsS -X POST http://localhost:3000/reports -H 'Content-Type: application/json' -d '{}' > /tmp/be08-second.json
node -e "const a=require('/tmp/be08-first.json'),b=require('/tmp/be08-second.json'); if(a.id!==b.id) throw new Error('idempotency failed'); console.log('PASS: same-day requests share report id',a.id)"
ID=$(node -e "console.log(require('/tmp/be08-first.json').id)")
curl -fsS -o reports/verification.pdf http://localhost:3000/reports/$ID/file
file reports/verification.pdf
