import { DatabaseSync } from 'node:sqlite';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
export const DB_PATH = path.join(root, 'report.db');
export const REPORTS_DIR = path.join(root, 'reports');

export function openDb() {
  return new DatabaseSync(DB_PATH);
}

export function ensureSchema(db) {
  db.exec(`
    CREATE TABLE IF NOT EXISTS orders (
      id INTEGER PRIMARY KEY,
      order_date TEXT NOT NULL,
      customer TEXT NOT NULL,
      product TEXT NOT NULL,
      category TEXT NOT NULL,
      quantity INTEGER NOT NULL,
      unit_price REAL NOT NULL,
      total REAL NOT NULL
    );
    CREATE TABLE IF NOT EXISTS reports (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      generated_at TEXT NOT NULL,
      report_date TEXT NOT NULL,
      file_path TEXT NOT NULL
    );
  `);
}

export function getReportData(db) {
  const totals = db.prepare(`
    SELECT COUNT(*) AS total_orders, ROUND(SUM(total), 2) AS total_revenue
    FROM orders
  `).get();

  const average = db.prepare(`
    SELECT ROUND(AVG(total), 2) AS average_order_value
    FROM orders
  `).get();

  const topProducts = db.prepare(`
    SELECT product, category, SUM(quantity) AS units_sold, ROUND(SUM(total), 2) AS revenue
    FROM orders
    GROUP BY product, category
    ORDER BY revenue DESC
    LIMIT 5
  `).all();

  const categoryBreakdown = db.prepare(`
    SELECT category, COUNT(*) AS orders, SUM(quantity) AS units_sold,
           ROUND(SUM(total), 2) AS revenue
    FROM orders
    GROUP BY category
    ORDER BY revenue DESC
  `).all();

  return {
    totals: { ...totals, ...average },
    topProducts,
    categoryBreakdown
  };
}
