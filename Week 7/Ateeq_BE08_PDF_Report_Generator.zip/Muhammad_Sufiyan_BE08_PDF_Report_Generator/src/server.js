import express from 'express';
import fs from 'node:fs/promises';
import path from 'node:path';
import { openDb, ensureSchema, getReportData, REPORTS_DIR } from './db.js';
import { generatePdf } from './report.js';

const app = express();
const port = Number(process.env.PORT || 3000);
const db = openDb();
ensureSchema(db);
await fs.mkdir(REPORTS_DIR, { recursive: true });

app.use(express.json());
app.use(express.static(path.resolve('public')));

app.get('/health', (_req, res) => res.json({ ok: true }));

app.post('/reports', async (req, res) => {
  const force = req.body?.force === true;
  const today = new Date().toISOString().slice(0, 10);

  if (!force) {
    const existing = db.prepare('SELECT * FROM reports WHERE report_date = ? ORDER BY id DESC LIMIT 1').get(today);
    if (existing) {
      return res.status(200).json({ id: existing.id, status: 'done', file: `/reports/${existing.id}/file`, idempotent: true });
    }
  }

  const reportDate = today;
  const data = getReportData(db);
  data.allOrders = db.prepare('SELECT * FROM orders ORDER BY id').all();

  // Visible work: PDF rendering takes a moment, matching the assignment's synchronous endpoint.
  await new Promise(resolve => setTimeout(resolve, 700));
  const provisional = db.prepare('INSERT INTO reports (generated_at, report_date, file_path) VALUES (?, ?, ?)').run(new Date().toISOString(), reportDate, '');
  const id = Number(provisional.lastInsertRowid);
  try {
    const { filePath } = await generatePdf(data, id, reportDate);
    db.prepare('UPDATE reports SET file_path = ? WHERE id = ?').run(filePath, id);
    return res.status(201).json({ id, status: 'done', file: `/reports/${id}/file` });
  } catch (error) {
    db.prepare('DELETE FROM reports WHERE id = ?').run(id);
    console.error(error);
    return res.status(500).json({ error: 'PDF generation failed', detail: error.message });
  }
});

app.get('/reports/:id', (req, res) => {
  const row = db.prepare('SELECT id, generated_at, report_date, file_path FROM reports WHERE id = ?').get(Number(req.params.id));
  if (!row) return res.status(404).json({ error: 'Report not found' });
  res.json({ id: row.id, generated_at: row.generated_at, report_date: row.report_date, status: row.file_path ? 'done' : 'pending', file: `/reports/${row.id}/file` });
});

app.get('/reports/:id/file', async (req, res) => {
  const row = db.prepare('SELECT * FROM reports WHERE id = ?').get(Number(req.params.id));
  if (!row) return res.status(404).json({ error: 'Report not found' });
  if (!row.file_path) return res.status(409).json({ error: 'Report is not ready' });
  try {
    await fs.access(row.file_path);
    res.type('application/pdf');
    res.sendFile(path.resolve(row.file_path));
  } catch {
    res.status(404).json({ error: 'Report file missing' });
  }
});

app.get('/reports', (_req, res) => {
  const rows = db.prepare('SELECT id, generated_at, report_date, file_path FROM reports ORDER BY id DESC').all();
  res.json(rows.map(r => ({ ...r, status: r.file_path ? 'done' : 'pending', file: `/reports/${r.id}/file` })));
});

app.listen(port, () => console.log(`BE-08 server running at http://localhost:${port}`));
