import { openDb, ensureSchema, getReportData } from './db.js';
const db = openDb(); ensureSchema(db);
const data = getReportData(db);
data.allOrders = db.prepare('SELECT * FROM orders ORDER BY id').all();
console.log(JSON.stringify(data, null, 2));
db.close();
