import { openDb, ensureSchema } from './db.js';

const db = openDb();
ensureSchema(db);
db.exec('DELETE FROM orders;');

const products = [
  ['Premium Hoodie', 'Apparel', 42],
  ['Classic T-Shirt', 'Apparel', 18],
  ['Denim Jacket', 'Apparel', 55],
  ['Running Shoes', 'Footwear', 68],
  ['Canvas Sneakers', 'Footwear', 49],
  ['Leather Belt', 'Accessories', 24],
  ['Travel Backpack', 'Bags', 39],
  ['Laptop Sleeve', 'Bags', 22],
  ['Sports Cap', 'Accessories', 15],
  ['Wool Scarf', 'Accessories', 19]
];

const customers = ['Ali Traders', 'Noor Retail', 'Metro Store', 'Urban Mart', 'Safa Collection', 'Prime Outlet', 'Eastline Shop', 'City Bazaar'];
const insert = db.prepare(`INSERT INTO orders (id, order_date, customer, product, category, quantity, unit_price, total)
VALUES (?, ?, ?, ?, ?, ?, ?, ?)`);

const start = new Date('2026-08-01T00:00:00Z');
for (let i = 1; i <= 200; i++) {
  const d = new Date(start);
  d.setUTCDate(d.getUTCDate() + ((i * 3) % 30));
  const [product, category, base] = products[(i - 1) % products.length];
  const quantity = 1 + (i % 8);
  const unitPrice = Number((base + ((i * 7) % 17) - 8).toFixed(2));
  const total = Number((quantity * unitPrice).toFixed(2));
  insert.run(i, d.toISOString().slice(0, 10), customers[(i - 1) % customers.length], product, category, quantity, unitPrice, total);
}

db.close();
console.log('Seeded report.db with 200 orders.');
