import { serve } from "inngest/next";
import { inngest } from "../../../lib/inngest";

export const runtime = "nodejs";

export const GET = serve({ client: inngest, functions: [] }).GET;
export const POST = serve({ client: inngest, functions: [] }).POST;
export const PUT = serve({ client: inngest, functions: [] }).PUT;