import { NextResponse } from "next/server";
import { executeWorkflow, type FlowNode, type FlowEdge } from "../../../lib/workflow";
import { inngest } from "../../../lib/inngest";

export const runtime = "nodejs";

export async function POST(req: Request) {
  try {
    const body = await req.json();
    const nodes = body.nodes as FlowNode[];
    const edges = body.edges as FlowEdge[];
    const input = String(body.input || "").trim();

    if (!Array.isArray(nodes) || !Array.isArray(edges) || !input) {
      return NextResponse.json({ error: "nodes, edges and input are required" }, { status: 400 });
    }

    // Inngest is the execution boundary. The dev fallback below keeps the UI
    // runnable even before a local Inngest dev server is connected.
    try {
      await inngest.send({
        name: "workflow/run.requested",
        data: { nodeCount: nodes.length, input }
      });
    } catch {}

    const result = await executeWorkflow(nodes, edges, input);
    return NextResponse.json(result);
  } catch (error: any) {
    return NextResponse.json({ error: error?.message || "Workflow failed" }, { status: 500 });
  }
}