import "./globals.css";

export const metadata = {
  title: "AI Decision Flow — Muhammad Sufiyan",
  description: "React Flow + Inngest visual AI decision workflow"
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return <html lang="en"><body>{children}</body></html>;
}