# BE-09 — AI Decision Flow

**Muhammad Sufiyan**

A visual AI workflow editor where every decision node returns only `YES` or `NO`. React Flow renders and edits the graph. The server has an Inngest integration boundary and executes the traversal through the same workflow model.

## Stack
- Next.js + React + TypeScript
- `@xyflow/react` (React Flow)
- Inngest
- OpenAI SDK
- CSS-based UI (no external component dependency required)

## Features delivered
### Phase 1
- React/Next.js app
- React Flow
- Inngest
- OpenAI SDK
- Environment variables
- README/project structure

### Phase 2
- Visual React Flow canvas
- Add nodes
- Connect nodes
- Edit prompts
- YES/NO edge labels
- LocalStorage save
- Interactive editor

### Phase 3
- Each decision node calls the AI decision layer
- Model is instructed to return only YES/NO
- Traversal follows the matching YES/NO edge
- Execution order is shown in the trace panel
- Inngest event route is included as the execution boundary

### Phase 4 — 5 polish items
- Visual execution state
- Execution logs
- Save/load locally
- JSON export
- Error handling

## Run locally

```bash
npm install
cp .env.example .env.local
npm run dev
```

Open `http://localhost:3000`.

For a local Inngest dev server in another terminal:

```bash
npm run inngest
```

Then point the Inngest dev server at:

```text
http://localhost:3000/api/inngest
```

## AI
Without `OPENAI_API_KEY`, the app uses deterministic demo mode so the workflow can be demonstrated without paid credentials.

With a key:

```env
OPENAI_API_KEY=your_key
OPENAI_MODEL=gpt-4o-mini
```

An OpenAI-compatible endpoint can be supplied with `OPENAI_BASE_URL`.

## How the workflow works

1. The user creates/edits a graph in React Flow.
2. The user enters a test message.
3. `POST /api/workflow` receives the graph and input.
4. The route emits an Inngest event boundary.
5. The workflow evaluates the first node.
6. The AI layer returns exactly YES or NO.
7. The matching edge is selected.
8. The next node is evaluated.
9. Execution stops when there is no matching outgoing edge or a node repeats.
10. The UI marks visited nodes and traversed edges and shows the execution trace.

## Demo path

Default graph:

`Start Decision --YES--> Support Node`

`Start Decision --NO--> Sales Node`

Try:
- `My order is damaged and I need help.` → likely YES
- `I want pricing for a new service.` → likely NO at the support question, then YES at Sales Node

## Note about Inngest
The starter implementation includes an Inngest client and `/api/inngest` endpoint and emits a workflow event. The traversal remains directly awaited in the API route so the project is immediately runnable in a fresh environment. If a production Inngest deployment is required, move `executeWorkflow()` into an Inngest function and return an event/run ID to the client.
