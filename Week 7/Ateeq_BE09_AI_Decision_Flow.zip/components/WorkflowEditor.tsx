 "use client";

import { useCallback, useEffect, useMemo, useState } from "react";
import {
  ReactFlow, Background, Controls, MiniMap, addEdge,
  useEdgesState, useNodesState, Handle, Position, type Connection, type Edge, type Node
} from "@xyflow/react";
import "@xyflow/react/dist/style.css";

type Decision = "YES" | "NO";
type FlowNodeData = { label: string; prompt: string; result?: Decision; active?: boolean };

const initialNodes: Node<FlowNodeData>[] = [
  { id: "start", position: { x: 60, y: 180 }, data: { label: "Start Decision", prompt: "Is this a support request?" }, type: "decision" },
  { id: "support", position: { x: 390, y: 70 }, data: { label: "Support Node", prompt: "Does the message describe a product issue, bug, or help request?" }, type: "decision" },
  { id: "sales", position: { x: 390, y: 300 }, data: { label: "Sales Node", prompt: "Is the message asking about pricing, purchase, or a new service?" }, type: "decision" }
];

const initialEdges: Edge[] = [
  { id: "start-yes", source: "start", target: "support", label: "YES", type: "smoothstep", animated: false, style: { strokeWidth: 2 } },
  { id: "start-no", source: "start", target: "sales", label: "NO", type: "smoothstep", animated: false, style: { strokeWidth: 2 } }
];

function DecisionNode({ data }: { data: FlowNodeData }) {
  return <div className={`node ${data.active ? "active" : ""}`}>
    <Handle type="target" position={Position.Left} />
    <div className="node-title">{data.label}</div>
    <div className="node-prompt">{data.prompt}</div>
    {data.result && <div className="node-result">AI → {data.result}</div>}
    <Handle type="source" position={Position.Right} id="yes" style={{ top: "38%" }} />
    <Handle type="source" position={Position.Right} id="no" style={{ top: "68%" }} />
  </div>;
}

const nodeTypes = { decision: DecisionNode };

export default function WorkflowEditor() {
  const [nodes, setNodes, onNodesChange] = useNodesState<FlowNodeData>(initialNodes);
  const [edges, setEdges, onEdgesChange] = useEdgesState(initialEdges);
  const [selected, setSelected] = useState<string>("start");
  const [input, setInput] = useState("My order is damaged and I need help.");
  const [running, setRunning] = useState(false);
  const [logs, setLogs] = useState<string[]>([]);
  const [lastRun, setLastRun] = useState<string[]>([]);

  const selectedNode = useMemo(() => nodes.find(n => n.id === selected), [nodes, selected]);

  useEffect(() => {
    const saved = localStorage.getItem("sufiyan-be09-flow");
    if (!saved) return;
    try {
      const parsed = JSON.parse(saved);
      if (parsed.nodes && parsed.edges) { setNodes(parsed.nodes); setEdges(parsed.edges); }
    } catch {}
  }, [setNodes, setEdges]);

  const onConnect = useCallback((connection: Connection) => {
    const label = connection.sourceHandle === "no" ? "NO" : "YES";
    setEdges(es => addEdge({ ...connection, id: `${connection.source}-${connection.target}-${Date.now()}`, label, type: "smoothstep" }, es));
  }, [setEdges]);

  function updatePrompt(value: string) {
    if (!selectedNode) return;
    setNodes(ns => ns.map(n => n.id === selected ? { ...n, data: { ...n.data, prompt: value } } : n));
  }

  function save() {
    localStorage.setItem("sufiyan-be09-flow", JSON.stringify({ nodes, edges }));
    setLogs(l => [`Saved ${nodes.length} nodes and ${edges.length} edges locally.`, ...l]);
  }

  function exportJson() {
    const blob = new Blob([JSON.stringify({ nodes, edges }, null, 2)], { type: "application/json" });
    const a = document.createElement("a"); a.href = URL.createObjectURL(blob); a.download = "workflow.json"; a.click();
    setTimeout(() => URL.revokeObjectURL(a.href), 500);
  }

  function addNode() {
    const id = `node-${Date.now()}`;
    setNodes(ns => [...ns, { id, position: { x: 170, y: 450 }, data: { label: "New Decision", prompt: "Does this condition pass?" }, type: "decision" }]);
    setSelected(id);
  }

  async function run() {
    if (running) return;
    setRunning(true); setLastRun([]); setLogs(l => ["Starting Inngest workflow…", ...l]);
    setNodes(ns => ns.map(n => ({ ...n, data: { ...n.data, active: false, result: undefined } })));
    try {
      const res = await fetch("/api/workflow", { method: "POST", headers: { "content-type": "application/json" }, body: JSON.stringify({ nodes, edges, input }) });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || "Workflow failed");
      setLastRun(data.trace || []);
      setLogs(l => [`Workflow completed: ${data.decision}`, ...l]);
      const results = new Map<string, Decision>(data.results || []);
      setNodes(ns => ns.map(n => ({ ...n, data: { ...n.data, active: results.has(n.id), result: results.get(n.id) } })));
      setEdges(es => es.map(e => ({ ...e, animated: data.path?.includes(e.id) ?? false })));
    } catch (e: any) {
      setLogs(l => [`Error: ${e.message}`, ...l]);
    } finally { setRunning(false); }
  }

  return <div className="page">
    <header className="topbar">
      <div className="brand"><span>AI</span> Decision Flow · Muhammad Sufiyan</div>
      <div className="status"><i className="dot"/> React Flow + Inngest</div>
    </header>

    <div className="toolbar">
      <button className="btn primary" onClick={run} disabled={running}>{running ? "Running…" : "▶ Run workflow"}</button>
      <button className="btn" onClick={addNode}>＋ Add node</button>
      <button className="btn" onClick={save}>Save locally</button>
      <button className="btn" onClick={exportJson}>Export JSON</button>
      <button className="btn danger" onClick={() => { setNodes(initialNodes); setEdges(initialEdges); setLogs(["Workflow reset."]); }}>Reset</button>
    </div>

    <div className="layout">
      <div className="canvas">
        <ReactFlow
          nodes={nodes} edges={edges} nodeTypes={nodeTypes}
          onNodesChange={onNodesChange} onEdgesChange={onEdgesChange}
          onConnect={onConnect} onNodeClick={(_, n) => setSelected(n.id)}
          fitView
          colorMode="dark"
        >
          <Background gap={20} size={1} />
          <Controls />
          <MiniMap />
        </ReactFlow>
      </div>

      <aside className="panel">
        <h2>Node editor</h2>
        <div className="hint">Select a node, edit its prompt, then connect YES/NO handles to another decision.</div>
        {selectedNode && <div className="field">
          <label>Node</label><input value={selectedNode.data.label} onChange={e => setNodes(ns => ns.map(n => n.id === selected ? {...n, data:{...n.data,label:e.target.value}} : n))}/>
        </div>}
        {selectedNode && <div className="field">
          <label>Decision prompt</label><textarea value={selectedNode.data.prompt} onChange={e => updatePrompt(e.target.value)}/>
        </div>}

        <h3>Test input</h3>
        <div className="field"><label>Message sent to the first decision</label><textarea value={input} onChange={e => setInput(e.target.value)}/></div>

        <h3>Execution trace</h3>
        <div className="log">{lastRun.length ? lastRun.join("\n") : "No run yet."}</div>

        <h3>System log</h3>
        <div className="log">{logs.slice(0,8).join("\n") || "Ready."}</div>
        <p className="hint">Demo mode works without an API key. If OPENAI_API_KEY is configured, the server uses an OpenAI-compatible model and normalizes its answer to YES/NO.</p>
      </aside>
    </div>
  </div>;
}