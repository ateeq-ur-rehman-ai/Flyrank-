import { Inngest } from "inngest";

export const inngest = new Inngest({ id: "sufiyan-ai-decision-flow" });