import { askDecision, type Decision } from "./ai";

export type FlowNode = { id: string; data: { label: string; prompt: string } };
export type FlowEdge = { id: string; source: string; target: string; label?: string };

export async function executeWorkflow(nodes: FlowNode[], edges: FlowEdge[], input: string) {
  const byId = new Map(nodes.map(n => [n.id, n]));
  let current = nodes[0];
  const trace: string[] = [];
  const results: [string, Decision][] = [];
  const path: string[] = [];
  const visited = new Set<string>();

  for (let i = 0; i < nodes.length + 2; i++) {
    if (!current || visited.has(current.id)) break;
    visited.add(current.id);

    const decision = await askDecision(current.data.prompt, input);
    results.push([current.id, decision]);
    trace.push(`${i + 1}. ${current.data.label} → ${decision}`);

    const nextEdge = edges.find(e => e.source === current.id && (e.label || "").toUpperCase() === decision);
    if (!nextEdge) {
      trace.push(`   End: no ${decision} path connected.`);
      break;
    }

    path.push(nextEdge.id);
    current = byId.get(nextEdge.target)!;
  }

  return { decision: results.at(-1)?.[1] || "NO", trace, results, path };
}