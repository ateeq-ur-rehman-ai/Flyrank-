import OpenAI from "openai";

export type Decision = "YES" | "NO";

function demoDecision(prompt: string, input: string): Decision {
  const text = `${prompt} ${input}`.toLowerCase();
  const yesWords = ["support", "help", "issue", "bug", "broken", "damaged", "problem", "price", "pricing", "buy", "purchase", "service"];
  return yesWords.some(w => text.includes(w)) ? "YES" : "NO";
}

export async function askDecision(prompt: string, input: string): Promise<Decision> {
  if (!process.env.OPENAI_API_KEY) return demoDecision(prompt, input);

  const client = new OpenAI({
    apiKey: process.env.OPENAI_API_KEY,
    baseURL: process.env.OPENAI_BASE_URL || undefined
  });

  const controller = new AbortController();
  const timeout = setTimeout(() => controller.abort(), 30_000);

  try {
    const response = await client.chat.completions.create({
      model: process.env.OPENAI_MODEL || "gpt-4o-mini",
      temperature: 0,
      messages: [
        { role: "system", content: "You are a binary decision classifier. Return exactly one token: YES or NO. Do not explain." },
        { role: "user", content: `Decision question: ${prompt}\nInput: ${input}` }
      ]
    }, { signal: controller.signal });

    const raw = response.choices[0]?.message?.content?.trim().toUpperCase();
    if (raw !== "YES" && raw !== "NO") throw new Error("LLM returned an invalid decision");
    return raw;
  } finally {
    clearTimeout(timeout);
  }
}