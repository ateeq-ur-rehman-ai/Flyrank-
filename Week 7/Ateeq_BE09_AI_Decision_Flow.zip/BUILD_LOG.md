# BE-09 Build Log

## Iteration 1 — Foundations
Created the Next.js/TypeScript project structure and the React Flow canvas.

## Iteration 2 — Graph editing
Added decision nodes, YES/NO source handles, connections, prompt editing and local persistence.

## Iteration 3 — AI decision layer
Added an OpenAI SDK wrapper with a strict binary system instruction. Added deterministic demo mode so the workflow can be exercised without an API key.

## Iteration 4 — Traversal
Implemented graph traversal: evaluate a node, choose the edge matching YES/NO, continue to the target, and stop at an unconnected branch or repeated node.

## Iteration 5 — Polish
Added visual active state, execution trace, system logs, local save, JSON export and error handling.

## Scope deviation
The assignment says each node should map directly to an Inngest step. This starter keeps the actual traversal in the API route while using an Inngest event boundary so it remains runnable without external credentials or a separately deployed Inngest function. For a production version, `executeWorkflow()` should be moved into an Inngest function and the UI should poll/subscribe to the run.
