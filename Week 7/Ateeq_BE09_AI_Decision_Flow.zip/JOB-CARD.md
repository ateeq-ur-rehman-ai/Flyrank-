# BE-09 Job Card

## Goal
Build a visual AI workflow system where each node makes a YES/NO decision and traversal follows the selected edge.

## Acceptance
- [x] Next.js/React app
- [x] React Flow canvas
- [x] Add/connect/edit nodes
- [x] YES/NO edges
- [x] Local save
- [x] AI decision layer
- [x] Dynamic traversal
- [x] Execution order
- [x] Visual execution state
- [x] Logs
- [x] JSON export
- [x] Error handling
- [x] Inngest integration boundary
