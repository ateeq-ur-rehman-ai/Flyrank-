
import json, logging, os, random, time
from enum import Enum
from flask import Flask, jsonify, request
from pydantic import BaseModel, Field, ValidationError, field_validator
import requests

APP_VERSION = "1.0.0"
PROMPT_VERSION = "vendor-payment-v1"
MODEL = os.getenv("LLM_MODEL", "llama-3.1-8b-instant")
LLM_ENABLED = os.getenv("LLM_ENABLED", "true").lower() == "true"
LLM_STUB = os.getenv("LLM_STUB", "0") == "1"
TIMEOUT = float(os.getenv("LLM_TIMEOUT", "30"))
MAX_RETRIES = 2

logging.basicConfig(level=logging.INFO, format="%(message)s")
logger = logging.getLogger("be07")

class Decision(str, Enum):
    PAY_NOW = "PAY_NOW"
    SCHEDULE_PAYMENT = "SCHEDULE_PAYMENT"
    NO_ACTION = "NO_ACTION"
    NEEDS_REVIEW = "NEEDS_REVIEW"

class PaymentDecision(BaseModel):
    decision: Decision
    vendor_name: str = Field(min_length=1, max_length=120)
    reason: str = Field(min_length=1, max_length=300)
    confidence: float = Field(ge=0, le=1)

    @field_validator("vendor_name", "reason")
    @classmethod
    def no_empty(cls, v):
        if not v.strip(): raise ValueError("must not be blank")
        return v.strip()

class PaymentRequest(BaseModel):
    message: str = Field(min_length=5, max_length=3000)

SYSTEM_PROMPT = open(os.path.join(os.path.dirname(os.path.dirname(__file__)), "prompts", "vendor_payment_v1.txt"), encoding="utf-8").read()

app = Flask(__name__)

def stub_response(text):
    t = text.lower()
    if any(x in t for x in ["already paid", "paid already", "payment made", "settled"]):
        d = Decision.NO_ACTION
    elif any(x in t for x in ["urgent", "today", "immediately", "asap", "overdue"]):
        d = Decision.PAY_NOW
    elif any(x in t for x in ["tomorrow", "next week", "on 12", "schedule", "due on"]):
        d = Decision.SCHEDULE_PAYMENT
    else:
        d = Decision.NEEDS_REVIEW
    return {"decision": d.value, "vendor_name": "Unknown Vendor", "reason": "Deterministic stub classification.", "confidence": 0.90}

def call_groq(user_text):
    key = os.getenv("GROQ_API_KEY")
    if not key: raise RuntimeError("GROQ_API_KEY is not configured.")
    url = "https://api.groq.com/openai/v1/chat/completions"
    payload = {
        "model": MODEL,
        "temperature": 0,
        "response_format": {"type": "json_object"},
        "messages": [
            {"role":"system","content":SYSTEM_PROMPT},
            {"role":"user","content":user_text}
        ]
    }
    headers = {"Authorization": f"Bearer {key}", "Content-Type":"application/json"}
    last = None
    for attempt in range(MAX_RETRIES + 1):
        started = time.perf_counter()
        try:
            r = requests.post(url, headers=headers, json=payload, timeout=TIMEOUT)
            duration = int((time.perf_counter()-started)*1000)
            if r.status_code == 200:
                data = r.json()
                usage = data.get("usage", {})
                raw = data["choices"][0]["message"]["content"]
                logger.info(json.dumps({"event":"llm_call","prompt_version":PROMPT_VERSION,"model":MODEL,
                    "input_tokens":usage.get("prompt_tokens",0),"output_tokens":usage.get("completion_tokens",0),
                    "duration_ms":duration,"repair":False}))
                return raw
            last = r
            if r.status_code in (400,401,403):
                raise RuntimeError(f"Provider error {r.status_code}: {r.text[:250]}")
            if r.status_code not in (429,500,502,503,504) or attempt >= MAX_RETRIES:
                raise RuntimeError(f"Provider error {r.status_code}: {r.text[:250]}")
            retry_after = r.headers.get("Retry-After")
            delay = float(retry_after) if retry_after else (2 ** attempt) + random.uniform(0, .25)
            time.sleep(delay)
        except requests.Timeout:
            duration = int((time.perf_counter()-started)*1000)
            logger.info(json.dumps({"event":"llm_timeout","prompt_version":PROMPT_VERSION,"model":MODEL,"duration_ms":duration}))
            if attempt >= MAX_RETRIES:
                raise TimeoutError("LLM provider timed out.")
            time.sleep((2 ** attempt) + random.uniform(0, .25))
    raise RuntimeError("LLM provider failed.")

def repair_output(user_text, raw):
    key = os.getenv("GROQ_API_KEY")
    if not key: raise RuntimeError("GROQ_API_KEY is not configured.")
    repair_prompt = SYSTEM_PROMPT + "\nREPAIR TASK: Return ONLY valid JSON matching the schema. Original output:\n" + raw
    payload = {"model":MODEL,"temperature":0,"response_format":{"type":"json_object"},
               "messages":[{"role":"system","content":repair_prompt},{"role":"user","content":user_text}]}
    r = requests.post("https://api.groq.com/openai/v1/chat/completions",
        headers={"Authorization":f"Bearer {key}","Content-Type":"application/json"},
        json=payload, timeout=TIMEOUT)
    if r.status_code != 200:
        raise RuntimeError(f"Repair provider error {r.status_code}: {r.text[:250]}")
    data=r.json(); usage=data.get("usage",{})
    logger.info(json.dumps({"event":"llm_call","prompt_version":PROMPT_VERSION,"model":MODEL,
        "input_tokens":usage.get("prompt_tokens",0),"output_tokens":usage.get("completion_tokens",0),
        "duration_ms":0,"repair":True}))
    return data["choices"][0]["message"]["content"]

@app.post("/api/v1/vendor-payment-decision")
def vendor_payment_decision():
    body = request.get_json(silent=True)
    if not isinstance(body, dict) or "message" not in body:
        return jsonify({"error":"Invalid input","field":"message"}), 400
    try:
        req = PaymentRequest.model_validate(body)
    except ValidationError as e:
        err=e.errors()[0]
        return jsonify({"error":"Invalid input","field":err["loc"][0],"detail":err["msg"]}), 400

    if not LLM_ENABLED:
        return jsonify(PaymentDecision.model_validate(stub_response(req.message)).model_dump()), 200
    if LLM_STUB:
        return jsonify(PaymentDecision.model_validate(stub_response(req.message)).model_dump()), 200

    try:
        raw = call_groq(req.message)
    except TimeoutError as e:
        return jsonify({"error":"LLM timeout","detail":str(e)}), 504
    except Exception as e:
        return jsonify({"error":"LLM unavailable","detail":str(e)}), 503

    try:
        result = PaymentDecision.model_validate_json(raw)
        return jsonify(result.model_dump()), 200
    except ValidationError:
        try:
            repaired = repair_output(req.message, raw)
            result = PaymentDecision.model_validate_json(repaired)
            return jsonify(result.model_dump()), 200
        except Exception as e:
            logger.info(json.dumps({"event":"quarantine","prompt_version":PROMPT_VERSION,"reason":"schema_validation_failed"}))
            return jsonify({"error":"Model output failed schema validation","detail":"Response quarantined."}), 422

@app.get("/health")
def health():
    return jsonify({"status":"ok","llm_enabled":LLM_ENABLED,"stub":LLM_STUB,"prompt_version":PROMPT_VERSION})

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=int(os.getenv("PORT","8000")))
