
import json, os, requests
cases=json.load(open("evals/cases.json",encoding="utf-8"))
base=os.getenv("BASE_URL","http://127.0.0.1:8000")
passed=0
for c in cases:
    r=requests.post(base+"/api/v1/vendor-payment-decision",json={"message":c["input"]},timeout=35)
    got=r.json().get("decision") if r.status_code==200 else f"HTTP_{r.status_code}"
    ok=got==c["expected"]
    passed+=ok
    print(f"{c['id']}: {'PASS' if ok else 'FAIL'} expected={c['expected']} got={got}")
print(f"\nScore: {passed}/{len(cases)} = {passed/len(cases)*100:.1f}%")
