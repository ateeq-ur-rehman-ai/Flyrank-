
import os, sys
sys.path.insert(0, ".")
os.environ["LLM_STUB"]="1"
os.environ["LLM_ENABLED"]="true"
from app.main import app

client=app.test_client()

def test_valid_stub():
    r=client.post("/api/v1/vendor-payment-decision",json={"message":"Shanghai Textile Co. needs payment today."})
    assert r.status_code==200
    assert r.json["decision"]=="PAY_NOW"
    assert set(r.json)=={"decision","vendor_name","reason","confidence"}

def test_missing_field():
    r=client.post("/api/v1/vendor-payment-decision",json={})
    assert r.status_code==400
    assert r.json["field"]=="message"

def test_short_message():
    r=client.post("/api/v1/vendor-payment-decision",json={"message":"hi"})
    assert r.status_code==400

def test_no_action():
    r=client.post("/api/v1/vendor-payment-decision",json={"message":"Yiwu Trading was already paid."})
    assert r.status_code==200
    assert r.json["decision"]=="NO_ACTION"
