# Job Card — Vendor Payment Decision API

## Input
POST JSON: `{"message": "<messy vendor/payment message>"}`

## Output
- `decision`
- `vendor_name`
- `reason`
- `confidence`

## Closed list
`decision` must be exactly one of:
- `PAY_NOW`
- `SCHEDULE_PAYMENT`
- `NO_ACTION`
- `NEEDS_REVIEW`

## Must never
- Never invent vendor/payment facts.
- Never return raw model text.
- Never guess when critical context is missing.
- Never retry 400/401/403 provider errors.
- Never send user content inside the system prompt.

## When unsure
Return `NEEDS_REVIEW`.

## One decision
The endpoint makes one payment-action decision per request.
