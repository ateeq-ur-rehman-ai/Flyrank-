# BE-07 — Put an LLM Behind Your API

**Muhammad Sufiyan**

A narrow, production-minded API endpoint that reads a messy vendor/payment message and returns one trusted, schema-validated payment action.

## Why this job
The Dubai Clothing operations system already deals with vendor payments. This endpoint automates one small judgement: should the payment be made now, scheduled, ignored because it is already paid, or sent for human review?

## Architecture
`POST /api/v1/vendor-payment-decision`
→ input validation
→ versioned system prompt
→ LLM provider
→ JSON parse + Pydantic schema validation
→ exactly one repair attempt on invalid model output
→ validated JSON response or 422 quarantine

## Trust controls
- Pydantic input/output schemas.
- Closed decision enum.
- User content is a separate user message.
- 30-second explicit provider timeout.
- Retries only for timeout, 429 and 5xx; never 400/401/403.
- Exponential backoff + jitter; respects Retry-After.
- Structured cost/usage logs.
- `LLM_ENABLED=false` kill switch.
- `LLM_STUB=1` deterministic no-cost mode.
- Invalid model output gets one repair attempt, then 422 + quarantine log.
- No raw model text is returned.

## Provider
This implementation uses Groq's OpenAI-compatible API. You need your own `GROQ_API_KEY`. The assignment allows use of available providers/tools; no key is included in this repository.

## Run
```bash
python -m venv .venv
# Windows
.venv\Scripts\activate
pip install -r requirements.txt
copy .env.example .env
# put your GROQ_API_KEY in .env
python -m app.main
```

Test:
```bash
curl -X POST http://127.0.0.1:8000/api/v1/vendor-payment-decision ^
  -H "Content-Type: application/json" ^
  -d "{\"message\":\"Shanghai Textile Co. says the invoice is overdue and needs settlement today.\"}"
```

Example shape:
```json
{"confidence":0.98,"decision":"PAY_NOW","reason":"The invoice is explicitly overdue and needs settlement today.","vendor_name":"Shanghai Textile Co."}
```

No API key needed for stub mode:
```bash
set LLM_STUB=1
python -m app.main
```

## Tests
```bash
pytest -q
python evals/run_evals.py
```

## Eval set
`evals/cases.json` contains 8 labelled cases, including ambiguous and unsure cases. Run the script against the live/stub endpoint and record the actual score and date here after running it.

**Eval score:** Run locally and record the real result. Do not claim a score that has not been measured.

## Build log
See `BUILD_LOG.md`.

## AI vs me
Optional bonus stage is intentionally separated. The hand-built implementation is the source of truth. If an AI-generated comparison is added later, it must live in a separate `ai-version/` folder and be reviewed manually.

## Security
`.env` is ignored and `.env.example` contains no secret. Never commit an API key.
