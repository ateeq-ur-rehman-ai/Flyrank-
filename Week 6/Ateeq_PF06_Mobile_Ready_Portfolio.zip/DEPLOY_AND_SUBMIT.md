# PF-05 Deployment & Submission Checklist

## Deploy
1. Create/login to Netlify.
2. Open Netlify Drop.
3. Drag the project folder containing `index.html` and `success.html` into the drop zone.
4. Open the generated `*.netlify.app` URL.
5. Rename the site to a professional name if available, for example `muhammad-sufiyan`.
6. Open the site's Forms section and make sure form detection is enabled.
7. Redeploy after enabling form detection if Netlify asks for a new deploy.

## Real end-to-end test
1. Open the public HTTPS site in an incognito/private window.
2. Go to Contact.
3. Submit a real test message.
4. In Netlify → Forms, verify the submission appears.
5. Optional but recommended: configure a Form submission notification to your email and verify that email arrives.
6. Save a screenshot showing the successful submission and the Netlify Forms submission record.

## Submit to FlyRank
Provide:
- Live HTTPS portfolio URL
- Screenshot/evidence of the real form submission
- `BACKEND_EXPLAINER.md` (or paste its contents into the submission)

## Important
The assignment requires exactly one live dynamic feature. Do not add a second interactive feature before submission.
