# PF-06 — Open It on Your Phone: Fix Log

## Scope
Portfolio audited as a mobile-first static site. The goal was to remove obvious mobile layout problems, improve readability/tap targets, and make the existing links and single contact feature easier to use.

## Before → After

### 1. Narrow screens could feel crowded
**Before:** The desktop layout used fixed two-column sections and two-column form fields as the default.

**After:** At widths below 700px, project cards and form fields collapse to one column. This prevents horizontal pressure and keeps content inside the viewport.

### 2. Buttons were not optimized for touch
**Before:** Buttons used compact desktop spacing.

**After:** Buttons now have a minimum 46px height, and on mobile the main action buttons become full-width. This gives a larger, clearer tap target.

### 3. Mobile typography
**Before:** The hero heading and supporting text were primarily tuned for desktop.

**After:** The hero heading uses a responsive `clamp()` size and the body copy becomes 17px on mobile. Form controls use 16px text to avoid common mobile browser zoom-on-focus behaviour.

### 4. Overflow protection
**Before:** Wide cards/forms could potentially pressure the viewport.

**After:** The page explicitly prevents horizontal overflow, grid children can shrink with `min-width:0`, and the form controls are width-constrained.

### 5. Keyboard/focus accessibility
**Before:** Inputs relied mostly on browser defaults for focus indication.

**After:** Focused inputs and textareas receive a visible outline, making keyboard navigation easier to follow.

### 6. Reduced-motion support
**Before:** Smooth scrolling was always enabled.

**After:** Users who request reduced motion through their device/OS preference get normal scrolling.

### 7. Link audit
The portfolio currently exposes:
- LinkedIn
- GitHub
- Contact section
- Netlify form submission flow

No fake demo/repository links were added. The project cards describe work but do not pretend to have a public demo where none was supplied.

## Manual device check required
This package improves the layout and gives you the fix log, but the assignment specifically requires a **real phone check**. Before submission:
1. Deploy the latest folder.
2. Open the public HTTPS URL on your actual phone.
3. Test the menu/navigation, LinkedIn, GitHub and contact form.
4. Scroll through every section.
5. Submit a real test form.
6. Take one phone screenshot after the fixes.
7. Optionally take a before screenshot from the old deployment/version if you have it.

## Desktop/tablet check
After the phone test, check approximately:
- 390px wide phone
- 768px tablet
- 1366px desktop

The CSS has dedicated responsive behaviour for mobile and tablet widths.
