# PF-06 Submission Checklist

- [ ] Latest version deployed to the same/new Netlify URL
- [ ] Real phone test completed
- [ ] LinkedIn link clicked
- [ ] GitHub link clicked
- [ ] Contact form submitted successfully
- [ ] Netlify Forms submission confirmed
- [ ] Tablet width checked
- [ ] Desktop width checked
- [ ] Phone screenshot captured after fixes
- [ ] `FIX_LOG.md` attached to FlyRank
- [ ] Live HTTPS URL submitted
