# PF-05 — Backend & Data Flow Explainer

## What is a backend?

A backend is the part of a website that handles work that should not be done only in the visitor's browser. It can receive data, validate it, store it, call other services and send a result back.

For this portfolio, I deliberately kept the feature small. The page itself is static HTML/CSS, while Netlify provides the form-handling backend service.

## What is the one feature?

The portfolio has exactly one dynamic feature: a contact form.

A visitor enters their name, email and message and presses **Send message**. The form is marked with Netlify's form attribute, so the hosting platform detects it when the site is deployed and handles the submission.

## How the data flows

1. The visitor opens the portfolio in their browser.
2. The browser displays the HTML form.
3. The visitor enters name, email and message.
4. The browser sends the form fields to the deployed site using an HTTP POST request.
5. Netlify's form handling receives the submission.
6. The submission becomes available in the site's Netlify Forms area.
7. A form-submission notification can also be configured in Netlify to forward the submission to the owner's email.
8. The visitor is sent to `success.html` and sees a confirmation.

The important point is that the browser does not need a custom server written by me for this feature. Netlify supplies the backend form handling for the deployed static site.

## Why I chose this feature

The assignment asks for exactly one genuinely working feature. A contact form is useful for a portfolio because it creates a direct path for a recruiter, client or collaborator to contact me without adding unnecessary features.

## Free-tier setup

Netlify's current documentation says its credit-based plans provide unlimited free form submissions. The form is enabled by adding `data-netlify="true"` (or `netlify`) to the HTML form and deploying it. Netlify scans the deployed HTML for the form and handles submissions.

## Test evidence

After deployment, submit a real test message such as:

Name: FlyRank Test  
Email: your own email  
Message: PF-05 live contact form test.

Then open the Netlify site dashboard → Forms and confirm the submission appears. For stronger evidence, configure a form-submission notification and confirm the email arrives.

Do not claim the feature is live-tested until this real submission has been confirmed.
