# Muhammad Sufiyan — PF-05 Portfolio

This is the updated portfolio for FlyRank's "Make It Do Something" assignment.

Dynamic feature: **one Netlify Forms contact form**.

Files:
- `index.html` — portfolio page and the single dynamic contact form
- `success.html` — post-submission confirmation page
- `BACKEND_EXPLAINER.md` — plain-words backend and data-flow explanation
- `DEPLOY_AND_SUBMIT.md` — deployment, real-test and submission checklist

No API key or secret is required.
