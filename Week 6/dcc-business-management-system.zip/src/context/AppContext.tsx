import React, { createContext, useContext, useState, useEffect, ReactNode } from 'react';
import {
  Vendor,
  Container,
  Payment,
  CurrencyInfo,
  ActivityLog,
  ActiveModule,
  UserProfile,
  CurrencyCode,
  ContainerStatus,
  PaymentStatus,
} from '../types';
import {
  INITIAL_CURRENCIES,
  INITIAL_VENDORS,
  INITIAL_CONTAINERS,
  INITIAL_PAYMENTS,
  INITIAL_ACTIVITY_LOGS,
  INITIAL_USERS,
} from '../data/mockData';
import { fetchLiveExchangeRates } from '../services/currencyService';

interface AppContextType {
  // Navigation & Screen state
  activeModule: ActiveModule;
  setActiveModule: (module: ActiveModule) => void;
  selectedVendorId: string | null;
  setSelectedVendorId: (id: string | null) => void;
  selectedContainerId: string | null;
  setSelectedContainerId: (id: string | null) => void;
  
  // Auth state
  isAuthenticated: boolean;
  currentUser: UserProfile;
  login: (email?: string) => void;
  logout: () => void;
  switchUser: (user: UserProfile) => void;
  availableUsers: UserProfile[];

  // Global search
  globalSearch: string;
  setGlobalSearch: (q: string) => void;

  // Data
  vendors: Vendor[];
  containers: Container[];
  payments: Payment[];
  currencies: CurrencyInfo[];
  activities: ActivityLog[];

  // Currency helpers
  convertAmount: (amount: number, fromCurrency: CurrencyCode, toCurrency: CurrencyCode) => number;
  updateCurrencyRate: (currency: CurrencyCode, newRate: number) => void;
  resetCurrencyRates: () => void;
  fetchLiveRates: () => Promise<void>;
  isFetchingRates: boolean;
  lastRatesUpdated: string;
  rateProvider: string;
  isLiveRates: boolean;

  // Vendor actions
  addVendor: (vendor: Omit<Vendor, 'id' | 'createdAt' | 'totalImportValuePKR' | 'totalPaidPKR' | 'pendingBalancePKR' | 'activeContainersCount' | 'totalContainersCount'>) => void;
  updateVendor: (id: string, updates: Partial<Vendor>) => void;
  deleteVendor: (id: string) => void;
  getVendorById: (id: string) => Vendor | undefined;

  // Container actions
  addContainer: (container: Omit<Container, 'id' | 'createdAt' | 'shipmentValuePKR' | 'trackingMilestones'>) => void;
  updateContainerStatus: (id: string, newStatus: ContainerStatus, note?: string) => void;
  getContainerById: (id: string) => Container | undefined;

  // Payment actions
  addPayment: (payment: Omit<Payment, 'id' | 'paymentRef' | 'createdAt' | 'amountPKR'>) => void;
  updatePaymentStatus: (id: string, status: PaymentStatus) => void;

  // Modal triggers
  isAddVendorOpen: boolean;
  setIsAddVendorOpen: (open: boolean) => void;
  isAddPaymentOpen: boolean;
  setIsAddPaymentOpen: (open: boolean) => void;
  isAddContainerOpen: boolean;
  setIsAddContainerOpen: (open: boolean) => void;
  isVendorDetailsOpen: boolean;
  setIsVendorDetailsOpen: (open: boolean) => void;
  isContainerDetailsOpen: boolean;
  setIsContainerDetailsOpen: (open: boolean) => void;
  isMobileSidebarOpen: boolean;
  setIsMobileSidebarOpen: (open: boolean) => void;

  // Reset to demo data
  resetAllData: () => void;
}

const AppContext = createContext<AppContextType | undefined>(undefined);

const STORAGE_KEYS = {
  VENDORS: 'dcc_vendors_v1',
  CONTAINERS: 'dcc_containers_v1',
  PAYMENTS: 'dcc_payments_v1',
  CURRENCIES: 'dcc_currencies_v1',
  ACTIVITIES: 'dcc_activities_v1',
  AUTH: 'dcc_auth_v1',
};

// Unique ID generator with random entropy to prevent key collisions
const generateUniqueId = (prefix: string): string => {
  return `${prefix}-${Date.now()}-${Math.random().toString(36).slice(2, 9)}`;
};

// Helper to deduplicate items by ID and guarantee uniqueness
const sanitizeListWithUniqueIds = <T extends { id: string }>(items: T[]): T[] => {
  const seen = new Set<string>();
  const result: T[] = [];
  for (const item of items) {
    if (!item || !item.id) continue;
    if (!seen.has(item.id)) {
      seen.add(item.id);
      result.push(item);
    } else {
      const freshId = generateUniqueId(item.id.split('-')[0] || 'item');
      seen.add(freshId);
      result.push({ ...item, id: freshId });
    }
  }
  return result;
};

export const AppProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
  const [activeModule, setActiveModule] = useState<ActiveModule>('dashboard');
  const [selectedVendorId, setSelectedVendorId] = useState<string | null>(null);
  const [selectedContainerId, setSelectedContainerId] = useState<string | null>(null);
  const [globalSearch, setGlobalSearch] = useState<string>('');

  const [isAuthenticated, setIsAuthenticated] = useState<boolean>(() => {
    const saved = localStorage.getItem(STORAGE_KEYS.AUTH);
    return saved !== null ? JSON.parse(saved) : true;
  });

  const [currentUser, setCurrentUser] = useState<UserProfile>(INITIAL_USERS[0]);

  // Modals state
  const [isAddVendorOpen, setIsAddVendorOpen] = useState(false);
  const [isAddPaymentOpen, setIsAddPaymentOpen] = useState(false);
  const [isAddContainerOpen, setIsAddContainerOpen] = useState(false);
  const [isVendorDetailsOpen, setIsVendorDetailsOpen] = useState(false);
  const [isContainerDetailsOpen, setIsContainerDetailsOpen] = useState(false);
  const [isMobileSidebarOpen, setIsMobileSidebarOpen] = useState(false);

  // Entities state with LocalStorage
  const [vendors, setVendors] = useState<Vendor[]>(() => {
    const saved = localStorage.getItem(STORAGE_KEYS.VENDORS);
    return sanitizeListWithUniqueIds(saved ? JSON.parse(saved) : INITIAL_VENDORS);
  });

  const [containers, setContainers] = useState<Container[]>(() => {
    const saved = localStorage.getItem(STORAGE_KEYS.CONTAINERS);
    return sanitizeListWithUniqueIds(saved ? JSON.parse(saved) : INITIAL_CONTAINERS);
  });

  const [payments, setPayments] = useState<Payment[]>(() => {
    const saved = localStorage.getItem(STORAGE_KEYS.PAYMENTS);
    return sanitizeListWithUniqueIds(saved ? JSON.parse(saved) : INITIAL_PAYMENTS);
  });

  const [currencies, setCurrencies] = useState<CurrencyInfo[]>(() => {
    const saved = localStorage.getItem(STORAGE_KEYS.CURRENCIES);
    return saved ? JSON.parse(saved) : INITIAL_CURRENCIES;
  });

  const [activities, setActivities] = useState<ActivityLog[]>(() => {
    const saved = localStorage.getItem(STORAGE_KEYS.ACTIVITIES);
    return sanitizeListWithUniqueIds(saved ? JSON.parse(saved) : INITIAL_ACTIVITY_LOGS);
  });

  // Live Exchange Rate State
  const [isFetchingRates, setIsFetchingRates] = useState<boolean>(false);
  const [lastRatesUpdated, setLastRatesUpdated] = useState<string>('Live Feed Initializing...');
  const [rateProvider, setRateProvider] = useState<string>('Forex Live API');
  const [isLiveRates, setIsLiveRates] = useState<boolean>(true);

  // Sync to local storage
  useEffect(() => {
    localStorage.setItem(STORAGE_KEYS.VENDORS, JSON.stringify(vendors));
  }, [vendors]);

  useEffect(() => {
    localStorage.setItem(STORAGE_KEYS.CONTAINERS, JSON.stringify(containers));
  }, [containers]);

  useEffect(() => {
    localStorage.setItem(STORAGE_KEYS.PAYMENTS, JSON.stringify(payments));
  }, [payments]);

  useEffect(() => {
    localStorage.setItem(STORAGE_KEYS.CURRENCIES, JSON.stringify(currencies));
  }, [currencies]);

  useEffect(() => {
    localStorage.setItem(STORAGE_KEYS.ACTIVITIES, JSON.stringify(activities));
  }, [activities]);

  useEffect(() => {
    localStorage.setItem(STORAGE_KEYS.AUTH, JSON.stringify(isAuthenticated));
  }, [isAuthenticated]);

  const login = () => {
    setIsAuthenticated(true);
  };

  const logout = () => {
    setIsAuthenticated(false);
  };

  const switchUser = (user: UserProfile) => {
    setCurrentUser(user);
  };

  const getCurrencyRate = (code: CurrencyCode): number => {
    const curr = currencies.find((c) => c.code === code);
    return curr ? curr.rateToPKR : 1;
  };

  const convertAmount = (amount: number, from: CurrencyCode, to: CurrencyCode): number => {
    if (from === to) return amount;
    const fromRate = getCurrencyRate(from);
    const toRate = getCurrencyRate(to);
    // Convert to PKR first, then to target
    const inPKR = amount * fromRate;
    return inPKR / toRate;
  };

  const updateCurrencyRate = (currency: CurrencyCode, newRate: number) => {
    setCurrencies((prev) =>
      prev.map((c) => (c.code === currency ? { ...c, rateToPKR: newRate } : c))
    );
    
    // Add activity log
    const newAct: ActivityLog = {
      id: generateUniqueId('act'),
      timestamp: new Date().toISOString().replace('T', ' ').slice(0, 16),
      type: 'rate',
      title: `Exchange Rate Updated: 1 ${currency} = Rs. ${newRate}`,
      description: `Daily rate adjusted for ${currency} conversion to Pakistani Rupee.`,
      tag: 'Forex'
    };
    setActivities((prev) => [newAct, ...prev]);
  };

  const fetchLiveRates = async () => {
    setIsFetchingRates(true);
    try {
      const response = await fetchLiveExchangeRates();
      setLastRatesUpdated(response.lastUpdated);
      setRateProvider(response.provider);
      setIsLiveRates(response.isLive);

      // Update all currencies with real live rates
      setCurrencies((prev) =>
        prev.map((c) => {
          if (c.code === 'PKR') return { ...c, rateToPKR: 1 };
          const liveRate = response.ratesToPKR[c.code];
          return liveRate !== undefined ? { ...c, rateToPKR: liveRate } : c;
        })
      );

      // Add activity log with unique ID
      if (response.isLive) {
        const newAct: ActivityLog = {
          id: generateUniqueId('act'),
          timestamp: new Date().toISOString().replace('T', ' ').slice(0, 16),
          type: 'rate',
          title: `Live Forex Sync: 1 USD = Rs. ${response.ratesToPKR.USD}, 1 CNY = Rs. ${response.ratesToPKR.CNY}`,
          description: `Updated live import exchange rates from ${response.provider}.`,
          tag: 'Live Forex'
        };
        setActivities((prev) => [newAct, ...prev.filter(a => !a.title.startsWith('Live Forex Sync'))]);
      }
    } catch (err) {
      console.error('Failed to sync live rates', err);
    } finally {
      setIsFetchingRates(false);
    }
  };

  // Initial fetch on app load
  useEffect(() => {
    fetchLiveRates();
  }, []);

  const resetCurrencyRates = () => {
    fetchLiveRates();
  };

  const getVendorById = (id: string) => vendors.find((v) => v.id === id);
  const getContainerById = (id: string) => containers.find((c) => c.id === id);

  const addVendor = (vendorData: Omit<Vendor, 'id' | 'createdAt' | 'totalImportValuePKR' | 'totalPaidPKR' | 'pendingBalancePKR' | 'activeContainersCount' | 'totalContainersCount'>) => {
    const newId = generateUniqueId('ven');
    const newVendor: Vendor = {
      ...vendorData,
      id: newId,
      totalImportValuePKR: 0,
      totalPaidPKR: 0,
      pendingBalancePKR: 0,
      activeContainersCount: 0,
      totalContainersCount: 0,
      createdAt: new Date().toISOString().split('T')[0],
    };

    setVendors((prev) => [newVendor, ...prev]);

    const newAct: ActivityLog = {
      id: generateUniqueId('act'),
      timestamp: new Date().toISOString().replace('T', ' ').slice(0, 16),
      type: 'vendor',
      title: `New Vendor Added: ${newVendor.name}`,
      description: `Registered ${newVendor.country} vendor specializing in ${newVendor.category}.`,
      tag: newVendor.country
    };
    setActivities((prev) => [newAct, ...prev]);
  };

  const updateVendor = (id: string, updates: Partial<Vendor>) => {
    setVendors((prev) =>
      prev.map((v) => (v.id === id ? { ...v, ...updates } : v))
    );
  };

  const deleteVendor = (id: string) => {
    setVendors((prev) => prev.filter((v) => v.id !== id));
  };

  const addContainer = (containerData: Omit<Container, 'id' | 'createdAt' | 'shipmentValuePKR' | 'trackingMilestones'>) => {
    const newId = generateUniqueId('cnt');
    const rate = getCurrencyRate(containerData.currency);
    const valuePKR = containerData.shipmentValue * rate;

    const initialMilestones = [
      { step: 'Factory Dispatch & Staging', location: containerData.portOfLoading, timestamp: `${containerData.shipmentDate} 10:00`, completed: true },
      { step: 'Vessel Departed Origin Port', location: containerData.portOfLoading, timestamp: `${containerData.shipmentDate} 18:00`, completed: true },
      { step: 'In Transit on Sea Route', location: 'High Seas toward Arabian Sea', timestamp: 'En Route', completed: true },
      { step: `Arrival at ${containerData.destinationPort}`, location: containerData.destinationPort, timestamp: `Expected ${containerData.expectedArrival}`, completed: false },
      { step: 'Customs & SITE Warehouse Unload', location: 'DCC Central Warehouse Karachi', timestamp: 'Pending Arrival', completed: false },
    ];

    const newContainer: Container = {
      ...containerData,
      id: newId,
      shipmentValuePKR: valuePKR,
      trackingMilestones: initialMilestones,
      createdAt: new Date().toISOString().split('T')[0],
    };

    setContainers((prev) => [newContainer, ...prev]);

    // Update vendor total import value and container counts
    setVendors((prev) =>
      prev.map((v) => {
        if (v.id === containerData.vendorId) {
          return {
            ...v,
            totalImportValuePKR: v.totalImportValuePKR + valuePKR,
            pendingBalancePKR: v.pendingBalancePKR + valuePKR,
            activeContainersCount: v.activeContainersCount + 1,
            totalContainersCount: v.totalContainersCount + 1,
          };
        }
        return v;
      })
    );

    const newAct: ActivityLog = {
      id: generateUniqueId('act'),
      timestamp: new Date().toISOString().replace('T', ' ').slice(0, 16),
      type: 'container',
      title: `Container Registered: ${newContainer.containerNumber}`,
      description: `Import shipment booked from ${newContainer.vendorName} (${newContainer.originCountry}) - Valued at Rs. ${(valuePKR / 1000000).toFixed(2)}M.`,
      amountPKR: valuePKR,
      tag: newContainer.status
    };
    setActivities((prev) => [newAct, ...prev]);
  };

  const updateContainerStatus = (id: string, newStatus: ContainerStatus, note?: string) => {
    setContainers((prev) =>
      prev.map((c) => {
        if (c.id === id) {
          const nowStr = new Date().toISOString().replace('T', ' ').slice(0, 16);
          const updatedMilestones = [...c.trackingMilestones];
          
          if (newStatus === 'Arrived') {
            c.actualArrival = new Date().toISOString().split('T')[0];
            const milestoneIndex = updatedMilestones.findIndex(m => m.step.includes('Arrival'));
            if (milestoneIndex >= 0) {
              updatedMilestones[milestoneIndex] = {
                ...updatedMilestones[milestoneIndex],
                completed: true,
                timestamp: nowStr,
                notes: note || 'Vessel berthed and manifested at port terminal'
              };
            }
          } else if (newStatus === 'Unloading' || newStatus === 'Unloaded') {
            c.unloadingDate = new Date().toISOString().split('T')[0];
          } else if (newStatus === 'Completed') {
            c.completedDate = new Date().toISOString().split('T')[0];
            // Mark all milestones completed
            updatedMilestones.forEach(m => { m.completed = true; });
          }

          return {
            ...c,
            status: newStatus,
            trackingMilestones: updatedMilestones,
          };
        }
        return c;
      })
    );

    const updated = containers.find((c) => c.id === id);
    if (updated) {
      const newAct: ActivityLog = {
        id: generateUniqueId('act'),
        timestamp: new Date().toISOString().replace('T', ' ').slice(0, 16),
        type: 'container',
        title: `Container ${updated.containerNumber} → ${newStatus}`,
        description: note || `Shipment status updated to ${newStatus}.`,
        amountPKR: updated.shipmentValuePKR,
        tag: newStatus
      };
      setActivities((prev) => [newAct, ...prev]);
    }
  };

  const addPayment = (paymentData: Omit<Payment, 'id' | 'paymentRef' | 'createdAt' | 'amountPKR'>) => {
    const newId = generateUniqueId('pay');
    const refNum = `PAY-2026-${Math.floor(100 + Math.random() * 900)}`;
    const rate = paymentData.exchangeRateToPKR || getCurrencyRate(paymentData.currency);
    const amountPKR = paymentData.amount * rate;

    const newPayment: Payment = {
      ...paymentData,
      id: newId,
      paymentRef: refNum,
      exchangeRateToPKR: rate,
      amountPKR: amountPKR,
      createdAt: new Date().toISOString().split('T')[0],
    };

    setPayments((prev) => [newPayment, ...prev]);

    // If completed, update vendor total paid and pending balance
    if (newPayment.status === 'Completed') {
      setVendors((prev) =>
        prev.map((v) => {
          if (v.id === newPayment.vendorId) {
            const newPaid = v.totalPaidPKR + amountPKR;
            const newPending = Math.max(0, v.totalImportValuePKR - newPaid);
            return {
              ...v,
              totalPaidPKR: newPaid,
              pendingBalancePKR: newPending,
            };
          }
          return v;
        })
      );
    }

    const newAct: ActivityLog = {
      id: generateUniqueId('act'),
      timestamp: new Date().toISOString().replace('T', ' ').slice(0, 16),
      type: 'payment',
      title: `Payment Recorded: ${refNum}`,
      description: `${newPayment.status} payment of ${newPayment.currency} ${newPayment.amount.toLocaleString()} (Rs. ${(amountPKR / 1000000).toFixed(2)}M) to ${newPayment.vendorName}.`,
      amountPKR: amountPKR,
      tag: newPayment.status
    };
    setActivities((prev) => [newAct, ...prev]);
  };

  const updatePaymentStatus = (id: string, newStatus: PaymentStatus) => {
    let paymentToUpdate: Payment | undefined;
    setPayments((prev) =>
      prev.map((p) => {
        if (p.id === id) {
          paymentToUpdate = { ...p, status: newStatus };
          return paymentToUpdate;
        }
        return p;
      })
    );

    if (paymentToUpdate && newStatus === 'Completed') {
      const p = paymentToUpdate;
      setVendors((prev) =>
        prev.map((v) => {
          if (v.id === p.vendorId) {
            const newPaid = v.totalPaidPKR + p.amountPKR;
            const newPending = Math.max(0, v.totalImportValuePKR - newPaid);
            return {
              ...v,
              totalPaidPKR: newPaid,
              pendingBalancePKR: newPending,
            };
          }
          return v;
        })
      );

      const newAct: ActivityLog = {
        id: generateUniqueId('act'),
        timestamp: new Date().toISOString().replace('T', ' ').slice(0, 16),
        type: 'payment',
        title: `Payment Approved: ${p.paymentRef}`,
        description: `Marked as Completed for ${p.vendorName} (Rs. ${(p.amountPKR / 1000000).toFixed(2)}M).`,
        amountPKR: p.amountPKR,
        tag: 'Completed'
      };
      setActivities((prev) => [newAct, ...prev]);
    }
  };

  const resetAllData = () => {
    localStorage.removeItem(STORAGE_KEYS.VENDORS);
    localStorage.removeItem(STORAGE_KEYS.CONTAINERS);
    localStorage.removeItem(STORAGE_KEYS.PAYMENTS);
    localStorage.removeItem(STORAGE_KEYS.CURRENCIES);
    localStorage.removeItem(STORAGE_KEYS.ACTIVITIES);
    setVendors(INITIAL_VENDORS);
    setContainers(INITIAL_CONTAINERS);
    setPayments(INITIAL_PAYMENTS);
    setCurrencies(INITIAL_CURRENCIES);
    setActivities(INITIAL_ACTIVITY_LOGS);
  };

  return (
    <AppContext.Provider
      value={{
        activeModule,
        setActiveModule,
        selectedVendorId,
        setSelectedVendorId,
        selectedContainerId,
        setSelectedContainerId,
        isAuthenticated,
        currentUser,
        login,
        logout,
        switchUser,
        availableUsers: INITIAL_USERS,
        globalSearch,
        setGlobalSearch,
        vendors,
        containers,
        payments,
        currencies,
        activities,
        convertAmount,
        updateCurrencyRate,
        resetCurrencyRates,
        fetchLiveRates,
        isFetchingRates,
        lastRatesUpdated,
        rateProvider,
        isLiveRates,
        addVendor,
        updateVendor,
        deleteVendor,
        getVendorById,
        addContainer,
        updateContainerStatus,
        getContainerById,
        addPayment,
        updatePaymentStatus,
        isAddVendorOpen,
        setIsAddVendorOpen,
        isAddPaymentOpen,
        setIsAddPaymentOpen,
        isAddContainerOpen,
        setIsAddContainerOpen,
        isVendorDetailsOpen,
        setIsVendorDetailsOpen,
        isContainerDetailsOpen,
        setIsContainerDetailsOpen,
        isMobileSidebarOpen,
        setIsMobileSidebarOpen,
        resetAllData,
      }}
    >
      {children}
    </AppContext.Provider>
  );
};

export const useApp = (): AppContextType => {
  const context = useContext(AppContext);
  if (!context) {
    throw new Error('useApp must be used within an AppProvider');
  }
  return context;
};
