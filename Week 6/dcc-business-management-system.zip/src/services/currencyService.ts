import { CurrencyCode, CurrencyInfo } from '../types';
import { INITIAL_CURRENCIES } from '../data/mockData';

export interface LiveRatesResponse {
  ratesToPKR: Record<CurrencyCode, number>;
  lastUpdated: string;
  provider: string;
  isLive: boolean;
}

// Fallback rates if network/API is offline
const FALLBACK_RATES: Record<CurrencyCode, number> = {
  PKR: 1,
  CNY: 38.65,
  AED: 76.10,
  SAR: 74.40,
  QAR: 76.55,
  KWD: 909.50,
  BHD: 740.20,
  OMR: 724.80,
  USD: 279.40,
};

const API_ENDPOINTS = [
  'https://open.er-api.com/v6/latest/USD',
  'https://api.exchangerate-api.com/v4/latest/USD',
  'https://cdn.jsdelivr.net/npm/@fawazahmed0/currency-api@latest/v1/currencies/usd.json',
];

/**
 * Fetch real-time live currency exchange rates from public forex APIs
 */
export async function fetchLiveExchangeRates(): Promise<LiveRatesResponse> {
  // Try Open.er-api first
  try {
    const response = await fetch('https://open.er-api.com/v6/latest/USD', {
      headers: { Accept: 'application/json' },
    });

    if (response.ok) {
      const data = await response.json();
      if (data && data.rates && data.rates.PKR) {
        const usdToPKR = Number(data.rates.PKR);
        const rates = data.rates;

        const calculatedRatesToPKR: Record<CurrencyCode, number> = {
          PKR: 1,
          CNY: rates.CNY ? parseFloat((usdToPKR / Number(rates.CNY)).toFixed(4)) : FALLBACK_RATES.CNY,
          AED: rates.AED ? parseFloat((usdToPKR / Number(rates.AED)).toFixed(4)) : FALLBACK_RATES.AED,
          SAR: rates.SAR ? parseFloat((usdToPKR / Number(rates.SAR)).toFixed(4)) : FALLBACK_RATES.SAR,
          QAR: rates.QAR ? parseFloat((usdToPKR / Number(rates.QAR)).toFixed(4)) : FALLBACK_RATES.QAR,
          KWD: rates.KWD ? parseFloat((usdToPKR / Number(rates.KWD)).toFixed(4)) : FALLBACK_RATES.KWD,
          BHD: rates.BHD ? parseFloat((usdToPKR / Number(rates.BHD)).toFixed(4)) : FALLBACK_RATES.BHD,
          OMR: rates.OMR ? parseFloat((usdToPKR / Number(rates.OMR)).toFixed(4)) : FALLBACK_RATES.OMR,
          USD: parseFloat(usdToPKR.toFixed(4)),
        };

        const lastUpdated = data.time_last_update_utc
          ? new Date(data.time_last_update_utc).toLocaleString('en-PK', {
              dateStyle: 'medium',
              timeStyle: 'short',
            })
          : new Date().toLocaleTimeString();

        return {
          ratesToPKR: calculatedRatesToPKR,
          lastUpdated,
          provider: 'Open Exchange Forex API (Live)',
          isLive: true,
        };
      }
    }
  } catch (error) {
    console.warn('Primary exchange rate API failed, attempting secondary API...', error);
  }

  // Secondary API: api.exchangerate-api.com
  try {
    const response = await fetch('https://api.exchangerate-api.com/v4/latest/USD');
    if (response.ok) {
      const data = await response.json();
      if (data && data.rates && data.rates.PKR) {
        const usdToPKR = Number(data.rates.PKR);
        const rates = data.rates;

        const calculatedRatesToPKR: Record<CurrencyCode, number> = {
          PKR: 1,
          CNY: rates.CNY ? parseFloat((usdToPKR / Number(rates.CNY)).toFixed(4)) : FALLBACK_RATES.CNY,
          AED: rates.AED ? parseFloat((usdToPKR / Number(rates.AED)).toFixed(4)) : FALLBACK_RATES.AED,
          SAR: rates.SAR ? parseFloat((usdToPKR / Number(rates.SAR)).toFixed(4)) : FALLBACK_RATES.SAR,
          QAR: rates.QAR ? parseFloat((usdToPKR / Number(rates.QAR)).toFixed(4)) : FALLBACK_RATES.QAR,
          KWD: rates.KWD ? parseFloat((usdToPKR / Number(rates.KWD)).toFixed(4)) : FALLBACK_RATES.KWD,
          BHD: rates.BHD ? parseFloat((usdToPKR / Number(rates.BHD)).toFixed(4)) : FALLBACK_RATES.BHD,
          OMR: rates.OMR ? parseFloat((usdToPKR / Number(rates.OMR)).toFixed(4)) : FALLBACK_RATES.OMR,
          USD: parseFloat(usdToPKR.toFixed(4)),
        };

        return {
          ratesToPKR: calculatedRatesToPKR,
          lastUpdated: new Date().toLocaleString('en-PK', {
            dateStyle: 'medium',
            timeStyle: 'short',
          }),
          provider: 'ExchangeRate-API Live Feed',
          isLive: true,
        };
      }
    }
  } catch (secError) {
    console.warn('Secondary exchange rate API failed...', secError);
  }

  // Fallback to local stored/static rates
  return {
    ratesToPKR: FALLBACK_RATES,
    lastUpdated: new Date().toLocaleString('en-PK', {
      dateStyle: 'medium',
      timeStyle: 'short',
    }) + ' (Offline Cache)',
    provider: 'SBP / DCC Standard Reference',
    isLive: false,
  };
}
