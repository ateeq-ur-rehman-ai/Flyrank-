import React, { useState } from 'react';
import {
  Ship,
  Container as ContainerIcon,
  Anchor,
  Box,
  CheckCircle2,
  Clock,
  MapPin,
  Calendar,
  Search,
  Filter,
  Plus,
  ArrowRight,
  TrendingUp,
  FileText,
  AlertCircle,
  ExternalLink,
} from 'lucide-react';
import { motion } from 'motion/react';
import { useApp } from '../../context/AppContext';
import { ContainerStatus, Country } from '../../types';
import { formatPKR, formatCurrency, formatDate, getContainerStatusBadge, getDaysUntil } from '../../utils/formatters';

export const ContainersModule: React.FC = () => {
  const {
    containers,
    setSelectedContainerId,
    setIsContainerDetailsOpen,
    setIsAddContainerOpen,
    globalSearch,
  } = useApp();

  const [statusFilter, setStatusFilter] = useState<'ALL' | ContainerStatus>('ALL');
  const [countryFilter, setCountryFilter] = useState<'ALL' | Country>('ALL');
  const [localSearch, setLocalSearch] = useState('');

  const activeSearch = (globalSearch || localSearch).toLowerCase();

  // Filtered containers list
  const filteredContainers = containers.filter((c) => {
    const matchesStatus = statusFilter === 'ALL' || c.status === statusFilter;
    const matchesCountry = countryFilter === 'ALL' || c.originCountry === countryFilter;
    const matchesSearch =
      c.containerNumber.toLowerCase().includes(activeSearch) ||
      c.blNumber.toLowerCase().includes(activeSearch) ||
      c.vendorName.toLowerCase().includes(activeSearch) ||
      c.vesselName.toLowerCase().includes(activeSearch) ||
      c.portOfLoading.toLowerCase().includes(activeSearch) ||
      c.destinationPort.toLowerCase().includes(activeSearch) ||
      c.cargoDescription.toLowerCase().includes(activeSearch);
    return matchesStatus && matchesCountry && matchesSearch;
  });

  // Aggregates
  const totalContainers = containers.length;
  const inTransit = containers.filter((c) => c.status === 'In Transit');
  const arrived = containers.filter((c) => c.status === 'Arrived');
  const unloading = containers.filter((c) => c.status === 'Unloading');
  const unloaded = containers.filter((c) => c.status === 'Unloaded');
  const completed = containers.filter((c) => c.status === 'Completed');

  const totalCargoValuePKR = containers.reduce((acc, c) => acc + c.shipmentValuePKR, 0);

  return (
    <motion.div
      initial={{ opacity: 0, y: 10 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.25, ease: 'easeOut' }}
      className="p-3.5 sm:p-5 md:p-6 space-y-4 sm:space-y-6 max-w-7xl mx-auto"
    >
      {/* Top Metrics Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3 sm:gap-4">
        <motion.div
          whileHover={{ y: -2 }}
          className="bg-white border border-stone-200 rounded-2xl p-4 sm:p-5 shadow-sm"
        >
          <div className="flex items-center justify-between text-xs text-stone-500 font-mono uppercase tracking-wider mb-1.5">
            <span>Total Containers</span>
            <ContainerIcon className="w-4 h-4 text-stone-700" />
          </div>
          <div className="text-2xl sm:text-3xl font-bold text-stone-900 font-mono-num">
            {totalContainers}
          </div>
          <p className="text-xs text-stone-500 mt-2 font-mono">
            Value: <strong className="text-stone-800 font-mono-num">{formatPKR(totalCargoValuePKR, true)}</strong>
          </p>
        </motion.div>

        <motion.div
          whileHover={{ y: -2 }}
          className="bg-white border border-stone-200 rounded-2xl p-4 sm:p-5 shadow-sm"
        >
          <div className="flex items-center justify-between text-xs text-stone-500 font-mono uppercase tracking-wider mb-1.5">
            <span>In Transit</span>
            <Ship className="w-4 h-4 text-stone-700" />
          </div>
          <div className="text-2xl sm:text-3xl font-bold text-amber-800 font-mono-num">
            {inTransit.length} Shipments
          </div>
          <p className="text-xs text-stone-500 mt-2">
            En route to Karachi
          </p>
        </motion.div>

        <motion.div
          whileHover={{ y: -2 }}
          className="bg-white border border-stone-200 rounded-2xl p-4 sm:p-5 shadow-sm"
        >
          <div className="flex items-center justify-between text-xs text-stone-500 font-mono uppercase tracking-wider mb-1.5">
            <span>At Port</span>
            <Anchor className="w-4 h-4 text-stone-700" />
          </div>
          <div className="text-2xl sm:text-3xl font-bold text-stone-900 font-mono-num">
            {arrived.length} Berthed
          </div>
          <p className="text-xs text-stone-500 mt-2 font-mono">
            KPT & Port Qasim
          </p>
        </motion.div>

        <motion.div
          whileHover={{ y: -2 }}
          className="bg-white border border-stone-200 rounded-2xl p-4 sm:p-5 shadow-sm"
        >
          <div className="flex items-center justify-between text-xs text-stone-500 font-mono uppercase tracking-wider mb-1.5">
            <span>Unloading</span>
            <Box className="w-4 h-4 text-stone-700" />
          </div>
          <div className="text-2xl sm:text-3xl font-bold text-stone-900 font-mono-num">
            {unloading.length + unloaded.length} Containers
          </div>
          <p className="text-xs text-stone-500 mt-2">
            Warehouse receiving & QC
          </p>
        </motion.div>
      </div>

      {/* Main Containers Controls & List */}
      <div className="bg-white border border-stone-200 rounded-xl p-4 sm:p-5 shadow-sm space-y-4">
        {/* Header with Search & Add Container */}
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 sm:gap-4 border-b border-stone-100 pb-4">
          <div>
            <h3 className="text-base font-bold text-stone-900 flex items-center gap-2">
              <Ship className="w-4 h-4 text-stone-700" />
              Containers & Shipments
            </h3>
            <p className="text-xs text-stone-500 mt-0.5">
              Track vessel shipments, port arrivals, and unloading status
            </p>
          </div>

          <div className="flex items-center gap-2">
            <button
              id="btn-add-container-modal"
              onClick={() => setIsAddContainerOpen(true)}
              className="px-3.5 py-2 bg-gradient-to-r from-amber-600 to-amber-700 hover:from-amber-500 hover:to-amber-600 text-white text-xs font-bold rounded-xl flex items-center gap-1.5 transition-all shadow-sm"
            >
              <Plus className="w-3.5 h-3.5" />
              <span>Add Container</span>
            </button>
          </div>
        </div>

        {/* Filter Bar */}
        <div className="flex flex-wrap items-center justify-between gap-3 pt-1">
          {/* Status Tabs */}
          <div className="flex flex-wrap items-center gap-1.5">
            <span className="text-xs font-mono font-semibold text-stone-500 mr-1">Status:</span>
            {[
              { id: 'ALL', label: `All (${totalContainers})` },
              { id: 'In Transit', label: `In Transit (${inTransit.length})` },
              { id: 'Arrived', label: `Arrived (${arrived.length})` },
              { id: 'Unloading', label: `Unloading (${unloading.length})` },
              { id: 'Unloaded', label: `Unloaded (${unloaded.length})` },
              { id: 'Completed', label: `Completed (${completed.length})` },
            ].map((tab) => (
              <button
                key={tab.id}
                onClick={() => setStatusFilter(tab.id as any)}
                className={`px-3 py-1 rounded-lg text-xs font-medium transition-colors ${
                  statusFilter === tab.id
                    ? 'bg-[#1C1917] text-white font-bold'
                    : 'bg-stone-100 text-stone-600 hover:text-stone-900'
                }`}
              >
                {tab.label}
              </button>
            ))}
          </div>

          {/* Local search */}
          <div className="relative w-full sm:w-64">
            <Search className="w-3.5 h-3.5 text-stone-400 absolute left-3 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              value={localSearch}
              onChange={(e) => setLocalSearch(e.target.value)}
              placeholder="Search container, BL, vendor..."
              className="w-full pl-8 pr-3 py-1.5 text-xs bg-stone-50 border border-stone-300 rounded-lg text-stone-900 placeholder-stone-400 focus:outline-none focus:border-stone-800"
            />
          </div>
        </div>

        {/* Containers Table */}
        <div className="overflow-x-auto rounded-xl border border-stone-200 mt-2">
          <table className="w-full text-left text-xs bg-white min-w-[700px]">
            <thead className="bg-stone-100 text-stone-700 font-mono text-[11px] border-b border-stone-200">
              <tr>
                <th className="py-3 px-3">Container #</th>
                <th className="py-3 px-3">Vendor / Origin</th>
                <th className="py-3 px-3">Status</th>
                <th className="py-3 px-3">Shipment Date</th>
                <th className="py-3 px-3">Expected Arrival</th>
                <th className="py-3 px-3">Actual / Unload</th>
                <th className="py-3 px-3">Value</th>
                <th className="py-3 px-3">Cargo Details</th>
                <th className="py-3 px-3 text-right">Action</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-stone-100">
              {filteredContainers.map((c) => {
                const badge = getContainerStatusBadge(c.status);
                const etaInfo = getDaysUntil(c.expectedArrival);

                return (
                  <tr
                    key={c.id}
                    id={`container-row-${c.id}`}
                    onClick={() => {
                      setSelectedContainerId(c.id);
                      setIsContainerDetailsOpen(true);
                    }}
                    className="hover:bg-stone-50/80 transition-colors cursor-pointer group"
                  >
                    {/* Container # & BL */}
                    <td className="py-3 px-3 whitespace-nowrap">
                      <div className="font-mono font-bold text-stone-900 group-hover:text-amber-900 transition-colors flex items-center gap-1.5">
                        <ContainerIcon className="w-3.5 h-3.5 text-stone-600" />
                        {c.containerNumber}
                      </div>
                      <span className="text-[10px] text-stone-400 block font-mono">
                        BL: {c.blNumber}
                      </span>
                    </td>

                    {/* Vendor & Origin */}
                    <td className="py-3 px-3">
                      <p className="font-semibold text-stone-900 truncate max-w-[170px]">
                        {c.vendorName}
                      </p>
                      <p className="text-[11px] text-stone-500 font-mono flex items-center gap-1 mt-0.5">
                        <span>{c.originCountry}</span> • <span>{c.portOfLoading.split('(')[0]}</span>
                      </p>
                    </td>

                    {/* Status Badge */}
                    <td className="py-3 px-3 whitespace-nowrap">
                      <span className={`inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full text-[11px] font-bold border ${badge.bg} ${badge.border}`}>
                        <span className={`w-1.5 h-1.5 rounded-full ${badge.dot}`}></span>
                        {badge.text}
                      </span>
                    </td>

                    {/* Shipment Date */}
                    <td className="py-3 px-3 whitespace-nowrap text-stone-700 font-mono">
                      {formatDate(c.shipmentDate)}
                    </td>

                    {/* Expected Arrival */}
                    <td className="py-3 px-3 whitespace-nowrap">
                      <span className="text-stone-900 font-mono font-semibold block">
                        {formatDate(c.expectedArrival)}
                      </span>
                      {c.status === 'In Transit' && (
                        <span className="text-[10px] text-amber-800 font-mono font-medium block">
                          {etaInfo.text}
                        </span>
                      )}
                    </td>

                    {/* Actual / Unloading Date */}
                    <td className="py-3 px-3 whitespace-nowrap text-stone-700 font-mono">
                      {c.unloadingDate ? (
                        <div>
                          <span className="text-stone-900 font-semibold block">
                            {formatDate(c.unloadingDate)}
                          </span>
                          <span className="text-[10px] text-stone-500">Unloaded</span>
                        </div>
                      ) : c.actualArrival ? (
                        <div>
                          <span className="text-amber-800 font-semibold block">
                            {formatDate(c.actualArrival)}
                          </span>
                          <span className="text-[10px] text-stone-500">Berthed</span>
                        </div>
                      ) : (
                        <span className="text-stone-400">—</span>
                      )}
                    </td>

                    {/* Shipment Value */}
                    <td className="py-3 px-3 whitespace-nowrap">
                      <span className="font-bold text-stone-900 font-mono-num block">
                        {formatPKR(c.shipmentValuePKR, true)}
                      </span>
                      <span className="text-[10px] text-stone-500 font-mono-num">
                        {formatCurrency(c.shipmentValue, c.currency)}
                      </span>
                    </td>

                    {/* Cargo info */}
                    <td className="py-3 px-3 max-w-[200px]">
                      <p className="text-stone-800 truncate" title={c.cargoDescription}>
                        {c.cargoDescription}
                      </p>
                      <p className="text-[10px] text-stone-500 font-mono">
                        {c.containerSize} • {c.packagesCount} Cartons
                      </p>
                    </td>

                    {/* Action */}
                    <td className="py-3 px-3 text-right whitespace-nowrap">
                      <button
                        onClick={(e) => {
                          e.stopPropagation();
                          setSelectedContainerId(c.id);
                          setIsContainerDetailsOpen(true);
                        }}
                        className="px-3 py-1 bg-stone-100 hover:bg-[#1C1917] hover:text-amber-100 text-stone-800 rounded-lg text-xs font-semibold transition-colors border border-stone-200"
                      >
                        Details
                      </button>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>

        {filteredContainers.length === 0 && (
          <div className="p-12 text-center text-stone-500">
            <ContainerIcon className="w-8 h-8 text-stone-400 mx-auto mb-2" />
            <p className="text-sm font-semibold">No containers found.</p>
          </div>
        )}

        {/* Visual Shipment Timeline Demo Bar */}
        <div className="mt-6 pt-4 border-t border-stone-200 bg-stone-50/70 p-4 rounded-xl">
          <div className="flex items-center justify-between mb-3">
            <span className="text-xs font-bold text-stone-800 uppercase tracking-wider flex items-center gap-1.5">
              <Clock className="w-3.5 h-3.5 text-stone-600" /> Shipment Lifecycle
            </span>
            <span className="text-[11px] text-stone-500 font-mono">Factory → High Seas → Port Berth → Warehouse</span>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-5 gap-2 text-center text-xs">
            <div className="p-2.5 rounded-lg bg-white border border-stone-200 text-stone-800 shadow-2xs">
              <span className="text-[10px] font-mono font-bold text-amber-800 block mb-0.5">STAGE 1</span>
              <p className="font-semibold">Factory Dispatch</p>
              <p className="text-[10px] text-stone-500">Stuffing & Gate-In</p>
            </div>
            <div className="p-2.5 rounded-lg bg-white border border-stone-200 text-stone-800 shadow-2xs">
              <span className="text-[10px] font-mono font-bold text-amber-800 block mb-0.5">STAGE 2</span>
              <p className="font-semibold">High Seas</p>
              <p className="text-[10px] text-stone-500">In transit (12-18d)</p>
            </div>
            <div className="p-2.5 rounded-lg bg-white border border-stone-200 text-stone-800 shadow-2xs">
              <span className="text-[10px] font-mono font-bold text-amber-800 block mb-0.5">STAGE 3</span>
              <p className="font-semibold">Port Arrival</p>
              <p className="text-[10px] text-stone-500">KPT / Port Qasim</p>
            </div>
            <div className="p-2.5 rounded-lg bg-white border border-stone-200 text-stone-800 shadow-2xs">
              <span className="text-[10px] font-mono font-bold text-amber-800 block mb-0.5">STAGE 4</span>
              <p className="font-semibold">Clearance</p>
              <p className="text-[10px] text-stone-500">Duty & Gate Out</p>
            </div>
            <div className="p-2.5 rounded-lg bg-white border border-stone-200 text-stone-800 shadow-2xs">
              <span className="text-[10px] font-mono font-bold text-emerald-800 block mb-0.5">STAGE 5</span>
              <p className="font-semibold">Unloaded</p>
              <p className="text-[10px] text-stone-500">QC verified</p>
            </div>
          </div>
        </div>
      </div>
    </motion.div>
  );
};
