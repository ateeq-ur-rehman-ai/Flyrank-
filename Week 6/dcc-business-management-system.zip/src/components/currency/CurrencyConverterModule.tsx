import React, { useState } from 'react';
import {
  ArrowRightLeft,
  Coins,
  TrendingUp,
  RefreshCw,
  Edit2,
  Check,
  Calculator,
  ShieldCheck,
  DollarSign,
  HelpCircle,
  Sparkles,
  ArrowRight,
  Globe,
  Clock,
  Radio,
  CheckCircle2,
} from 'lucide-react';
import { useApp } from '../../context/AppContext';
import { CurrencyCode, CurrencyInfo } from '../../types';
import { formatPKR, formatCurrency } from '../../utils/formatters';

export const CurrencyConverterModule: React.FC = () => {
  const {
    currencies,
    updateCurrencyRate,
    fetchLiveRates,
    isFetchingRates,
    lastRatesUpdated,
    rateProvider,
    isLiveRates,
  } = useApp();

  // Instant Converter State
  const [sourceCurrency, setSourceCurrency] = useState<CurrencyCode>('CNY');
  const [sourceAmount, setSourceAmount] = useState<string>('50000');
  const [targetCurrency, setTargetCurrency] = useState<CurrencyCode>('PKR');

  // Rate Editor Modal / Inline State
  const [editingCurrency, setEditingCurrency] = useState<CurrencyCode | null>(null);
  const [editRateInput, setEditRateInput] = useState<string>('');

  // Quick Container Cost Simulator State
  const [calcCargoCurrency, setCalcCargoCurrency] = useState<CurrencyCode>('CNY');
  const [calcCargoAmount, setCalcCargoAmount] = useState<string>('300000');
  const [calcFreightUSD, setCalcFreightUSD] = useState<string>('2400');
  const [calcCustomsDutyPKR, setCalcCustomsDutyPKR] = useState<string>('2100000');

  // Currency lookup
  const getRate = (code: CurrencyCode): number => {
    const c = currencies.find((curr) => curr.code === code);
    return c ? c.rateToPKR : 1;
  };

  const parsedAmount = parseFloat(sourceAmount) || 0;
  const sourceRate = getRate(sourceCurrency);
  const targetRate = getRate(targetCurrency);

  // Conversion: convert source to PKR, then PKR to target
  const convertedInPKR = parsedAmount * sourceRate;
  const targetAmount = convertedInPKR / targetRate;

  // Swap currencies
  const handleSwap = () => {
    const prevSource = sourceCurrency;
    setSourceCurrency(targetCurrency);
    setTargetCurrency(prevSource);
  };

  // Quick Landed Cost Calculation
  const cargoPKR = (parseFloat(calcCargoAmount) || 0) * getRate(calcCargoCurrency);
  const freightPKR = (parseFloat(calcFreightUSD) || 0) * getRate('USD');
  const dutyPKR = parseFloat(calcCustomsDutyPKR) || 0;
  const totalLandedPKR = cargoPKR + freightPKR + dutyPKR;

  const handleSaveRate = (currency: CurrencyCode) => {
    const num = parseFloat(editRateInput);
    if (!isNaN(num) && num > 0) {
      updateCurrencyRate(currency, num);
    }
    setEditingCurrency(null);
  };

  // Key Trade Currencies for quick cards
  const tradeCurrencies: { code: CurrencyCode; label: string; sub: string }[] = [
    { code: 'CNY', label: 'Chinese Yuan', sub: 'Fabric & Mill Imports' },
    { code: 'AED', label: 'UAE Dirham', sub: 'Dubai & Sharjah Wholesale' },
    { code: 'USD', label: 'US Dollar', sub: 'Sea Freight & Global TT' },
    { code: 'SAR', label: 'Saudi Riyal', sub: 'Riyadh & Jeddah Trade' },
  ];

  return (
    <div className="p-4 sm:p-6 space-y-6 max-w-7xl mx-auto">
      {/* Top Banner with Real-Time API Status */}
      <div className="bg-white border border-stone-200 rounded-2xl p-4 sm:p-6 text-stone-900 flex flex-col md:flex-row md:items-center justify-between gap-4 shadow-sm">
        <div>
          <div className="flex flex-wrap items-center gap-2 mb-1.5">
            <span className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full bg-emerald-50 text-emerald-800 text-xs font-bold border border-emerald-200">
              <span className="relative flex h-2 w-2">
                <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75"></span>
                <span className="relative inline-flex rounded-full h-2 w-2 bg-emerald-600"></span>
              </span>
              Real-Time Forex API Live
            </span>
            <span className="text-xs text-stone-500 font-medium flex items-center gap-1">
              <Globe className="w-3.5 h-3.5 text-stone-400" />
              {rateProvider}
            </span>
          </div>
          
          <h2 className="text-xl sm:text-2xl font-bold text-stone-900 tracking-tight">
            Live Currency Converter & Forex Rates
          </h2>
          <p className="text-xs text-stone-600 mt-1 flex items-center gap-1.5">
            <Clock className="w-3.5 h-3.5 text-stone-400" />
            Last synced from live market: <span className="font-semibold text-stone-800">{lastRatesUpdated}</span>
          </p>
        </div>

        <div className="flex items-center gap-2.5 self-start md:self-auto">
          <button
            id="btn-sync-live-rates"
            onClick={fetchLiveRates}
            disabled={isFetchingRates}
            className="px-4 py-2.5 bg-[#1C1917] hover:bg-[#292524] disabled:bg-stone-300 text-amber-50 text-xs font-bold rounded-xl border border-stone-800 flex items-center gap-2 transition-all shadow-sm active:scale-95 cursor-pointer"
          >
            <RefreshCw className={`w-3.5 h-3.5 text-amber-300 ${isFetchingRates ? 'animate-spin' : ''}`} />
            <span>{isFetchingRates ? 'Fetching Live Rates...' : 'Sync Live Rates'}</span>
          </button>
        </div>
      </div>

      {/* 4 Quick Key Trade Currencies Cards */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3 sm:gap-4">
        {tradeCurrencies.map((tc) => {
          const curr = currencies.find((c) => c.code === tc.code);
          const rate = curr ? curr.rateToPKR : 1;
          const isSelected = sourceCurrency === tc.code;

          return (
            <div
              key={tc.code}
              onClick={() => {
                setSourceCurrency(tc.code);
                setTargetCurrency('PKR');
              }}
              className={`p-4 rounded-2xl border transition-all cursor-pointer relative overflow-hidden group ${
                isSelected
                  ? 'bg-amber-50/70 border-amber-500/80 shadow-sm ring-1 ring-amber-500/40'
                  : 'bg-white border-stone-200 hover:border-stone-300 hover:shadow-xs'
              }`}
            >
              <div className="flex items-center justify-between">
                <span className="text-2xl">{curr?.flag}</span>
                <span className="text-[10px] font-bold uppercase tracking-wider px-2 py-0.5 rounded bg-stone-100 text-stone-700">
                  {tc.code} / PKR
                </span>
              </div>

              <div className="mt-2.5">
                <span className="text-xs text-stone-500 font-medium block">{tc.label}</span>
                <div className="text-lg sm:text-xl font-bold text-stone-900 font-mono-num mt-0.5">
                  Rs. {rate.toFixed(2)}
                </div>
                <span className="text-[11px] text-stone-400 block mt-0.5 truncate">{tc.sub}</span>
              </div>

              <div className="mt-3 pt-2.5 border-t border-stone-100 flex items-center justify-between text-[11px]">
                <span className="text-stone-500 font-medium">10,000 {tc.code}</span>
                <span className="font-bold text-emerald-800 font-mono-num">
                  {formatPKR(rate * 10000)}
                </span>
              </div>
            </div>
          );
        })}
      </div>

      {/* Main Converter & Landed Cost Simulator */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-4 sm:gap-6">
        {/* Interactive Instant Converter (7 cols) */}
        <div className="lg:col-span-7 bg-white border border-stone-200 rounded-2xl p-4 sm:p-6 shadow-sm space-y-5">
          <div className="flex items-center justify-between border-b border-stone-100 pb-3">
            <h3 className="text-base font-bold text-stone-900 flex items-center gap-2">
              <Coins className="w-4 h-4 text-stone-700" />
              Live Conversion Calculator
            </h3>
            <span className="text-[11px] text-emerald-800 font-semibold flex items-center gap-1 bg-emerald-50 px-2.5 py-0.5 rounded-full border border-emerald-200">
              <CheckCircle2 className="w-3 h-3 text-emerald-600" />
              Real Live Rates Active
            </span>
          </div>

          <div className="space-y-4">
            {/* Source Input */}
            <div>
              <label className="block text-xs font-semibold text-stone-600 mb-1.5">
                Amount to Convert:
              </label>
              <div className="flex rounded-xl overflow-hidden border border-stone-300 bg-stone-50 focus-within:border-stone-800 focus-within:ring-1 focus-within:ring-stone-800 transition-all">
                <input
                  id="converter-source-amount"
                  type="number"
                  value={sourceAmount}
                  onChange={(e) => setSourceAmount(e.target.value)}
                  placeholder="Enter amount..."
                  className="flex-1 px-4 py-3 text-xl font-bold text-stone-900 bg-transparent placeholder-stone-400 focus:outline-none font-mono-num"
                />
                <select
                  id="converter-source-currency"
                  value={sourceCurrency}
                  onChange={(e) => setSourceCurrency(e.target.value as CurrencyCode)}
                  className="px-4 py-3 bg-stone-100 text-stone-800 font-bold text-sm border-l border-stone-300 focus:outline-none cursor-pointer hover:bg-stone-200 transition-colors"
                >
                  {currencies.map((c) => (
                    <option key={c.code} value={c.code} className="bg-white text-stone-900">
                      {c.flag} {c.code} ({c.name})
                    </option>
                  ))}
                </select>
              </div>
            </div>

            {/* Swap Button & Rate Info */}
            <div className="flex items-center justify-between py-1">
              <div className="text-xs text-stone-500 font-medium">
                <span>Real-Time Market Rate: </span>
                <strong className="text-stone-800 font-mono-num">
                  1 {sourceCurrency} = {(sourceRate / targetRate).toFixed(4)} {targetCurrency}
                </strong>
              </div>

              <button
                id="btn-swap-currencies"
                onClick={handleSwap}
                className="p-2.5 rounded-xl bg-stone-100 hover:bg-[#1C1917] hover:text-white text-stone-700 transition-all shadow-xs border border-stone-200 cursor-pointer"
                title="Swap Currencies"
              >
                <ArrowRightLeft className="w-4 h-4" />
              </button>
            </div>

            {/* Target Output */}
            <div>
              <label className="block text-xs font-semibold text-stone-600 mb-1.5">
                Converted Amount ({targetCurrency}):
              </label>
              <div className="flex rounded-xl overflow-hidden border border-amber-700/40 bg-amber-50/50 shadow-inner">
                <div className="flex-1 px-4 py-3.5 flex items-center">
                  <span className="text-2xl sm:text-3xl font-bold text-amber-900 font-mono-num">
                    {targetCurrency === 'PKR'
                      ? formatPKR(targetAmount)
                      : formatCurrency(targetAmount, targetCurrency)}
                  </span>
                </div>
                <select
                  id="converter-target-currency"
                  value={targetCurrency}
                  onChange={(e) => setTargetCurrency(e.target.value as CurrencyCode)}
                  className="px-4 py-3.5 bg-amber-100/90 text-amber-950 font-bold text-sm border-l border-amber-300/70 focus:outline-none cursor-pointer"
                >
                  {currencies.map((c) => (
                    <option key={c.code} value={c.code} className="bg-white text-stone-900">
                      {c.flag} {c.code}
                    </option>
                  ))}
                </select>
              </div>
            </div>

            {/* Quick Currency Shortcuts */}
            <div className="pt-2">
              <span className="text-[11px] font-semibold text-stone-500 block mb-2">
                Common Import Invoice Presets:
              </span>
              <div className="flex flex-wrap gap-2">
                {[
                  { label: '50,000 CNY (China Fabric)', amount: '50000', curr: 'CNY' },
                  { label: '100,000 AED (Dubai Wholesale)', amount: '100000', curr: 'AED' },
                  { label: '25,000 USD (Vessel Freight)', amount: '25000', curr: 'USD' },
                  { label: '75,000 SAR (Saudi Nida)', amount: '75000', curr: 'SAR' },
                  { label: '5,000 KWD (Kuwait Fabric)', amount: '5000', curr: 'KWD' },
                ].map((preset, idx) => (
                  <button
                    key={idx}
                    onClick={() => {
                      setSourceAmount(preset.amount);
                      setSourceCurrency(preset.curr as CurrencyCode);
                      setTargetCurrency('PKR');
                    }}
                    className="px-3 py-1.5 bg-stone-100 hover:bg-stone-200 text-stone-700 rounded-lg border border-stone-200 transition-colors text-xs font-medium cursor-pointer"
                  >
                    {preset.label}
                  </button>
                ))}
              </div>
            </div>
          </div>
        </div>

        {/* Landed Cost Estimator for DCC Containers (5 cols) */}
        <div className="lg:col-span-5 bg-white border border-stone-200 rounded-2xl p-4 sm:p-6 shadow-sm flex flex-col justify-between space-y-4">
          <div>
            <div className="flex items-center justify-between border-b border-stone-100 pb-3 mb-4">
              <h3 className="text-base font-bold text-stone-900 flex items-center gap-2">
                <Calculator className="w-4 h-4 text-stone-700" />
                Container Landed Cost Estimator
              </h3>
              <span className="text-[11px] text-stone-500 font-medium">Karachi Port</span>
            </div>

            <div className="space-y-3.5">
              {/* Goods Amount */}
              <div>
                <label className="block text-xs font-medium text-stone-600 mb-1">
                  1. Goods Value (FOB / Invoice):
                </label>
                <div className="flex rounded-xl overflow-hidden border border-stone-300 bg-stone-50">
                  <input
                    type="number"
                    value={calcCargoAmount}
                    onChange={(e) => setCalcCargoAmount(e.target.value)}
                    className="flex-1 px-3 py-2 text-xs font-bold text-stone-900 bg-transparent font-mono-num"
                  />
                  <select
                    value={calcCargoCurrency}
                    onChange={(e) => setCalcCargoCurrency(e.target.value as CurrencyCode)}
                    className="px-3 py-2 bg-stone-100 text-xs font-bold text-stone-800 border-l border-stone-300 cursor-pointer"
                  >
                    <option value="CNY">¥ CNY</option>
                    <option value="AED">AED</option>
                    <option value="USD">$ USD</option>
                    <option value="SAR">SAR</option>
                  </select>
                </div>
                <span className="text-[11px] text-amber-900 mt-1 block font-mono-num font-medium">
                  = {formatPKR(cargoPKR)} (Live: Rs. {getRate(calcCargoCurrency).toFixed(2)}/{calcCargoCurrency})
                </span>
              </div>

              {/* Sea Freight */}
              <div>
                <label className="block text-xs font-medium text-stone-600 mb-1">
                  2. Shipping Line Sea Freight (USD):
                </label>
                <div className="flex rounded-xl overflow-hidden border border-stone-300 bg-stone-50">
                  <span className="px-3 py-2 text-xs text-stone-500 bg-stone-100 border-r border-stone-300 font-bold">$</span>
                  <input
                    type="number"
                    value={calcFreightUSD}
                    onChange={(e) => setCalcFreightUSD(e.target.value)}
                    className="flex-1 px-3 py-2 text-xs font-bold text-stone-900 bg-transparent font-mono-num"
                  />
                </div>
                <span className="text-[11px] text-amber-900 mt-1 block font-mono-num font-medium">
                  = {formatPKR(freightPKR)} (Live: Rs. {getRate('USD').toFixed(2)}/USD)
                </span>
              </div>

              {/* Port & Customs Duty in PKR */}
              <div>
                <label className="block text-xs font-medium text-stone-600 mb-1">
                  3. Customs Duty & Port Charges (PKR):
                </label>
                <div className="flex rounded-xl overflow-hidden border border-stone-300 bg-stone-50">
                  <span className="px-3 py-2 text-xs text-stone-500 bg-stone-100 border-r border-stone-300 font-bold">Rs</span>
                  <input
                    type="number"
                    value={calcCustomsDutyPKR}
                    onChange={(e) => setCalcCustomsDutyPKR(e.target.value)}
                    className="flex-1 px-3 py-2 text-xs font-bold text-stone-900 bg-transparent font-mono-num"
                  />
                </div>
              </div>
            </div>
          </div>

          {/* Total Landed Result */}
          <div className="p-4 rounded-xl bg-stone-50 border border-stone-200">
            <span className="text-[11px] uppercase font-bold text-stone-500 tracking-wider block">
              Estimated Total Landed Cost (Karachi Warehouse)
            </span>
            <div className="text-2xl font-bold text-stone-900 font-mono-num mt-1">
              {formatPKR(totalLandedPKR)}
            </div>
            <p className="text-xs text-stone-600 mt-1">
              Approx. {formatPKR(totalLandedPKR, true)} total cost delivered
            </p>
          </div>
        </div>
      </div>

      {/* Comprehensive 9-Currency Real-Time Exchange Rate Matrix & Manual Adjuster */}
      <div className="bg-white border border-stone-200 rounded-2xl p-4 sm:p-6 shadow-sm space-y-4">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 border-b border-stone-100 pb-3">
          <div>
            <h3 className="text-base font-bold text-stone-900 flex items-center gap-2">
              <TrendingUp className="w-4 h-4 text-stone-700" />
              Live Forex Exchange Rates Table
            </h3>
            <p className="text-xs text-stone-500 mt-0.5">
              Real-time market rates for Pakistani Rupee (PKR). Click "Adjust" if you have specific bank TT / Hawala negotiated rates.
            </p>
          </div>
          <div className="flex items-center gap-2">
            <span className="text-xs text-stone-500 font-medium">
              Base Currency: <strong className="text-stone-900">PKR (₨)</strong>
            </span>
          </div>
        </div>

        <div className="overflow-x-auto rounded-xl border border-stone-200">
          <table className="w-full text-left text-xs bg-white">
            <thead className="bg-stone-100 text-stone-700 font-medium text-xs border-b border-stone-200">
              <tr>
                <th className="py-3 px-3.5">Currency</th>
                <th className="py-3 px-3.5">Country</th>
                <th className="py-3 px-3.5">Live Rate (1 Unit in PKR)</th>
                <th className="py-3 px-3.5">10,000 Units in PKR</th>
                <th className="py-3 px-3.5">100,000 Units in PKR</th>
                <th className="py-3 px-3.5 text-right">Custom Rate</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-stone-100">
              {currencies.map((curr) => {
                const isEditing = editingCurrency === curr.code;
                return (
                  <tr key={curr.code} className="hover:bg-stone-50/80 transition-colors">
                    <td className="py-3 px-3.5 whitespace-nowrap">
                      <div className="flex items-center gap-2.5">
                        <span className="text-xl">{curr.flag}</span>
                        <div>
                          <span className="font-bold text-stone-900 font-mono block text-xs">{curr.code}</span>
                          <span className="text-[11px] text-stone-500">{curr.name}</span>
                        </div>
                      </div>
                    </td>

                    <td className="py-3 px-3.5 text-stone-700 font-medium">
                      {curr.country}
                    </td>

                    <td className="py-3 px-3.5 whitespace-nowrap">
                      {isEditing ? (
                        <div className="flex items-center gap-1.5">
                          <input
                            type="number"
                            step="0.01"
                            value={editRateInput}
                            onChange={(e) => setEditRateInput(e.target.value)}
                            className="w-24 px-2 py-1 bg-stone-50 border border-stone-800 rounded-lg text-stone-900 text-xs font-mono font-bold"
                            autoFocus
                          />
                          <button
                            onClick={() => handleSaveRate(curr.code)}
                            className="p-1.5 bg-emerald-700 hover:bg-emerald-800 text-white rounded-lg shadow-xs cursor-pointer"
                            title="Save Custom Rate"
                          >
                            <Check className="w-3.5 h-3.5" />
                          </button>
                        </div>
                      ) : (
                        <div className="flex items-center gap-2">
                          <span className="font-bold text-emerald-800 font-mono-num text-sm">
                            Rs. {curr.rateToPKR.toFixed(2)}
                          </span>
                          {curr.code !== 'PKR' && (
                            <span className="text-[10px] px-1.5 py-0.5 rounded bg-emerald-50 text-emerald-700 font-semibold border border-emerald-200">
                              Live
                            </span>
                          )}
                        </div>
                      )}
                    </td>

                    <td className="py-3 px-3.5 font-semibold text-stone-800 font-mono-num whitespace-nowrap">
                      {formatPKR(curr.rateToPKR * 10000)}
                    </td>

                    <td className="py-3 px-3.5 font-bold text-amber-900 font-mono-num whitespace-nowrap">
                      {formatPKR(curr.rateToPKR * 100000)}
                    </td>

                    <td className="py-3 px-3.5 text-right whitespace-nowrap">
                      {curr.code !== 'PKR' && (
                        <button
                          onClick={() => {
                            setEditingCurrency(curr.code);
                            setEditRateInput(curr.rateToPKR.toString());
                          }}
                          className="px-3 py-1 bg-stone-100 hover:bg-[#1C1917] hover:text-white text-stone-700 rounded-lg text-xs font-medium transition-colors border border-stone-200 cursor-pointer"
                        >
                          Adjust Rate
                        </button>
                      )}
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
