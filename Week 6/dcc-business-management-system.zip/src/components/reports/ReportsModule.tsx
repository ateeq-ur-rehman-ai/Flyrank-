import React, { useState } from 'react';
import {
  FileText,
  FileSpreadsheet,
  Printer,
  Download,
  Calendar,
  Building2,
  Ship,
  DollarSign,
  TrendingUp,
  AlertCircle,
  CheckCircle2,
  ArrowUpRight,
  Filter,
  PieChart,
  Sparkles,
  Layers,
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import confetti from 'canvas-confetti';
import { useApp } from '../../context/AppContext';
import { formatPKR, formatCurrency, formatDate } from '../../utils/formatters';
import { generateDCCReportPDF } from '../../utils/pdfGenerator';

export const ReportsModule: React.FC = () => {
  const { vendors, containers, payments, currencies, currentUser } = useApp();

  const [activeReportTab, setActiveReportTab] = useState<
    'monthly' | 'vendor' | 'container' | 'import_value' | 'outstanding' | 'forex'
  >('monthly');

  const [dateRange, setDateRange] = useState<'YTD' | 'CURRENT_MONTH' | 'ALL'>('YTD');
  const [downloadSuccessMessage, setDownloadSuccessMessage] = useState<string | null>(null);

  // Aggregates
  const totalSpendPKR = vendors.reduce((acc, v) => acc + v.totalImportValuePKR, 0);
  const totalSettledPKR = vendors.reduce((acc, v) => acc + v.totalPaidPKR, 0);
  const totalOutstandingPKR = vendors.reduce((acc, v) => acc + v.pendingBalancePKR, 0);

  const chinaSpendPKR = vendors.filter((v) => v.region === 'China').reduce((acc, v) => acc + v.totalImportValuePKR, 0);
  const gulfSpendPKR = vendors.filter((v) => v.region === 'Gulf').reduce((acc, v) => acc + v.totalImportValuePKR, 0);

  const getTabTitle = (tab: string) => {
    switch (tab) {
      case 'monthly':
        return 'Monthly Settlements Report';
      case 'vendor':
        return 'Vendor Balances & Import Ledger';
      case 'container':
        return 'Container Shipments & Port Status';
      case 'import_value':
        return 'China vs Gulf Sourcing Analysis';
      case 'outstanding':
        return 'Pending Supplier Liabilities';
      case 'forex':
        return 'Foreign Currency Exchange Matrix';
      default:
        return 'Financial & Logistics Report';
    }
  };

  // Celebration Confetti for client delight
  const triggerConfetti = () => {
    confetti({
      particleCount: 60,
      spread: 70,
      origin: { y: 0.75 },
      colors: ['#D97706', '#10956a', '#1C1917', '#F59E0B'],
    });
  };

  // 1. Colorful DCC Branded PDF Download Handler
  const handleDownloadPDF = () => {
    triggerConfetti();
    const title = getTabTitle(activeReportTab);
    const scopeLabel = dateRange === 'YTD' ? 'Year-to-Date (2026)' : dateRange === 'CURRENT_MONTH' ? 'August 2026 Only' : 'Complete History';

    generateDCCReportPDF({
      reportType: activeReportTab,
      reportTitle: title,
      scope: scopeLabel,
      vendors,
      containers,
      payments,
      currencies,
      userName: currentUser?.name || 'Admin Manager',
    });

    setDownloadSuccessMessage(`PDF generated: DCC ${title}.pdf (Colorful Branded Format)`);
    setTimeout(() => setDownloadSuccessMessage(null), 4000);
  };

  // 2. Export as CSV Handler
  const handleExportCSV = () => {
    triggerConfetti();
    let csvContent = 'data:text/csv;charset=utf-8,';

    if (activeReportTab === 'vendor') {
      csvContent += 'Vendor Code,Vendor Name,Region,Country,Category,Total Imported (PKR),Total Paid (PKR),Pending Balance (PKR),Containers\n';
      vendors.forEach((v) => {
        csvContent += `"${v.code}","${v.name}","${v.region}","${v.country}","${v.category}",${v.totalImportValuePKR},${v.totalPaidPKR},${v.pendingBalancePKR},${v.totalContainersCount}\n`;
      });
    } else if (activeReportTab === 'container') {
      csvContent += 'Container Number,BL Number,Vendor,Origin Country,Status,Shipment Value,Currency,PKR Value,Ship Date,Expected Arrival\n';
      containers.forEach((c) => {
        csvContent += `"${c.containerNumber}","${c.blNumber}","${c.vendorName}","${c.originCountry}","${c.status}",${c.shipmentValue},"${c.currency}",${c.shipmentValuePKR},"${c.shipmentDate}","${c.expectedArrival}"\n`;
      });
    } else if (activeReportTab === 'forex') {
      csvContent += 'Currency Code,Currency Name,Country,Exchange Rate to PKR,10K in PKR,100K in PKR\n';
      currencies.forEach((curr) => {
        csvContent += `"${curr.code}","${curr.name}","${curr.country}",${curr.rateToPKR},${curr.rateToPKR * 10000},${curr.rateToPKR * 100000}\n`;
      });
    } else if (activeReportTab === 'outstanding') {
      csvContent += 'Vendor Code,Vendor Name,Country,Pending Balance (PKR),Currency,Active Shipments\n';
      vendors.filter(v => v.pendingBalancePKR > 0).forEach((v) => {
        csvContent += `"${v.code}","${v.name}","${v.country}",${v.pendingBalancePKR},"${v.bankDetails.currency}",${v.activeContainersCount}\n`;
      });
    } else {
      csvContent += 'Payment Ref,Invoice Number,Vendor Name,Payment Date,Foreign Amount,Currency,Forex Rate,PKR Amount,Method,Status\n';
      payments.forEach((p) => {
        csvContent += `"${p.paymentRef}","${p.invoiceNumber}","${p.vendorName}","${p.paymentDate}",${p.amount},"${p.currency}",${p.exchangeRateToPKR},${p.amountPKR},"${p.paymentMethod}","${p.status}"\n`;
      });
    }

    const encodedUri = encodeURI(csvContent);
    const link = document.createElement('a');
    link.setAttribute('href', encodedUri);
    link.setAttribute('download', `DCC_${activeReportTab.toUpperCase()}_EXPORT_${new Date().toISOString().slice(0, 10)}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);

    setDownloadSuccessMessage(`CSV export downloaded: DCC_${activeReportTab.toUpperCase()}_EXPORT.csv`);
    setTimeout(() => setDownloadSuccessMessage(null), 4000);
  };

  return (
    <motion.div
      initial={{ opacity: 0, y: 8 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.3, ease: 'easeOut' }}
      className="p-3.5 sm:p-5 md:p-6 space-y-4 sm:space-y-6 max-w-7xl mx-auto"
    >
      {/* Download Alert Banner */}
      <AnimatePresence>
        {downloadSuccessMessage && (
          <motion.div
            initial={{ opacity: 0, height: 0, y: -10 }}
            animate={{ opacity: 1, height: 'auto', y: 0 }}
            exit={{ opacity: 0, height: 0, y: -10 }}
            className="p-3.5 bg-emerald-50 border border-emerald-300 rounded-xl text-emerald-900 flex items-center justify-between shadow-sm overflow-hidden"
          >
            <div className="flex items-center gap-2.5">
              <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
              <span className="text-xs font-semibold">{downloadSuccessMessage}</span>
            </div>
            <span className="text-[10px] px-2 py-0.5 rounded bg-emerald-200/60 font-bold text-emerald-900">
              Downloaded
            </span>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Top Banner with 2 Dedicated Download Options (PDF & CSV) */}
      <div className="bg-white border border-stone-200 rounded-2xl p-4 sm:p-6 text-stone-900 flex flex-col md:flex-row md:items-center justify-between gap-4 shadow-sm">
        <div>
          <div className="flex items-center gap-2 mb-1">
            <span className="px-2.5 py-0.5 rounded-full bg-amber-100 text-amber-900 text-[10px] font-bold uppercase tracking-wider border border-amber-300/80 flex items-center gap-1">
              <Sparkles className="w-3 h-3 text-amber-600" />
              Executive Reports
            </span>
            <span className="text-xs text-stone-500 font-medium">Dual Export (PDF & CSV)</span>
          </div>
          <h2 className="text-xl sm:text-2xl font-bold text-stone-900 tracking-tight">
            Financial & Logistics Reports
          </h2>
          <p className="text-xs text-stone-600 mt-1">
            Download branded, colorful PDF statements with official DCC letterhead or export raw data as CSV.
          </p>
        </div>

        {/* 2 Primary Export Options */}
        <div className="flex flex-wrap items-center gap-2.5 self-start md:self-auto no-print">
          {/* 1. PDF Download Option */}
          <motion.button
            whileHover={{ scale: 1.02 }}
            whileTap={{ scale: 0.98 }}
            id="btn-download-pdf-report"
            onClick={handleDownloadPDF}
            className="px-4 py-2.5 bg-gradient-to-r from-[#1C1917] to-[#2E2824] hover:from-[#2C2621] hover:to-[#3D352F] text-amber-100 text-xs font-bold rounded-xl border border-amber-900/40 flex items-center gap-2 transition-all shadow-sm cursor-pointer"
            title="Download high-resolution branded colorful PDF report"
          >
            <FileText className="w-4 h-4 text-amber-400" />
            <span>Download PDF</span>
            <span className="text-[9px] px-1.5 py-0.5 rounded bg-amber-500/20 text-amber-300 font-bold border border-amber-400/30 uppercase">
              Branded
            </span>
          </motion.button>

          {/* 2. CSV Export Option */}
          <motion.button
            whileHover={{ scale: 1.02 }}
            whileTap={{ scale: 0.98 }}
            id="btn-export-csv-report"
            onClick={handleExportCSV}
            className="px-4 py-2.5 bg-white hover:bg-stone-50 text-stone-800 text-xs font-semibold rounded-xl border border-stone-300 flex items-center gap-2 transition-colors shadow-2xs cursor-pointer"
            title="Export raw tabular data as spreadsheet CSV"
          >
            <FileSpreadsheet className="w-4 h-4 text-emerald-600" />
            <span>Export as CSV</span>
          </motion.button>
        </div>
      </div>

      {/* Summary KPI Strip with interactive hover animations */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3 sm:gap-4">
        {[
          {
            title: 'Total Trade Volume',
            value: formatPKR(totalSpendPKR, true),
            sub: `${vendors.length} Foreign Vendors Registered`,
            highlight: 'text-stone-900',
          },
          {
            title: 'Settled Payments',
            value: formatPKR(totalSettledPKR, true),
            sub: `${((totalSettledPKR / (totalSpendPKR || 1)) * 100).toFixed(1)}% Completed Settlements`,
            highlight: 'text-emerald-800',
          },
          {
            title: 'Pending Balance',
            value: formatPKR(totalOutstandingPKR, true),
            sub: 'Awaiting Customs / Port BL clearance',
            highlight: 'text-amber-900',
          },
          {
            title: 'China vs Gulf Split',
            value: `🇨🇳 ${((chinaSpendPKR / (totalSpendPKR || 1)) * 100).toFixed(0)}% / 🇦🇪 ${((gulfSpendPKR / (totalSpendPKR || 1)) * 100).toFixed(0)}%`,
            sub: `Rs. ${(chinaSpendPKR / 1000000).toFixed(1)}M vs Rs. ${(gulfSpendPKR / 1000000).toFixed(1)}M`,
            highlight: 'text-stone-800',
          },
        ].map((kpi, idx) => (
          <motion.div
            key={idx}
            whileHover={{ y: -2, transition: { duration: 0.15 } }}
            className="bg-white border border-stone-200 rounded-2xl p-4 sm:p-5 shadow-sm"
          >
            <span className="text-xs uppercase tracking-wider text-stone-500 font-semibold block">
              {kpi.title}
            </span>
            <span className={`text-2xl font-bold font-mono-num mt-1 block ${kpi.highlight}`}>
              {kpi.value}
            </span>
            <span className="text-xs text-stone-500 mt-1 block">{kpi.sub}</span>
          </motion.div>
        ))}
      </div>

      {/* Report Module Navigation Tabs & Dynamic Content */}
      <div className="bg-white border border-stone-200 rounded-2xl p-4 sm:p-6 shadow-sm space-y-5">
        <div className="flex flex-wrap items-center justify-between gap-3 border-b border-stone-100 pb-4 no-print">
          <div className="flex flex-wrap items-center gap-1.5">
            {[
              { id: 'monthly', label: 'Monthly Payments', icon: Calendar },
              { id: 'vendor', label: 'Vendor Ledger', icon: Building2 },
              { id: 'container', label: 'Containers & BL', icon: Ship },
              { id: 'import_value', label: 'Import Value Sourcing', icon: PieChart },
              { id: 'outstanding', label: 'Pending Liabilities', icon: AlertCircle },
              { id: 'forex', label: 'Forex Matrix', icon: TrendingUp },
            ].map((tab) => {
              const Icon = tab.icon;
              const isActive = activeReportTab === tab.id;
              return (
                <button
                  key={tab.id}
                  id={`tab-report-${tab.id}`}
                  onClick={() => setActiveReportTab(tab.id as any)}
                  className={`px-3 sm:px-3.5 py-2 text-xs font-semibold rounded-xl transition-all flex items-center gap-1.5 cursor-pointer ${
                    isActive
                      ? 'bg-[#1C1917] text-amber-100 shadow-xs font-bold'
                      : 'bg-stone-100 text-stone-600 hover:text-stone-900 hover:bg-stone-200'
                  }`}
                >
                  <Icon className={`w-3.5 h-3.5 ${isActive ? 'text-amber-300' : 'text-stone-500'}`} />
                  <span>{tab.label}</span>
                </button>
              );
            })}
          </div>

          <div className="flex items-center gap-2">
            <span className="text-xs text-stone-500 font-medium">Filter Scope:</span>
            <select
              id="select-report-scope"
              value={dateRange}
              onChange={(e) => setDateRange(e.target.value as any)}
              className="bg-stone-50 border border-stone-300 text-stone-800 text-xs px-3 py-1.5 rounded-lg focus:outline-none focus:border-stone-700 cursor-pointer"
            >
              <option value="YTD">Year-to-Date (2026)</option>
              <option value="CURRENT_MONTH">August 2026 Only</option>
              <option value="ALL">All History Records</option>
            </select>
          </div>
        </div>

        {/* Tab Content with Smooth Transitions */}
        <AnimatePresence mode="wait">
          <motion.div
            key={activeReportTab}
            initial={{ opacity: 0, y: 6 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -6 }}
            transition={{ duration: 0.2 }}
          >
            {/* 1. Monthly Payments Report */}
            {activeReportTab === 'monthly' && (
              <div className="space-y-4">
                <div className="flex items-center justify-between">
                  <div>
                    <h3 className="text-base font-bold text-stone-900">Monthly Payments & Disbursements</h3>
                    <p className="text-xs text-stone-500">Bank settlements, overseas TTs, and disbursements by month</p>
                  </div>
                </div>

                <div className="overflow-x-auto rounded-xl border border-stone-200">
                  <table className="w-full text-left text-xs bg-white min-w-[600px]">
                    <thead className="bg-stone-100 text-stone-700 text-xs font-semibold border-b border-stone-200">
                      <tr>
                        <th className="py-3 px-3.5">Month</th>
                        <th className="py-3 px-3.5">Transactions</th>
                        <th className="py-3 px-3.5">Paid (PKR)</th>
                        <th className="py-3 px-3.5">Pending (PKR)</th>
                        <th className="py-3 px-3.5">Total Month Volume</th>
                        <th className="py-3 px-3.5">Currencies</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-stone-100">
                      <tr className="hover:bg-stone-50/80">
                        <td className="py-3 px-3.5 font-bold text-stone-900">August 2026 (Current)</td>
                        <td className="py-3 px-3.5 text-stone-600 font-medium">6 Transactions</td>
                        <td className="py-3 px-3.5 font-bold text-emerald-800 font-mono-num">Rs. 43,267,700</td>
                        <td className="py-3 px-3.5 font-bold text-amber-900 font-mono-num">Rs. 14,028,250</td>
                        <td className="py-3 px-3.5 font-bold text-stone-900 font-mono-num">Rs. 57,295,950</td>
                        <td className="py-3 px-3.5 text-stone-500 text-[11px]">CNY, AED, USD, SAR, KWD</td>
                      </tr>
                      <tr className="hover:bg-stone-50/80">
                        <td className="py-3 px-3.5 font-bold text-stone-900">July 2026</td>
                        <td className="py-3 px-3.5 text-stone-600 font-medium">7 Transactions</td>
                        <td className="py-3 px-3.5 font-bold text-emerald-800 font-mono-num">Rs. 45,600,000</td>
                        <td className="py-3 px-3.5 text-stone-400 font-mono-num">Rs. 0</td>
                        <td className="py-3 px-3.5 font-bold text-stone-900 font-mono-num">Rs. 45,600,000</td>
                        <td className="py-3 px-3.5 text-stone-500 text-[11px]">CNY, AED, USD</td>
                      </tr>
                      <tr className="hover:bg-stone-50/80">
                        <td className="py-3 px-3.5 font-bold text-stone-900">June 2026</td>
                        <td className="py-3 px-3.5 text-stone-600 font-medium">8 Transactions</td>
                        <td className="py-3 px-3.5 font-bold text-emerald-800 font-mono-num">Rs. 37,800,000</td>
                        <td className="py-3 px-3.5 text-stone-400 font-mono-num">Rs. 0</td>
                        <td className="py-3 px-3.5 font-bold text-stone-900 font-mono-num">Rs. 37,800,000</td>
                        <td className="py-3 px-3.5 text-stone-500 text-[11px]">CNY, AED, SAR</td>
                      </tr>
                    </tbody>
                  </table>
                </div>
              </div>
            )}

            {/* 2. Vendor-Wise Ledger */}
            {activeReportTab === 'vendor' && (
              <div className="space-y-4">
                <div>
                  <h3 className="text-base font-bold text-stone-900">Vendor Ledger & Cumulative Balances</h3>
                  <p className="text-xs text-stone-500">Breakdown by foreign mills, trading houses, and fabric houses</p>
                </div>

                <div className="overflow-x-auto rounded-xl border border-stone-200">
                  <table className="w-full text-left text-xs bg-white min-w-[650px]">
                    <thead className="bg-stone-100 text-stone-700 text-xs font-semibold border-b border-stone-200">
                      <tr>
                        <th className="py-3 px-3.5">Vendor</th>
                        <th className="py-3 px-3.5">Country & Region</th>
                        <th className="py-3 px-3.5">Category</th>
                        <th className="py-3 px-3.5">Total Imported</th>
                        <th className="py-3 px-3.5">Total Paid</th>
                        <th className="py-3 px-3.5">Pending Balance</th>
                        <th className="py-3 px-3.5">Shipments</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-stone-100">
                      {vendors.map((v) => (
                        <tr key={v.id} className="hover:bg-stone-50/80">
                          <td className="py-3 px-3.5 font-bold text-stone-900">
                            {v.name}
                            <span className="block text-[10px] text-stone-500 font-normal">{v.code}</span>
                          </td>
                          <td className="py-3 px-3.5 text-stone-700 font-medium">{v.country} ({v.region})</td>
                          <td className="py-3 px-3.5 text-stone-600">{v.category}</td>
                          <td className="py-3 px-3.5 font-bold text-stone-900 font-mono-num">{formatPKR(v.totalImportValuePKR)}</td>
                          <td className="py-3 px-3.5 font-bold text-emerald-800 font-mono-num">{formatPKR(v.totalPaidPKR)}</td>
                          <td className="py-3 px-3.5 font-bold text-amber-900 font-mono-num">{formatPKR(v.pendingBalancePKR)}</td>
                          <td className="py-3 px-3.5 text-stone-600 text-xs font-medium">{v.totalContainersCount} Containers</td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>
            )}

            {/* 3. Container Summary */}
            {activeReportTab === 'container' && (
              <div className="space-y-4">
                <div>
                  <h3 className="text-base font-bold text-stone-900">Container Shipments & Bill of Lading (BL)</h3>
                  <p className="text-xs text-stone-500">Real-time container logistics, shipping lines, and port arrivals</p>
                </div>

                <div className="overflow-x-auto rounded-xl border border-stone-200">
                  <table className="w-full text-left text-xs bg-white min-w-[650px]">
                    <thead className="bg-stone-100 text-stone-700 text-xs font-semibold border-b border-stone-200">
                      <tr>
                        <th className="py-3 px-3.5">Container #</th>
                        <th className="py-3 px-3.5">BL Number</th>
                        <th className="py-3 px-3.5">Vendor / Line</th>
                        <th className="py-3 px-3.5">Status</th>
                        <th className="py-3 px-3.5">Value (PKR)</th>
                        <th className="py-3 px-3.5">Shipped</th>
                        <th className="py-3 px-3.5">Port Arrival</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-stone-100">
                      {containers.map((c) => (
                        <tr key={c.id} className="hover:bg-stone-50/80">
                          <td className="py-3 px-3.5 font-bold text-stone-900 font-mono">{c.containerNumber}</td>
                          <td className="py-3 px-3.5 text-stone-500 font-mono">{c.blNumber}</td>
                          <td className="py-3 px-3.5 text-stone-700 font-medium">
                            {c.vendorName}
                            <span className="block text-[10px] text-stone-500">{c.shippingLine}</span>
                          </td>
                          <td className="py-3 px-3.5">
                            <span className="px-2.5 py-1 rounded-full text-[11px] font-bold bg-stone-100 text-stone-800 border border-stone-200">
                              {c.status.replace('_', ' ')}
                            </span>
                          </td>
                          <td className="py-3 px-3.5 font-bold text-stone-900 font-mono-num">{formatPKR(c.shipmentValuePKR)}</td>
                          <td className="py-3 px-3.5 text-stone-600">{formatDate(c.shipmentDate)}</td>
                          <td className="py-3 px-3.5 text-stone-600">{formatDate(c.actualArrival || c.expectedArrival)}</td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>
            )}

            {/* 4. Import Value Analysis */}
            {activeReportTab === 'import_value' && (
              <div className="space-y-4">
                <div>
                  <h3 className="text-base font-bold text-stone-900">Import Value Analysis (China vs Gulf)</h3>
                  <p className="text-xs text-stone-500">Comparison of China and Gulf sourcing volumes, textile materials, and mills</p>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="p-5 rounded-2xl bg-amber-50/50 border border-amber-200/80 shadow-2xs">
                    <span className="text-xs font-bold text-amber-900 uppercase tracking-wider block">
                      🇨🇳 China Textile Imports (Shaoxing & Guangzhou)
                    </span>
                    <span className="text-3xl font-bold text-stone-900 font-mono-num mt-2 block">
                      {formatPKR(chinaSpendPKR)}
                    </span>
                    <p className="text-xs text-stone-600 mt-2.5 leading-relaxed">
                      Silk brocades, chiffon rolls, high-grade denim, satin, and pure linen imported from Shaoxing, Guangzhou, and Ningbo ports.
                    </p>
                  </div>

                  <div className="p-5 rounded-2xl bg-stone-100/70 border border-stone-200 shadow-2xs">
                    <span className="text-xs font-bold text-stone-800 uppercase tracking-wider block">
                      🇦🇪 Gulf Region Imports (Dubai, Sharjah & Riyadh)
                    </span>
                    <span className="text-3xl font-bold text-stone-900 font-mono-num mt-2 block">
                      {formatPKR(gulfSpendPKR)}
                    </span>
                    <p className="text-xs text-stone-600 mt-2.5 leading-relaxed">
                      Jacquard damask, Saudi Nida abaya crepe, metallic zari embroidery, and Kuwait woolens from Deira and Sharjah Wholesale Market.
                    </p>
                  </div>
                </div>
              </div>
            )}

            {/* 5. Outstanding Payments */}
            {activeReportTab === 'outstanding' && (
              <div className="space-y-4">
                <div>
                  <h3 className="text-base font-bold text-stone-900">Pending Supplier Liabilities</h3>
                  <p className="text-xs text-stone-500">Unsettled invoices awaiting customs clearance, container inspection, or bank release</p>
                </div>

                <div className="overflow-x-auto rounded-xl border border-stone-200">
                  <table className="w-full text-left text-xs bg-white min-w-[650px]">
                    <thead className="bg-stone-100 text-stone-700 text-xs font-semibold border-b border-stone-200">
                      <tr>
                        <th className="py-3 px-3.5">Vendor</th>
                        <th className="py-3 px-3.5">Pending Balance (PKR)</th>
                        <th className="py-3 px-3.5">Currency</th>
                        <th className="py-3 px-3.5">Beneficiary Bank</th>
                        <th className="py-3 px-3.5">Shipments</th>
                        <th className="py-3 px-3.5">Status</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-stone-100">
                      {vendors.filter(v => v.pendingBalancePKR > 0).map((v) => (
                        <tr key={v.id} className="hover:bg-stone-50/80">
                          <td className="py-3 px-3.5 font-bold text-stone-900">
                            {v.name}
                            <span className="block text-[10px] text-stone-500">{v.country}</span>
                          </td>
                          <td className="py-3 px-3.5 font-bold text-amber-900 font-mono-num text-sm">
                            {formatPKR(v.pendingBalancePKR)}
                          </td>
                          <td className="py-3 px-3.5 text-stone-800 font-bold font-mono">
                            {v.bankDetails.currency}
                          </td>
                          <td className="py-3 px-3.5 text-stone-600">
                            {v.bankDetails.bankName}
                          </td>
                          <td className="py-3 px-3.5 text-stone-700 font-medium">
                            {v.activeContainersCount} containers en route
                          </td>
                          <td className="py-3 px-3.5">
                            <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-amber-100 text-amber-900 border border-amber-300">
                              Awaiting Release
                            </span>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>
            )}

            {/* 6. PKR Conversion Summary */}
            {activeReportTab === 'forex' && (
              <div className="space-y-4">
                <div>
                  <h3 className="text-base font-bold text-stone-900">Exchange Rates Summary Matrix</h3>
                  <p className="text-xs text-stone-500">Live & configured exchange rates applied across import ledgers</p>
                </div>

                <div className="overflow-x-auto rounded-xl border border-stone-200">
                  <table className="w-full text-left text-xs bg-white min-w-[650px]">
                    <thead className="bg-stone-100 text-stone-700 text-xs font-semibold border-b border-stone-200">
                      <tr>
                        <th className="py-3 px-3.5">Currency</th>
                        <th className="py-3 px-3.5">Country</th>
                        <th className="py-3 px-3.5">Live Rate (PKR)</th>
                        <th className="py-3 px-3.5">10,000 Units in PKR</th>
                        <th className="py-3 px-3.5">100,000 Units in PKR</th>
                        <th className="py-3 px-3.5">500,000 Units in PKR</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-stone-100">
                      {currencies.map((curr) => (
                        <tr key={curr.code} className="hover:bg-stone-50/80">
                          <td className="py-3 px-3.5 font-medium text-stone-900">
                            <span className="font-bold mr-1">{curr.flag} {curr.code}</span> ({curr.name})
                          </td>
                          <td className="py-3 px-3.5 text-stone-700 font-medium">{curr.country}</td>
                          <td className="py-3 px-3.5 font-bold text-emerald-800 font-mono-num text-sm">
                            Rs. {curr.rateToPKR.toFixed(2)}
                          </td>
                          <td className="py-3 px-3.5 font-semibold text-stone-800 font-mono-num">
                            {formatPKR(curr.rateToPKR * 10000)}
                          </td>
                          <td className="py-3 px-3.5 font-bold text-amber-900 font-mono-num">
                            {formatPKR(curr.rateToPKR * 100000)}
                          </td>
                          <td className="py-3 px-3.5 font-bold text-stone-900 font-mono-num">
                            {formatPKR(curr.rateToPKR * 500000)}
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>
            )}
          </motion.div>
        </AnimatePresence>
      </div>
    </motion.div>
  );
};
