import React, { useState } from 'react';
import { ShieldCheck, Lock, Mail, ArrowRight, Sparkles, Globe2, Building2, CheckCircle2 } from 'lucide-react';
import { motion } from 'motion/react';
import confetti from 'canvas-confetti';
import { useApp } from '../../context/AppContext';
import { INITIAL_USERS } from '../../data/mockData';

export const LoginScreen: React.FC = () => {
  const { login, switchUser } = useApp();
  const [email, setEmail] = useState('salman@dubaiclothing.pk');
  const [password, setPassword] = useState('••••••••••••');

  const handleQuickLogin = (userIndex: number) => {
    confetti({
      particleCount: 40,
      spread: 50,
      origin: { y: 0.65 },
      colors: ['#D97706', '#10956a', '#1C1917'],
    });
    switchUser(INITIAL_USERS[userIndex]);
    login();
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    confetti({
      particleCount: 45,
      spread: 55,
      origin: { y: 0.65 },
      colors: ['#D97706', '#10956a', '#1C1917'],
    });
    login(email);
  };

  return (
    <div className="min-h-screen bg-[#FBF9F5] text-stone-900 flex flex-col justify-center items-center p-4 relative overflow-hidden">
      {/* Subtle animated floating background ambient accents */}
      <motion.div
        animate={{
          scale: [1, 1.08, 1],
          opacity: [0.35, 0.55, 0.35],
        }}
        transition={{
          duration: 8,
          repeat: Infinity,
          ease: 'easeInOut',
        }}
        className="absolute -top-24 -right-24 w-96 h-96 rounded-full bg-amber-200/40 blur-3xl pointer-events-none"
      />
      <motion.div
        animate={{
          scale: [1, 1.12, 1],
          opacity: [0.25, 0.45, 0.25],
        }}
        transition={{
          duration: 10,
          repeat: Infinity,
          ease: 'easeInOut',
          delay: 1,
        }}
        className="absolute -bottom-24 -left-24 w-96 h-96 rounded-full bg-stone-300/30 blur-3xl pointer-events-none"
      />

      <div className="w-full max-w-md relative z-10">
        {/* DCC Header Badge with entrance animation */}
        <motion.div
          initial={{ opacity: 0, y: -16 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.45, ease: 'easeOut' }}
          className="text-center mb-7"
        >
          <motion.div
            whileHover={{ scale: 1.05, rotate: 2 }}
            whileTap={{ scale: 0.95 }}
            className="inline-flex items-center justify-center w-16 h-16 rounded-2xl bg-[#1C1917] text-amber-100 font-bold text-2xl shadow-lg border border-stone-800 mb-4 cursor-pointer"
          >
            DCC
          </motion.div>
          <h1 className="text-3xl font-bold text-stone-900 tracking-tight">
            Dubai Clothing Center
          </h1>
          <p className="text-stone-500 text-xs mt-1.5 font-medium">
            China & Gulf Import Registry • Karachi, Pakistan
          </p>
        </motion.div>

        {/* Login Card */}
        <motion.div
          initial={{ opacity: 0, scale: 0.96, y: 12 }}
          animate={{ opacity: 1, scale: 1, y: 0 }}
          transition={{ duration: 0.4, delay: 0.1, ease: 'easeOut' }}
          className="bg-white border border-stone-200 rounded-2xl p-7 sm:p-8 shadow-md"
        >
          <div className="mb-6 border-b border-stone-100 pb-4">
            <h2 className="text-xl font-bold text-stone-900">Sign In to DCC Portal</h2>
            <p className="text-xs text-stone-500 mt-1">
              Live foreign trade ledger, vendor accounts & shipment tracking
            </p>
          </div>

          <form onSubmit={handleSubmit} className="space-y-4">
            <div>
              <label className="block text-xs font-semibold text-stone-700 mb-1.5">
                Corporate Email
              </label>
              <div className="relative">
                <Mail className="w-4 h-4 text-stone-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
                <input
                  id="input-login-email"
                  type="email"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  className="w-full pl-10 pr-4 py-2.5 bg-stone-50 border border-stone-300 rounded-xl text-stone-900 text-xs placeholder-stone-400 focus:outline-none focus:border-stone-800 focus:ring-1 focus:ring-stone-800 transition-all"
                  placeholder="name@dubaiclothing.pk"
                  required
                />
              </div>
            </div>

            <div>
              <label className="block text-xs font-semibold text-stone-700 mb-1.5">
                Password
              </label>
              <div className="relative">
                <Lock className="w-4 h-4 text-stone-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
                <input
                  id="input-login-password"
                  type="password"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  className="w-full pl-10 pr-4 py-2.5 bg-stone-50 border border-stone-300 rounded-xl text-stone-900 text-xs placeholder-stone-400 focus:outline-none focus:border-stone-800 focus:ring-1 focus:ring-stone-800 transition-all"
                  placeholder="••••••••••••"
                  required
                />
              </div>
            </div>

            <div className="flex items-center justify-between text-xs pt-1">
              <label className="flex items-center gap-2 text-stone-600 cursor-pointer">
                <input
                  type="checkbox"
                  defaultChecked
                  className="rounded bg-stone-100 border-stone-300 text-stone-900 focus:ring-0"
                />
                <span>Keep session active</span>
              </label>
              <span className="text-amber-800 hover:text-amber-900 cursor-pointer font-medium">
                Forgot password?
              </span>
            </div>

            <motion.button
              whileHover={{ scale: 1.01 }}
              whileTap={{ scale: 0.98 }}
              id="btn-login-submit"
              type="submit"
              className="w-full py-3 bg-[#1C1917] hover:bg-[#292524] text-amber-50 font-bold text-xs rounded-xl transition-all shadow-md flex items-center justify-center gap-2 mt-2 cursor-pointer"
            >
              <span>Access DCC Management Portal</span>
              <ArrowRight className="w-4 h-4" />
            </motion.button>
          </form>

          {/* Quick Demo Personas with Muhammad Salman */}
          <div className="mt-7 pt-5 border-t border-stone-100">
            <div className="flex items-center justify-between mb-3">
              <span className="text-[10px] font-mono font-bold text-stone-400 uppercase tracking-widest">
                Quick Demo Accounts
              </span>
              <span className="text-[10px] font-mono text-amber-800 flex items-center gap-1 font-semibold">
                <Sparkles className="w-3 h-3 text-amber-600" /> 1-Click Sign In
              </span>
            </div>

            <div className="space-y-2">
              {/* Persona 1: Muhammad Salman */}
              <motion.button
                whileHover={{ scale: 1.02, x: 2 }}
                whileTap={{ scale: 0.98 }}
                type="button"
                id="btn-quick-login-salman"
                onClick={() => handleQuickLogin(0)}
                className="w-full p-2.5 bg-amber-50/70 hover:bg-amber-100/80 border border-amber-200/80 rounded-xl text-left flex items-center justify-between transition-all group cursor-pointer"
              >
                <div className="flex items-center gap-2.5">
                  <div className="w-8 h-8 rounded-lg bg-[#1C1917] text-amber-200 font-bold text-xs flex items-center justify-center shadow-xs">
                    MS
                  </div>
                  <div>
                    <div className="flex items-center gap-1.5">
                      <p className="text-xs font-bold text-stone-900 group-hover:text-amber-900 transition-colors">
                        Muhammad Salman
                      </p>
                      <span className="text-[9px] px-1.5 py-0.2 rounded bg-amber-200 text-amber-900 font-bold">
                        Primary
                      </span>
                    </div>
                    <p className="text-[10px] text-stone-500 font-medium">Managing Director & Owner</p>
                  </div>
                </div>
                <span className="text-xs text-amber-800 font-bold group-hover:translate-x-1 transition-transform">
                  Enter →
                </span>
              </motion.button>

              {/* Persona 2: Haji Tariq Mahmood */}
              <motion.button
                whileHover={{ scale: 1.02, x: 2 }}
                whileTap={{ scale: 0.98 }}
                type="button"
                id="btn-quick-login-tariq"
                onClick={() => handleQuickLogin(1)}
                className="w-full p-2.5 bg-stone-50 hover:bg-stone-100 border border-stone-200 rounded-xl text-left flex items-center justify-between transition-all group cursor-pointer"
              >
                <div className="flex items-center gap-2.5">
                  <div className="w-8 h-8 rounded-lg bg-[#292524] text-amber-100 font-bold text-xs flex items-center justify-center">
                    TM
                  </div>
                  <div>
                    <p className="text-xs font-bold text-stone-900 group-hover:text-amber-900 transition-colors">
                      Haji Tariq Mahmood
                    </p>
                    <p className="text-[10px] text-stone-500 font-medium">Senior Executive Director</p>
                  </div>
                </div>
                <span className="text-xs text-amber-800 font-semibold group-hover:translate-x-1 transition-transform">
                  Enter →
                </span>
              </motion.button>

              {/* Persona 3: Asim Rafique */}
              <motion.button
                whileHover={{ scale: 1.02, x: 2 }}
                whileTap={{ scale: 0.98 }}
                type="button"
                id="btn-quick-login-asim"
                onClick={() => handleQuickLogin(2)}
                className="w-full p-2.5 bg-stone-50 hover:bg-stone-100 border border-stone-200 rounded-xl text-left flex items-center justify-between transition-all group cursor-pointer"
              >
                <div className="flex items-center gap-2.5">
                  <div className="w-8 h-8 rounded-lg bg-[#3D3228] text-amber-200 font-bold text-xs flex items-center justify-center">
                    AR
                  </div>
                  <div>
                    <p className="text-xs font-bold text-stone-900 group-hover:text-amber-900 transition-colors">
                      Asim Rafique
                    </p>
                    <p className="text-[10px] text-stone-500 font-medium">Head of Import & Logistics</p>
                  </div>
                </div>
                <span className="text-xs text-amber-800 font-semibold group-hover:translate-x-1 transition-transform">
                  Enter →
                </span>
              </motion.button>
            </div>
          </div>
        </motion.div>

        {/* Footer info */}
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ duration: 0.4, delay: 0.3 }}
          className="text-center mt-6 text-xs text-stone-500 flex items-center justify-center gap-4 font-mono"
        >
          <span className="flex items-center gap-1.5">
            <ShieldCheck className="w-3.5 h-3.5 text-emerald-700" /> 256-Bit Encrypted
          </span>
          <span>•</span>
          <span className="flex items-center gap-1.5">
            <Globe2 className="w-3.5 h-3.5 text-stone-600" /> China & Gulf Trade
          </span>
        </motion.div>
      </div>
    </div>
  );
};
