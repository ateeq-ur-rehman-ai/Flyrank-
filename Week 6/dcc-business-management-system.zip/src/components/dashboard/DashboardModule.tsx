import React, { useState } from 'react';
import {
  Users,
  CreditCard,
  AlertCircle,
  Container as ContainerIcon,
  Ship,
  TrendingUp,
  ArrowUpRight,
  Clock,
  CheckCircle2,
  Anchor,
  Box,
  Plus,
  ArrowRight,
  Calendar,
  Globe2,
  DollarSign,
  Sparkles,
  Zap,
} from 'lucide-react';
import { motion } from 'motion/react';
import { useApp } from '../../context/AppContext';
import { formatPKR, formatCurrency, formatDate, getContainerStatusBadge, getPaymentStatusBadge } from '../../utils/formatters';

export const DashboardModule: React.FC = () => {
  const {
    vendors,
    containers,
    payments,
    activities,
    setActiveModule,
    setSelectedContainerId,
    setIsContainerDetailsOpen,
    setIsAddPaymentOpen,
    setIsAddContainerOpen,
  } = useApp();

  const [chartTimeframe, setChartTimeframe] = useState<'6M' | '1Y'>('6M');

  // Key KPI calculations
  const totalVendors = vendors.length;
  const chineseVendorsCount = vendors.filter((v) => v.region === 'China').length;
  const gulfVendorsCount = vendors.filter((v) => v.region === 'Gulf').length;

  // Monthly Payments (Current month Aug 2026)
  const currentMonthPayments = payments.filter((p) => p.paymentDate.startsWith('2026-08') && p.status === 'Completed');
  const totalMonthlyPaymentsPKR = currentMonthPayments.reduce((acc, p) => acc + p.amountPKR, 0);

  // Pending Payments
  const pendingPayments = payments.filter((p) => p.status === 'Pending' || p.status === 'Scheduled');
  const totalPendingPaymentsPKR = pendingPayments.reduce((acc, p) => acc + p.amountPKR, 0);

  // Total Containers & Status Breakdown
  const totalContainers = containers.length;
  const inTransitCount = containers.filter((c) => c.status === 'In Transit').length;
  const arrivedCount = containers.filter((c) => c.status === 'Arrived').length;
  const unloadingCount = containers.filter((c) => c.status === 'Unloading').length;
  const unloadedCount = containers.filter((c) => c.status === 'Unloaded').length;
  const completedCount = containers.filter((c) => c.status === 'Completed').length;

  // Total Cargo Value on Water / Port
  const activeContainersValuePKR = containers
    .filter((c) => c.status !== 'Completed')
    .reduce((acc, c) => acc + c.shipmentValuePKR, 0);

  // Chart Data: Monthly Spend (Last 6 Months in PKR Millions)
  const monthlyChartData = [
    { month: 'Mar', spendPKR: 28.5, containers: 3, china: 18.0, gulf: 10.5 },
    { month: 'Apr', spendPKR: 34.2, containers: 4, china: 22.1, gulf: 12.1 },
    { month: 'May', spendPKR: 41.0, containers: 5, china: 29.5, gulf: 11.5 },
    { month: 'Jun', spendPKR: 37.8, containers: 4, china: 24.0, gulf: 13.8 },
    { month: 'Jul', spendPKR: 45.6, containers: 6, china: 31.2, gulf: 14.4 },
    { month: 'Aug (Cur)', spendPKR: 49.3, containers: 6, china: 35.8, gulf: 13.5 },
  ];

  const maxSpend = Math.max(...monthlyChartData.map((d) => d.spendPKR));

  return (
    <motion.div
      initial={{ opacity: 0, y: 10 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.3, ease: 'easeOut' }}
      className="p-3.5 sm:p-5 md:p-6 space-y-4 sm:space-y-6 max-w-7xl mx-auto"
    >
      {/* Top Operations Banner */}
      <motion.div
        initial={{ opacity: 0, scale: 0.98 }}
        animate={{ opacity: 1, scale: 1 }}
        transition={{ duration: 0.35 }}
        className="bg-[#1C1917] border border-stone-800 rounded-2xl p-4 sm:p-6 text-stone-100 flex flex-col md:flex-row md:items-center justify-between gap-4 shadow-md relative overflow-hidden"
      >
        <div className="relative z-10">
          <div className="flex items-center gap-2">
            <span className="px-2.5 py-0.5 rounded bg-[#38312B] text-amber-300 font-mono text-[10px] font-bold uppercase tracking-widest border border-amber-600/30 flex items-center gap-1">
              <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse"></span>
              Live Operations Summary
            </span>
            <span className="text-xs text-stone-400">
              August 2026
            </span>
          </div>
          <h2 className="text-xl sm:text-2xl font-bold text-stone-100 mt-1.5 tracking-tight flex items-center gap-2">
            Dubai Clothing Center (DCC)
          </h2>
          <p className="text-xs text-stone-300 mt-1 max-w-2xl">
            <strong className="text-amber-200 font-medium">{totalVendors} suppliers</strong> across China & Gulf countries •{' '}
            <strong className="text-amber-200 font-medium">{inTransitCount + arrivedCount + unloadingCount} active shipments</strong> en route & berthed at Karachi.
          </p>
        </div>

        <div className="flex items-center gap-2 sm:gap-2.5 shrink-0 flex-wrap sm:flex-nowrap relative z-10">
          <motion.button
            whileHover={{ scale: 1.03 }}
            whileTap={{ scale: 0.97 }}
            onClick={() => setIsAddContainerOpen(true)}
            className="px-3.5 py-2.5 bg-[#292524] hover:bg-[#342F2D] text-stone-200 text-xs font-semibold rounded-xl border border-stone-700 flex items-center gap-1.5 transition-colors shadow-sm cursor-pointer"
          >
            <ContainerIcon className="w-3.5 h-3.5 text-amber-400" />
            <span>Add Container</span>
          </motion.button>
          <motion.button
            whileHover={{ scale: 1.03 }}
            whileTap={{ scale: 0.97 }}
            onClick={() => setIsAddPaymentOpen(true)}
            className="px-4 py-2.5 bg-gradient-to-r from-amber-600 to-amber-700 hover:from-amber-500 hover:to-amber-600 text-white text-xs font-bold rounded-xl flex items-center gap-1.5 transition-all shadow-md cursor-pointer"
          >
            <Plus className="w-3.5 h-3.5" />
            <span>Add Payment</span>
          </motion.button>
        </div>
      </motion.div>

      {/* 4 Primary KPI Cards with Stagger and Hover Lifts */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3 sm:gap-4">
        {/* Card 1: Total Vendors */}
        <motion.div
          whileHover={{ y: -3, transition: { duration: 0.15 } }}
          whileTap={{ scale: 0.99 }}
          onClick={() => setActiveModule('vendors')}
          className="bg-white border border-stone-200 rounded-2xl p-4 sm:p-5 hover:border-stone-400 hover:shadow-md transition-all cursor-pointer group shadow-sm"
        >
          <div className="flex items-center justify-between mb-2 sm:mb-3">
            <span className="text-xs font-mono font-semibold tracking-wider text-stone-600 uppercase">Total Vendors</span>
            <div className="p-2 rounded-lg bg-stone-100 text-stone-700 group-hover:bg-[#1C1917] group-hover:text-amber-200 transition-colors">
              <Users className="w-4 h-4" />
            </div>
          </div>
          <div className="flex items-baseline justify-between">
            <span className="text-2xl sm:text-3xl font-bold text-stone-900 font-mono-num">
              {totalVendors}
            </span>
            <span className="text-xs text-amber-800 font-semibold group-hover:translate-x-1 transition-transform flex items-center">
              View All →
            </span>
          </div>
          <div className="mt-3 pt-2.5 border-t border-stone-100 flex items-center justify-between text-xs text-stone-500">
            <span>🇨🇳 China: <strong className="text-stone-800 font-semibold">{chineseVendorsCount}</strong></span>
            <span>🇦🇪 Gulf: <strong className="text-stone-800 font-semibold">{gulfVendorsCount}</strong></span>
          </div>
        </motion.div>

        {/* Card 2: Monthly Payments */}
        <motion.div
          whileHover={{ y: -3, transition: { duration: 0.15 } }}
          whileTap={{ scale: 0.99 }}
          onClick={() => setActiveModule('vendors')}
          className="bg-white border border-stone-200 rounded-2xl p-4 sm:p-5 hover:border-stone-400 hover:shadow-md transition-all cursor-pointer group shadow-sm"
        >
          <div className="flex items-center justify-between mb-2 sm:mb-3">
            <span className="text-xs font-mono font-semibold tracking-wider text-stone-600 uppercase">Monthly Payments</span>
            <div className="p-2 rounded-lg bg-emerald-50 text-emerald-800 group-hover:bg-emerald-800 group-hover:text-emerald-50 transition-colors">
              <CreditCard className="w-4 h-4" />
            </div>
          </div>
          <div className="flex items-baseline justify-between">
            <span className="text-2xl sm:text-3xl font-bold text-emerald-800 font-mono-num">
              {formatPKR(totalMonthlyPaymentsPKR, true)}
            </span>
            <span className="text-[11px] font-mono text-stone-500">
              {currentMonthPayments.length} paid
            </span>
          </div>
          <div className="mt-3 pt-2.5 border-t border-stone-100 text-xs text-stone-500 flex items-center justify-between">
            <span>Settled this month:</span>
            <span className="text-stone-800 font-semibold font-mono-num">
              {formatPKR(totalMonthlyPaymentsPKR)}
            </span>
          </div>
        </motion.div>

        {/* Card 3: Pending Payments */}
        <motion.div
          whileHover={{ y: -3, transition: { duration: 0.15 } }}
          whileTap={{ scale: 0.99 }}
          onClick={() => setActiveModule('vendors')}
          className="bg-white border border-stone-200 rounded-2xl p-4 sm:p-5 hover:border-stone-400 hover:shadow-md transition-all cursor-pointer group shadow-sm"
        >
          <div className="flex items-center justify-between mb-2 sm:mb-3">
            <span className="text-xs font-mono font-semibold tracking-wider text-stone-600 uppercase">Pending Payments</span>
            <div className="p-2 rounded-lg bg-rose-50 text-rose-800 group-hover:bg-rose-800 group-hover:text-rose-50 transition-colors">
              <AlertCircle className="w-4 h-4" />
            </div>
          </div>
          <div className="flex items-baseline justify-between">
            <span className="text-2xl sm:text-3xl font-bold text-rose-800 font-mono-num">
              {formatPKR(totalPendingPaymentsPKR, true)}
            </span>
            <span className="text-xs font-mono text-rose-700 font-medium px-2 py-0.5 rounded-full bg-rose-50 border border-rose-200">
              {pendingPayments.length} due
            </span>
          </div>
          <div className="mt-3 pt-2.5 border-t border-stone-100 text-xs text-stone-500 flex items-center justify-between">
            <span>Next due:</span>
            <span className="text-stone-800 font-semibold truncate max-w-[140px]">Shaoxing TT (28 Aug)</span>
          </div>
        </motion.div>

        {/* Card 4: Total Containers */}
        <motion.div
          whileHover={{ y: -3, transition: { duration: 0.15 } }}
          whileTap={{ scale: 0.99 }}
          onClick={() => setActiveModule('containers')}
          className="bg-white border border-stone-200 rounded-2xl p-4 sm:p-5 hover:border-stone-400 hover:shadow-md transition-all cursor-pointer group shadow-sm"
        >
          <div className="flex items-center justify-between mb-2 sm:mb-3">
            <span className="text-xs font-mono font-semibold tracking-wider text-stone-600 uppercase">Total Containers</span>
            <div className="p-2 rounded-lg bg-amber-50 text-amber-800 group-hover:bg-amber-800 group-hover:text-amber-50 transition-colors">
              <ContainerIcon className="w-4 h-4" />
            </div>
          </div>
          <div className="flex items-baseline justify-between">
            <span className="text-2xl sm:text-3xl font-bold text-stone-900 font-mono-num">
              {totalContainers}
            </span>
            <span className="text-xs font-mono font-medium text-amber-800 bg-amber-50 px-2 py-0.5 rounded-full border border-amber-200">
              {inTransitCount + arrivedCount + unloadingCount} active
            </span>
          </div>
          <div className="mt-3 pt-2.5 border-t border-stone-100 text-xs text-stone-500 flex items-center justify-between">
            <span>Cargo Value:</span>
            <span className="text-stone-800 font-semibold font-mono-num">
              {formatPKR(activeContainersValuePKR, true)}
            </span>
          </div>
        </motion.div>
      </div>

      {/* Container Status Breakdown Section */}
      <div className="bg-white border border-stone-200 rounded-2xl p-4 sm:p-5 shadow-sm">
        <div className="flex items-center justify-between mb-3.5">
          <div className="flex items-center gap-2">
            <Anchor className="w-4 h-4 text-stone-700" />
            <h3 className="text-xs font-mono font-bold text-stone-700 uppercase tracking-widest">
              Container Status Overview
            </h3>
          </div>
          <button
            onClick={() => setActiveModule('containers')}
            className="text-xs text-amber-800 hover:text-amber-900 font-semibold flex items-center gap-1 cursor-pointer"
          >
            <span>View All Shipments</span>
            <ArrowRight className="w-3 h-3" />
          </button>
        </div>

        <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-5 gap-2.5 sm:gap-3">
          {/* In Transit */}
          <motion.div
            whileHover={{ scale: 1.02, y: -2 }}
            whileTap={{ scale: 0.98 }}
            onClick={() => setActiveModule('containers')}
            className="bg-stone-50/80 border border-stone-200 rounded-xl p-3 sm:p-3.5 hover:border-stone-400 hover:bg-stone-100/60 transition-all cursor-pointer shadow-2xs"
          >
            <div className="flex items-center justify-between text-xs text-stone-700 font-medium mb-1">
              <span className="flex items-center gap-1.5 font-semibold">
                <span className="w-2 h-2 rounded-full bg-sky-600 animate-pulse"></span>
                In Transit
              </span>
              <Ship className="w-3.5 h-3.5 text-stone-500" />
            </div>
            <div className="text-xl sm:text-2xl font-bold text-stone-900 font-mono-num">{inTransitCount}</div>
            <p className="text-[10px] text-stone-500 font-mono mt-0.5">On high seas</p>
          </motion.div>

          {/* Arrived at Port */}
          <motion.div
            whileHover={{ scale: 1.02, y: -2 }}
            whileTap={{ scale: 0.98 }}
            onClick={() => setActiveModule('containers')}
            className="bg-stone-50/80 border border-stone-200 rounded-xl p-3 sm:p-3.5 hover:border-stone-400 hover:bg-stone-100/60 transition-all cursor-pointer shadow-2xs"
          >
            <div className="flex items-center justify-between text-xs text-amber-800 font-medium mb-1">
              <span className="flex items-center gap-1.5 font-semibold">
                <span className="w-2 h-2 rounded-full bg-amber-600"></span>
                Arrived Port
              </span>
              <Anchor className="w-3.5 h-3.5 text-amber-700" />
            </div>
            <div className="text-xl sm:text-2xl font-bold text-stone-900 font-mono-num">{arrivedCount}</div>
            <p className="text-[10px] text-stone-500 font-mono mt-0.5">Karachi Ports</p>
          </motion.div>

          {/* Unloading */}
          <motion.div
            whileHover={{ scale: 1.02, y: -2 }}
            whileTap={{ scale: 0.98 }}
            onClick={() => setActiveModule('containers')}
            className="bg-stone-50/80 border border-stone-200 rounded-xl p-3 sm:p-3.5 hover:border-stone-400 hover:bg-stone-100/60 transition-all cursor-pointer shadow-2xs"
          >
            <div className="flex items-center justify-between text-xs text-purple-800 font-medium mb-1">
              <span className="flex items-center gap-1.5 font-semibold">
                <span className="w-2 h-2 rounded-full bg-purple-600"></span>
                Unloading
              </span>
              <Box className="w-3.5 h-3.5 text-purple-700" />
            </div>
            <div className="text-xl sm:text-2xl font-bold text-stone-900 font-mono-num">{unloadingCount}</div>
            <p className="text-[10px] text-stone-500 font-mono mt-0.5">At warehouse</p>
          </motion.div>

          {/* Unloaded */}
          <motion.div
            whileHover={{ scale: 1.02, y: -2 }}
            whileTap={{ scale: 0.98 }}
            onClick={() => setActiveModule('containers')}
            className="bg-stone-50/80 border border-stone-200 rounded-xl p-3 sm:p-3.5 hover:border-stone-400 hover:bg-stone-100/60 transition-all cursor-pointer shadow-2xs"
          >
            <div className="flex items-center justify-between text-xs text-teal-800 font-medium mb-1">
              <span className="flex items-center gap-1.5 font-semibold">
                <span className="w-2 h-2 rounded-full bg-teal-600"></span>
                Unloaded
              </span>
              <CheckCircle2 className="w-3.5 h-3.5 text-teal-700" />
            </div>
            <div className="text-xl sm:text-2xl font-bold text-stone-900 font-mono-num">{unloadedCount}</div>
            <p className="text-[10px] text-stone-500 font-mono mt-0.5">QC check</p>
          </motion.div>

          {/* Completed */}
          <motion.div
            whileHover={{ scale: 1.02, y: -2 }}
            whileTap={{ scale: 0.98 }}
            onClick={() => setActiveModule('containers')}
            className="col-span-2 sm:col-span-1 bg-stone-50/80 border border-stone-200 rounded-xl p-3 sm:p-3.5 hover:border-stone-400 hover:bg-stone-100/60 transition-all cursor-pointer shadow-2xs"
          >
            <div className="flex items-center justify-between text-xs text-emerald-800 font-medium mb-1">
              <span className="flex items-center gap-1.5 font-semibold">
                <span className="w-2 h-2 rounded-full bg-emerald-600"></span>
                Completed
              </span>
              <CheckCircle2 className="w-3.5 h-3.5 text-emerald-700" />
            </div>
            <div className="text-xl sm:text-2xl font-bold text-stone-900 font-mono-num">{completedCount}</div>
            <p className="text-[10px] text-stone-500 font-mono mt-0.5">Shelved & closed</p>
          </motion.div>
        </div>
      </div>

      {/* Middle Section: Visual Charts */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4 sm:gap-6">
        {/* Chart 1: Monthly Import Spend & Volume */}
        <div className="lg:col-span-2 bg-white border border-stone-200 rounded-2xl p-4 sm:p-5 shadow-sm">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 mb-5 pb-3 border-b border-stone-100">
            <div>
              <h3 className="text-base font-bold text-stone-900 flex items-center gap-2">
                <TrendingUp className="w-4 h-4 text-amber-800" />
                Monthly Import Spend (PKR Millions)
              </h3>
              <p className="text-xs text-stone-500 mt-0.5">
                China vs Gulf import payments over the last 6 months
              </p>
            </div>
            <div className="flex items-center gap-3 text-xs">
              <span className="flex items-center gap-1.5 text-stone-800 font-medium font-mono text-[11px]">
                <span className="w-3 h-3 rounded-sm bg-[#1C1917]"></span> China
              </span>
              <span className="flex items-center gap-1.5 text-amber-800 font-medium font-mono text-[11px]">
                <span className="w-3 h-3 rounded-sm bg-amber-600"></span> Gulf
              </span>
            </div>
          </div>

          {/* Bar Chart with animated spring heights */}
          <div className="h-56 w-full flex items-end justify-between gap-2 sm:gap-4 pt-6 pb-2 px-1 sm:px-2 overflow-x-auto">
            {monthlyChartData.map((item, idx) => {
              const heightPercent = (item.spendPKR / maxSpend) * 100;
              const chinaHeightPercent = (item.china / item.spendPKR) * 100;
              const gulfHeightPercent = (item.gulf / item.spendPKR) * 100;

              return (
                <div key={idx} className="flex-1 min-w-[38px] flex flex-col items-center h-full justify-end group relative">
                  {/* Tooltip on hover */}
                  <div className="absolute -top-12 bg-[#1C1917] border border-stone-700 text-stone-100 text-[11px] rounded-lg px-2.5 py-1 pointer-events-none opacity-0 group-hover:opacity-100 transition-opacity z-20 whitespace-nowrap shadow-xl">
                    <p className="font-bold font-mono-num">Rs. {item.spendPKR.toFixed(1)}M Total</p>
                    <p className="text-[10px] text-stone-300">
                      China: {item.china}M | Gulf: {item.gulf}M ({item.containers} cont.)
                    </p>
                  </div>

                  {/* Top value label */}
                  <span className="text-[10px] font-bold text-stone-700 font-mono-num mb-1.5 group-hover:text-amber-800 transition-colors">
                    {item.spendPKR.toFixed(1)}M
                  </span>

                  {/* Stacked animated bar */}
                  <motion.div
                    initial={{ height: 0 }}
                    animate={{ height: `${heightPercent}%` }}
                    transition={{ duration: 0.6, delay: idx * 0.08, ease: 'easeOut' }}
                    className="w-full max-w-[44px] rounded-t-sm overflow-hidden flex flex-col justify-end bg-stone-100 group-hover:brightness-105 transition-all cursor-pointer border border-stone-200"
                  >
                    <div
                      style={{ height: `${chinaHeightPercent}%` }}
                      className="w-full bg-[#1C1917]"
                    ></div>
                    <div
                      style={{ height: `${gulfHeightPercent}%` }}
                      className="w-full bg-amber-700 border-t border-stone-800"
                    ></div>
                  </motion.div>

                  {/* X-axis label */}
                  <span className="text-[10px] sm:text-[11px] text-stone-600 font-mono font-medium mt-2">
                    {item.month}
                  </span>
                </div>
              );
            })}
          </div>

          <div className="mt-3 pt-3 border-t border-stone-100 flex items-center justify-between text-xs text-stone-500 font-mono">
            <span>Avg Monthly Import: <strong className="text-stone-800 font-mono-num">Rs. 39.4M</strong></span>
            <span>Fiscal Year: <strong className="text-stone-800">2026</strong></span>
          </div>
        </div>

        {/* Chart 2: Regional Import Distribution */}
        <div className="bg-white border border-stone-200 rounded-2xl p-4 sm:p-5 shadow-sm flex flex-col justify-between">
          <div>
            <h3 className="text-base font-bold text-stone-900 flex items-center gap-2">
              <Globe2 className="w-4 h-4 text-emerald-700" />
              Regional Sourcing Split
            </h3>
            <p className="text-xs text-stone-500 mt-0.5">
              Share of total 2026 import volume
            </p>
          </div>

          {/* Distribution list with animated bar fills */}
          <div className="space-y-3.5 my-4">
            <div>
              <div className="flex justify-between text-xs mb-1">
                <span className="font-medium text-stone-800 flex items-center gap-1.5">
                  <span>🇨🇳</span> China (Shaoxing & Guangzhou)
                </span>
                <span className="font-bold text-stone-900 font-mono-num">64% (Rs. 173.8M)</span>
              </div>
              <div className="w-full h-2 bg-stone-100 rounded-full overflow-hidden border border-stone-200">
                <motion.div
                  initial={{ width: 0 }}
                  animate={{ width: '64%' }}
                  transition={{ duration: 0.8, ease: 'easeOut' }}
                  className="h-full bg-[#1C1917] rounded-full"
                ></motion.div>
              </div>
            </div>

            <div>
              <div className="flex justify-between text-xs mb-1">
                <span className="font-medium text-stone-800 flex items-center gap-1.5">
                  <span>🇦🇪</span> UAE (Dubai & Sharjah)
                </span>
                <span className="font-bold text-stone-900 font-mono-num">21% (Rs. 56.7M)</span>
              </div>
              <div className="w-full h-2 bg-stone-100 rounded-full overflow-hidden border border-stone-200">
                <motion.div
                  initial={{ width: 0 }}
                  animate={{ width: '21%' }}
                  transition={{ duration: 0.8, delay: 0.1, ease: 'easeOut' }}
                  className="h-full bg-amber-700 rounded-full"
                ></motion.div>
              </div>
            </div>

            <div>
              <div className="flex justify-between text-xs mb-1">
                <span className="font-medium text-stone-800 flex items-center gap-1.5">
                  <span>🇸🇦</span> Saudi Arabia (Riyadh)
                </span>
                <span className="font-bold text-stone-900 font-mono-num">9% (Rs. 24.5M)</span>
              </div>
              <div className="w-full h-2 bg-stone-100 rounded-full overflow-hidden border border-stone-200">
                <motion.div
                  initial={{ width: 0 }}
                  animate={{ width: '9%' }}
                  transition={{ duration: 0.8, delay: 0.2, ease: 'easeOut' }}
                  className="h-full bg-emerald-700 rounded-full"
                ></motion.div>
              </div>
            </div>

            <div>
              <div className="flex justify-between text-xs mb-1">
                <span className="font-medium text-stone-800 flex items-center gap-1.5">
                  <span>🇰🇼 🇶🇦</span> Kuwait & Qatar
                </span>
                <span className="font-bold text-stone-900 font-mono-num">6% (Rs. 16.2M)</span>
              </div>
              <div className="w-full h-2 bg-stone-100 rounded-full overflow-hidden border border-stone-200">
                <motion.div
                  initial={{ width: 0 }}
                  animate={{ width: '6%' }}
                  transition={{ duration: 0.8, delay: 0.3, ease: 'easeOut' }}
                  className="h-full bg-stone-500 rounded-full"
                ></motion.div>
              </div>
            </div>
          </div>

          <div className="p-3 rounded-xl bg-stone-50 border border-stone-200 text-xs flex items-center justify-between">
            <span className="text-stone-600">Total Imports:</span>
            <span className="text-amber-900 font-bold font-mono-num">Rs. 271.2M</span>
          </div>
        </div>
      </div>

      {/* Bottom Section: Active Containers & Recent Activity */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4 sm:gap-6">
        {/* Active Shipments Table */}
        <div className="lg:col-span-2 bg-white border border-stone-200 rounded-2xl p-4 sm:p-5 shadow-sm">
          <div className="flex items-center justify-between mb-4 pb-2 border-b border-stone-100">
            <div>
              <h3 className="text-base font-bold text-stone-900 flex items-center gap-2">
                <Ship className="w-4 h-4 text-stone-700" />
                Live Shipments & Vessels
              </h3>
              <p className="text-xs text-stone-500 mt-0.5">
                Vessels in transit and berthed at Karachi Ports
              </p>
            </div>
            <button
              onClick={() => setActiveModule('containers')}
              className="text-xs text-amber-800 hover:text-amber-900 font-semibold flex items-center gap-1 cursor-pointer"
            >
              <span>View All</span>
              <ArrowRight className="w-3 h-3" />
            </button>
          </div>

          <div className="overflow-x-auto rounded-xl">
            <table className="w-full text-left text-xs min-w-[500px]">
              <thead>
                <tr className="border-b border-stone-200 text-stone-600 font-mono text-[11px] bg-stone-50/50">
                  <th className="py-2.5 pl-3">Container #</th>
                  <th className="py-2.5">Vendor & Origin</th>
                  <th className="py-2.5">Status</th>
                  <th className="py-2.5">Value (PKR)</th>
                  <th className="py-2.5">Arrival ETA</th>
                  <th className="py-2.5 text-right pr-3">Action</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-stone-100">
                {containers.slice(0, 4).map((c) => {
                  const badge = getContainerStatusBadge(c.status);
                  return (
                    <tr
                      key={c.id}
                      className="hover:bg-amber-50/30 transition-colors group cursor-pointer"
                      onClick={() => {
                        setSelectedContainerId(c.id);
                        setIsContainerDetailsOpen(true);
                      }}
                    >
                      <td className="py-3 pl-3 font-bold text-stone-900 font-mono flex items-center gap-1.5">
                        <span className="w-1.5 h-1.5 rounded-full bg-amber-600"></span>
                        {c.containerNumber}
                      </td>
                      <td className="py-3">
                        <p className="font-semibold text-stone-800 truncate max-w-[160px]">
                          {c.vendorName}
                        </p>
                        <p className="text-[11px] text-stone-500 font-mono">
                          {c.originCountry} • {c.portOfLoading.split(',')[0]}
                        </p>
                      </td>
                      <td className="py-3">
                        <span className={`inline-flex items-center gap-1 text-[11px] font-bold px-2.5 py-0.5 rounded-full border ${badge.bg} ${badge.border}`}>
                          <span className={`w-1.5 h-1.5 rounded-full ${badge.dot}`}></span>
                          {badge.text}
                        </span>
                      </td>
                      <td className="py-3 font-semibold text-stone-800 font-mono-num">
                        {formatPKR(c.shipmentValuePKR, true)}
                        <span className="text-[10px] text-stone-500 block font-normal font-mono">
                          {formatCurrency(c.shipmentValue, c.currency)}
                        </span>
                      </td>
                      <td className="py-3 text-stone-700 font-mono">
                        {formatDate(c.expectedArrival)}
                      </td>
                      <td className="py-3 text-right pr-3">
                        <button
                          onClick={(e) => {
                            e.stopPropagation();
                            setSelectedContainerId(c.id);
                            setIsContainerDetailsOpen(true);
                          }}
                          className="px-2.5 py-1 bg-stone-100 hover:bg-[#1C1917] hover:text-amber-100 text-stone-700 rounded-lg text-xs font-semibold transition-colors border border-stone-200 cursor-pointer"
                        >
                          Details
                        </button>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </div>

        {/* Recent Activity Feed */}
        <div className="bg-white border border-stone-200 rounded-2xl p-4 sm:p-5 shadow-sm flex flex-col justify-between">
          <div>
            <div className="flex items-center justify-between mb-3 pb-2 border-b border-stone-100">
              <h3 className="text-base font-bold text-stone-900 flex items-center gap-2">
                <Clock className="w-4 h-4 text-amber-800" />
                Recent Activity
              </h3>
              <span className="text-[10px] font-mono text-stone-400">Live logs</span>
            </div>

            <div className="space-y-2.5">
              {activities.slice(0, 5).map((act, index) => (
                <motion.div
                  key={act.id}
                  initial={{ opacity: 0, x: 6 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{ duration: 0.2, delay: index * 0.05 }}
                  className="p-2.5 rounded-xl bg-stone-50 border border-stone-200/80 hover:border-amber-300 hover:bg-amber-50/20 transition-all shadow-2xs"
                >
                  <div className="flex items-center justify-between text-[10px] text-stone-400 mb-1 font-mono">
                    <span className="font-bold text-amber-800 uppercase tracking-wider">
                      {act.tag || act.type}
                    </span>
                    <span>{act.timestamp}</span>
                  </div>
                  <p className="text-xs font-semibold text-stone-800 leading-tight">
                    {act.title}
                  </p>
                  <p className="text-[11px] text-stone-500 mt-0.5 leading-snug">
                    {act.description}
                  </p>
                </motion.div>
              ))}
            </div>
          </div>

          <div className="mt-4 pt-3 border-t border-stone-100">
            <button
              onClick={() => setActiveModule('reports')}
              className="w-full py-2.5 bg-stone-100 hover:bg-stone-200 text-stone-800 rounded-xl text-xs font-semibold transition-colors flex items-center justify-center gap-1.5 border border-stone-200 cursor-pointer"
            >
              <span>View Full Reports</span>
              <ArrowRight className="w-3.5 h-3.5" />
            </button>
          </div>
        </div>
      </div>
    </motion.div>
  );
};
