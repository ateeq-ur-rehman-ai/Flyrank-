import React from 'react';
import {
  X,
  Building2,
  MapPin,
  Mail,
  Phone,
  CreditCard,
  Container as ContainerIcon,
  Plus,
  CheckCircle2,
  AlertCircle,
  ExternalLink,
  DollarSign,
  Calendar,
} from 'lucide-react';
import { motion } from 'motion/react';
import { useApp } from '../../context/AppContext';
import { formatPKR, formatCurrency, formatDate, getPaymentStatusBadge, getContainerStatusBadge } from '../../utils/formatters';

export const VendorDetailModal: React.FC = () => {
  const {
    selectedVendorId,
    setSelectedVendorId,
    isVendorDetailsOpen,
    setIsVendorDetailsOpen,
    getVendorById,
    containers,
    payments,
    setIsAddPaymentOpen,
    setSelectedContainerId,
    setIsContainerDetailsOpen,
  } = useApp();

  if (!isVendorDetailsOpen || !selectedVendorId) return null;

  const vendor = getVendorById(selectedVendorId);
  if (!vendor) return null;

  const vendorContainers = containers.filter((c) => c.vendorId === vendor.id);
  const vendorPayments = payments.filter((p) => p.vendorId === vendor.id);

  const paidPercentage = vendor.totalImportValuePKR > 0
    ? Math.min(100, Math.round((vendor.totalPaidPKR / vendor.totalImportValuePKR) * 100))
    : 100;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-xs">
      <motion.div
        initial={{ opacity: 0, scale: 0.96, y: 8 }}
        animate={{ opacity: 1, scale: 1, y: 0 }}
        exit={{ opacity: 0, scale: 0.96, y: 8 }}
        transition={{ duration: 0.2, ease: 'easeOut' }}
        className="bg-white border border-stone-300 rounded-2xl w-full max-w-4xl max-h-[90vh] flex flex-col shadow-2xl overflow-hidden"
      >
        {/* Modal Header */}
        <div className="p-6 border-b border-stone-200 flex items-start justify-between bg-stone-50/80">
          <div className="flex items-start gap-4">
            <div className="w-12 h-12 rounded-xl bg-amber-100 text-stone-800 font-bold flex items-center justify-center text-lg border border-amber-200 shrink-0 mt-1">
              {vendor.region === 'China' ? '🇨🇳' : '🇦🇪'}
            </div>
            <div>
              <div className="flex items-center gap-2">
                <span className="text-[10px] font-mono font-bold px-2 py-0.5 rounded bg-stone-200/70 text-stone-800 border border-stone-300">
                  {vendor.code}
                </span>
                <span className="text-xs text-stone-600 flex items-center gap-1">
                  <MapPin className="w-3 h-3 text-stone-500" />
                  {vendor.city}, {vendor.country}
                </span>
              </div>
              <h2 className="text-2xl font-bold text-stone-900 mt-1">
                {vendor.name}
              </h2>
              <p className="text-xs text-stone-600 mt-0.5">
                Specialization: <strong className="text-stone-800">{vendor.category}</strong>
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={() => {
                setIsAddPaymentOpen(true);
              }}
              className="px-3 py-1.5 bg-[#1C1917] hover:bg-stone-800 text-amber-100 rounded-xl text-xs font-bold transition-colors flex items-center gap-1.5 shadow-2xs"
            >
              <Plus className="w-3.5 h-3.5" />
              <span>Record Payment</span>
            </button>
            <button
              onClick={() => setIsVendorDetailsOpen(false)}
              className="p-2 rounded-xl text-stone-400 hover:text-stone-800 hover:bg-stone-100 transition-colors"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Modal Body */}
        <div className="p-6 space-y-6 overflow-y-auto flex-1">
          {/* Financial Overview Cards */}
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
            <div className="bg-stone-50 border border-stone-200 rounded-xl p-4">
              <span className="text-xs font-mono uppercase tracking-wider text-stone-500 font-semibold block">Total Imported (PKR)</span>
              <span className="text-xl font-bold text-stone-900 font-mono-num mt-1 block">
                {formatPKR(vendor.totalImportValuePKR)}
              </span>
              <span className="text-[11px] text-stone-500 mt-1 block font-mono-num">
                ~ {formatPKR(vendor.totalImportValuePKR, true)}
              </span>
            </div>

            <div className="bg-stone-50 border border-stone-200 rounded-xl p-4">
              <span className="text-xs font-mono uppercase tracking-wider text-stone-500 font-semibold block">Total Paid (Settled)</span>
              <span className="text-xl font-bold text-emerald-800 font-mono-num mt-1 block">
                {formatPKR(vendor.totalPaidPKR)}
              </span>
              <div className="w-full h-1.5 bg-stone-200 rounded-full mt-2 overflow-hidden">
                <div className="h-full bg-emerald-700" style={{ width: `${paidPercentage}%` }}></div>
              </div>
            </div>

            <div className="bg-stone-50 border border-stone-200 rounded-xl p-4">
              <span className="text-xs font-mono uppercase tracking-wider text-stone-500 font-semibold block">Outstanding Balance</span>
              <span className="text-xl font-bold text-amber-900 font-mono-num mt-1 block">
                {formatPKR(vendor.pendingBalancePKR)}
              </span>
              <span className="text-[11px] text-amber-900/80 mt-1 block font-medium">
                {vendor.pendingBalancePKR > 0 ? 'Pending invoice settlement' : 'Fully Settled ✓'}
              </span>
            </div>
          </div>

          {/* Contact & Banking Information Grid */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {/* Contact Details */}
            <div className="bg-stone-50 border border-stone-200 rounded-xl p-4 space-y-2.5">
              <h4 className="text-xs font-mono font-bold text-stone-700 uppercase tracking-wider flex items-center gap-1.5 mb-3">
                <Phone className="w-3.5 h-3.5 text-stone-600" />
                Contact & Communication
              </h4>

              <div className="flex justify-between text-xs py-1 border-b border-stone-200">
                <span className="text-stone-500">Representative:</span>
                <span className="font-semibold text-stone-800">{vendor.contactPerson}</span>
              </div>
              <div className="flex justify-between text-xs py-1 border-b border-stone-200">
                <span className="text-stone-500">Email:</span>
                <span className="text-stone-800 font-mono">{vendor.email}</span>
              </div>
              <div className="flex justify-between text-xs py-1 border-b border-stone-200">
                <span className="text-stone-500">Direct Phone:</span>
                <span className="font-mono text-stone-800">{vendor.phone}</span>
              </div>
              {vendor.weChatOrWhatsapp && (
                <div className="flex justify-between text-xs py-1 border-b border-stone-200">
                  <span className="text-stone-500">WeChat / WhatsApp:</span>
                  <span className="text-emerald-800 font-semibold font-mono">{vendor.weChatOrWhatsapp}</span>
                </div>
              )}
              <div className="flex justify-between text-xs py-1">
                <span className="text-stone-500">Factory / Mill Address:</span>
                <span className="text-stone-700 text-right max-w-[200px] truncate">{vendor.address}</span>
              </div>
            </div>

            {/* Bank Details */}
            <div className="bg-stone-50 border border-stone-200 rounded-xl p-4 space-y-2.5">
              <h4 className="text-xs font-mono font-bold text-stone-700 uppercase tracking-wider flex items-center gap-1.5 mb-3">
                <CreditCard className="w-3.5 h-3.5 text-stone-600" />
                Banking & Wire Transfer Details (TT/LC)
              </h4>

              <div className="flex justify-between text-xs py-1 border-b border-stone-200">
                <span className="text-stone-500">Beneficiary Bank:</span>
                <span className="font-semibold text-stone-800">{vendor.bankDetails.bankName}</span>
              </div>
              <div className="flex justify-between text-xs py-1 border-b border-stone-200">
                <span className="text-stone-500">SWIFT / BIC Code:</span>
                <span className="font-mono font-bold text-amber-900">{vendor.bankDetails.swiftCode}</span>
              </div>
              <div className="flex justify-between text-xs py-1 border-b border-stone-200">
                <span className="text-stone-500">Account / IBAN #:</span>
                <span className="font-mono text-stone-800 font-semibold">{vendor.bankDetails.accountNumber}</span>
              </div>
              <div className="flex justify-between text-xs py-1 border-b border-stone-200">
                <span className="text-stone-500">Account Name:</span>
                <span className="text-stone-800">{vendor.bankDetails.accountName}</span>
              </div>
              <div className="flex justify-between text-xs py-1">
                <span className="text-stone-500">Settlement Currency:</span>
                <span className="font-bold text-stone-900 font-mono">{vendor.bankDetails.currency}</span>
              </div>
            </div>
          </div>

          {/* Linked Shipments / Containers */}
          <div className="space-y-3">
            <h4 className="text-xs font-mono font-bold text-stone-700 uppercase tracking-wider flex items-center gap-1.5">
              <ContainerIcon className="w-3.5 h-3.5 text-stone-600" />
              Shipments & Containers from this Vendor ({vendorContainers.length})
            </h4>

            {vendorContainers.length > 0 ? (
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                {vendorContainers.map((c) => {
                  const badge = getContainerStatusBadge(c.status);
                  return (
                    <div
                      key={c.id}
                      onClick={() => {
                        setIsVendorDetailsOpen(false);
                        setSelectedContainerId(c.id);
                        setIsContainerDetailsOpen(true);
                      }}
                      className="p-3 bg-stone-50 border border-stone-200 hover:border-stone-400 rounded-xl cursor-pointer group transition-colors flex items-center justify-between"
                    >
                      <div>
                        <div className="flex items-center gap-2">
                          <span className="font-mono font-bold text-stone-900 text-xs group-hover:text-amber-900">
                            {c.containerNumber}
                          </span>
                          <span className={`text-[10px] font-mono font-bold px-2 py-0.2 rounded-full border ${badge.bg} ${badge.border}`}>
                            {badge.text}
                          </span>
                        </div>
                        <p className="text-[11px] text-stone-500 mt-1 font-mono">
                          Shipped: {formatDate(c.shipmentDate)} • ETA: {formatDate(c.expectedArrival)}
                        </p>
                      </div>

                      <div className="text-right">
                        <span className="text-xs font-bold text-stone-900 font-mono-num block">
                          {formatPKR(c.shipmentValuePKR, true)}
                        </span>
                        <span className="text-[10px] text-amber-900 font-medium group-hover:translate-x-0.5 transition-transform inline-block">
                          View Track →
                        </span>
                      </div>
                    </div>
                  );
                })}
              </div>
            ) : (
              <p className="text-xs text-stone-500 bg-stone-50 p-3 rounded-xl border border-stone-200">
                No active container shipments recorded yet for this supplier.
              </p>
            )}
          </div>

          {/* Payment History for this Vendor */}
          <div className="space-y-3">
            <h4 className="text-xs font-mono font-bold text-stone-700 uppercase tracking-wider flex items-center gap-1.5">
              <CreditCard className="w-3.5 h-3.5 text-stone-600" />
              Disbursement & TT Payment History ({vendorPayments.length})
            </h4>

            {vendorPayments.length > 0 ? (
              <div className="overflow-x-auto rounded-xl border border-stone-200">
                <table className="w-full text-left text-xs bg-white">
                  <thead className="bg-stone-100 text-stone-700 font-mono text-[11px] border-b border-stone-200">
                    <tr>
                      <th className="py-2.5 px-3">Payment Ref</th>
                      <th className="py-2.5 px-3">Date</th>
                      <th className="py-2.5 px-3">Foreign Amount</th>
                      <th className="py-2.5 px-3">Rate</th>
                      <th className="py-2.5 px-3">PKR Value</th>
                      <th className="py-2.5 px-3">Method</th>
                      <th className="py-2.5 px-3">Status</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-stone-100">
                    {vendorPayments.map((p) => {
                      const badge = getPaymentStatusBadge(p.status);
                      return (
                        <tr key={p.id} className="hover:bg-stone-50/80">
                          <td className="py-2.5 px-3 font-mono font-bold text-stone-900">{p.paymentRef}</td>
                          <td className="py-2.5 px-3 text-stone-600 font-mono">{formatDate(p.paymentDate)}</td>
                          <td className="py-2.5 px-3 font-bold text-stone-900 font-mono-num">{formatCurrency(p.amount, p.currency)}</td>
                          <td className="py-2.5 px-3 text-stone-500 font-mono-num">Rs. {p.exchangeRateToPKR.toFixed(2)}</td>
                          <td className="py-2.5 px-3 font-bold text-amber-900 font-mono-num">{formatPKR(p.amountPKR)}</td>
                          <td className="py-2.5 px-3 text-stone-700">{p.paymentMethod}</td>
                          <td className="py-2.5 px-3">
                            <span className={`px-2 py-0.5 rounded-full text-[10px] font-mono font-bold border ${badge.bg}`}>
                              {badge.text}
                            </span>
                          </td>
                        </tr>
                      );
                    })}
                  </tbody>
                </table>
              </div>
            ) : (
              <p className="text-xs text-stone-500 bg-stone-50 p-3 rounded-xl border border-stone-200">
                No past payment records logged yet.
              </p>
            )}
          </div>
        </div>

        {/* Modal Footer */}
        <div className="p-4 border-t border-stone-200 bg-stone-50/80 flex items-center justify-between text-xs">
          <span className="text-stone-500 font-mono">DCC Vendor File ID: {vendor.id}</span>
          <button
            onClick={() => setIsVendorDetailsOpen(false)}
            className="px-4 py-2 bg-stone-200 hover:bg-stone-300 text-stone-800 rounded-xl font-semibold transition-colors"
          >
            Close Vendor File
          </button>
        </div>
      </motion.div>
    </div>
  );
};
