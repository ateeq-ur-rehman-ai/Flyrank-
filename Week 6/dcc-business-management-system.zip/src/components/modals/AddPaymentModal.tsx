import React, { useState, useEffect } from 'react';
import { X, CreditCard, DollarSign, Calculator, Plus, Check } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import confetti from 'canvas-confetti';
import { useApp } from '../../context/AppContext';
import { CurrencyCode, PaymentMethod, PaymentStatus } from '../../types';
import { formatPKR, formatCurrency } from '../../utils/formatters';

export const AddPaymentModal: React.FC = () => {
  const {
    isAddPaymentOpen,
    setIsAddPaymentOpen,
    vendors,
    containers,
    currencies,
    addPayment,
    selectedVendorId,
  } = useApp();

  const [vendorId, setVendorId] = useState<string>('');
  const [containerId, setContainerId] = useState<string>('');
  const [invoiceNumber, setInvoiceNumber] = useState(`INV-DCC-${Math.floor(1000 + Math.random() * 9000)}`);
  const [paymentDate, setPaymentDate] = useState('2026-08-24');
  const [amount, setAmount] = useState<string>('150000');
  const [currency, setCurrency] = useState<CurrencyCode>('CNY');
  const [exchangeRate, setExchangeRate] = useState<number>(38.65);
  const [paymentMethod, setPaymentMethod] = useState<PaymentMethod>('Telegraphic Transfer (TT)');
  const [status, setStatus] = useState<PaymentStatus>('Completed');
  const [notes, setNotes] = useState('');

  // Sync initial vendor
  useEffect(() => {
    if (vendors.length > 0) {
      const targetVendorId = selectedVendorId || vendors[0].id;
      setVendorId(targetVendorId);
      const v = vendors.find((vend) => vend.id === targetVendorId);
      if (v) {
        setCurrency(v.bankDetails.currency);
        const currObj = currencies.find((c) => c.code === v.bankDetails.currency);
        if (currObj) setExchangeRate(currObj.rateToPKR);
      }
    }
  }, [isAddPaymentOpen, selectedVendorId, vendors]);

  // When currency changes, update exchange rate
  const handleCurrencyChange = (newCurr: CurrencyCode) => {
    setCurrency(newCurr);
    const currObj = currencies.find((c) => c.code === newCurr);
    if (currObj) {
      setExchangeRate(currObj.rateToPKR);
    }
  };

  // When vendor changes, set its currency
  const handleVendorChange = (id: string) => {
    setVendorId(id);
    const v = vendors.find((vend) => vend.id === id);
    if (v) {
      handleCurrencyChange(v.bankDetails.currency);
    }
  };

  if (!isAddPaymentOpen) return null;

  const selectedVendor = vendors.find((v) => v.id === vendorId);
  const vendorContainers = containers.filter((c) => c.vendorId === vendorId);

  const parsedAmount = parseFloat(amount) || 0;
  const calculatedPKR = parsedAmount * exchangeRate;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedVendor || parsedAmount <= 0) return;

    const linkedContainer = containers.find((c) => c.id === containerId);

    addPayment({
      vendorId: selectedVendor.id,
      vendorName: selectedVendor.name,
      vendorCountry: selectedVendor.country,
      containerId: containerId || undefined,
      containerNumber: linkedContainer ? linkedContainer.containerNumber : undefined,
      invoiceNumber: invoiceNumber.trim(),
      paymentDate,
      amount: parsedAmount,
      currency,
      exchangeRateToPKR: exchangeRate,
      paymentMethod,
      status,
      notes: notes.trim() || undefined,
    });

    triggerPaymentCelebration();
    setIsAddPaymentOpen(false);
  };

  const triggerPaymentCelebration = () => {
    confetti({
      particleCount: 50,
      spread: 60,
      origin: { y: 0.6 },
      colors: ['#D97706', '#10956a', '#1C1917'],
    });
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-xs">
      <motion.div
        initial={{ opacity: 0, scale: 0.95, y: 10 }}
        animate={{ opacity: 1, scale: 1, y: 0 }}
        exit={{ opacity: 0, scale: 0.95, y: 10 }}
        transition={{ duration: 0.2, ease: 'easeOut' }}
        className="bg-white border border-stone-300 rounded-2xl w-full max-w-2xl max-h-[90vh] flex flex-col shadow-2xl overflow-hidden"
      >
        {/* Header */}
        <div className="p-5 border-b border-stone-200 flex items-center justify-between bg-stone-50/80">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-amber-100 text-stone-800 flex items-center justify-center border border-amber-200">
              <CreditCard className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-base font-bold text-stone-900">Record Foreign Payment / TT</h3>
              <p className="text-xs text-stone-500">Execute or schedule payment with automatic PKR conversion</p>
            </div>
          </div>

          <button
            onClick={() => setIsAddPaymentOpen(false)}
            className="p-2 text-stone-400 hover:text-stone-800 hover:bg-stone-100 rounded-xl transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Form Body */}
        <form onSubmit={handleSubmit} className="p-6 space-y-4 overflow-y-auto flex-1 text-xs">
          {/* Vendor selection */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div>
              <label className="block font-semibold text-stone-700 mb-1">Beneficiary Vendor *</label>
              <select
                value={vendorId}
                onChange={(e) => handleVendorChange(e.target.value)}
                className="w-full px-3 py-2.5 bg-stone-50 border border-stone-300 rounded-xl text-stone-900 font-medium focus:outline-none focus:border-stone-500"
                required
              >
                {vendors.map((v) => (
                  <option key={v.id} value={v.id}>
                    {v.region === 'China' ? '🇨🇳' : '🇦🇪'} {v.name} ({v.country})
                  </option>
                ))}
              </select>
            </div>

            <div>
              <label className="block font-semibold text-stone-700 mb-1">Link to Container (Optional)</label>
              <select
                value={containerId}
                onChange={(e) => setContainerId(e.target.value)}
                className="w-full px-3 py-2.5 bg-stone-50 border border-stone-300 rounded-xl text-stone-900 focus:outline-none focus:border-stone-500 font-mono"
              >
                <option value="">-- No specific container (General Advance / Trims) --</option>
                {vendorContainers.map((c) => (
                  <option key={c.id} value={c.id}>
                    {c.containerNumber} ({c.status})
                  </option>
                ))}
              </select>
            </div>
          </div>

          {/* Invoice & Date */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div>
              <label className="block font-semibold text-stone-700 mb-1">Invoice / Proforma Ref *</label>
              <input
                type="text"
                value={invoiceNumber}
                onChange={(e) => setInvoiceNumber(e.target.value)}
                className="w-full px-3 py-2 bg-stone-50 border border-stone-300 rounded-xl text-stone-900 font-mono"
                required
              />
            </div>

            <div>
              <label className="block font-semibold text-stone-700 mb-1">Payment Date *</label>
              <input
                type="date"
                value={paymentDate}
                onChange={(e) => setPaymentDate(e.target.value)}
                className="w-full px-3 py-2 bg-stone-50 border border-stone-300 rounded-xl text-stone-900 font-mono"
                required
              />
            </div>
          </div>

          {/* Amount & Currency */}
          <div className="p-4 bg-stone-50 border border-stone-200 rounded-2xl space-y-3">
            <span className="font-mono font-bold text-stone-700 block uppercase tracking-wider text-[10px]">
              Payment Amount & Live Forex Valuation
            </span>

            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
              <div>
                <label className="block text-stone-600 mb-1">Foreign Amount *</label>
                <input
                  type="number"
                  value={amount}
                  onChange={(e) => setAmount(e.target.value)}
                  className="w-full px-3 py-2 bg-white border border-stone-300 rounded-xl text-stone-900 font-mono font-bold text-sm"
                  required
                />
              </div>

              <div>
                <label className="block text-stone-600 mb-1">Currency</label>
                <select
                  value={currency}
                  onChange={(e) => handleCurrencyChange(e.target.value as CurrencyCode)}
                  className="w-full px-3 py-2 bg-white border border-stone-300 rounded-xl text-stone-900 font-mono font-bold"
                >
                  {currencies.map((c) => (
                    <option key={c.code} value={c.code}>
                      {c.flag} {c.code} ({c.name})
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block text-stone-600 mb-1">Exchange Rate (to PKR)</label>
                <input
                  type="number"
                  step="0.01"
                  value={exchangeRate}
                  onChange={(e) => setExchangeRate(parseFloat(e.target.value) || 1)}
                  className="w-full px-3 py-2 bg-white border border-stone-300 rounded-xl text-amber-900 font-mono font-bold"
                />
              </div>
            </div>

            {/* Calculated PKR Preview */}
            <div className="p-3 bg-stone-100 border border-stone-200 rounded-xl flex items-center justify-between">
              <span className="text-stone-700 font-semibold">Equivalent PKR Value:</span>
              <span className="text-lg font-bold text-stone-900 font-mono-num">
                {formatPKR(calculatedPKR)}
              </span>
            </div>
          </div>

          {/* Payment Method & Status */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div>
              <label className="block font-semibold text-stone-700 mb-1">Payment Method</label>
              <select
                value={paymentMethod}
                onChange={(e) => setPaymentMethod(e.target.value as PaymentMethod)}
                className="w-full px-3 py-2 bg-stone-50 border border-stone-300 rounded-xl text-stone-900"
              >
                <option value="Telegraphic Transfer (TT)">Telegraphic Transfer (TT)</option>
                <option value="Letter of Credit (LC)">Letter of Credit (LC)</option>
                <option value="Hawala / Exchange House">Hawala / Exchange House</option>
                <option value="Direct Bank Wire">Direct Bank Wire</option>
                <option value="Cash Advance">Cash Advance</option>
              </select>
            </div>

            <div>
              <label className="block font-semibold text-stone-700 mb-1">Approval Status</label>
              <select
                value={status}
                onChange={(e) => setStatus(e.target.value as PaymentStatus)}
                className="w-full px-3 py-2 bg-stone-50 border border-stone-300 rounded-xl text-stone-900 font-bold"
              >
                <option value="Completed">Completed (Deducts balance)</option>
                <option value="Pending">Pending Approval (Haji Tariq sign-off)</option>
                <option value="Scheduled">Scheduled Tranche</option>
              </select>
            </div>
          </div>

          {/* Notes */}
          <div>
            <label className="block font-semibold text-stone-700 mb-1">Payment Notes / Description</label>
            <textarea
              value={notes}
              onChange={(e) => setNotes(e.target.value)}
              placeholder="e.g. 50% advance for container shipment following BL release copy..."
              className="w-full px-3 py-2 bg-stone-50 border border-stone-300 rounded-xl text-stone-900 placeholder-stone-400 h-16"
            />
          </div>

          {/* Submit buttons */}
          <div className="pt-2 flex items-center justify-end gap-2">
            <button
              type="button"
              onClick={() => setIsAddPaymentOpen(false)}
              className="px-4 py-2 bg-stone-200 hover:bg-stone-300 text-stone-800 rounded-xl font-semibold transition-colors"
            >
              Cancel
            </button>
            <button
              type="submit"
              className="px-5 py-2 bg-[#1C1917] hover:bg-stone-800 text-amber-100 rounded-xl font-bold shadow-2xs flex items-center gap-1.5 transition-colors"
            >
              <Plus className="w-4 h-4" />
              <span>Record Payment in Ledger</span>
            </button>
          </div>
        </form>
      </motion.div>
    </div>
  );
};
