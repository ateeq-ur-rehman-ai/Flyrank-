import React, { useState } from 'react';
import {
  X,
  Ship,
  Container as ContainerIcon,
  Anchor,
  Box,
  CheckCircle2,
  Clock,
  MapPin,
  Calendar,
  Layers,
  ArrowRight,
  TrendingUp,
  FileText,
  AlertCircle,
  DollarSign,
  UserCheck,
} from 'lucide-react';
import { motion } from 'motion/react';
import { useApp } from '../../context/AppContext';
import { ContainerStatus } from '../../types';
import { formatPKR, formatCurrency, formatDate, getContainerStatusBadge, getDaysUntil } from '../../utils/formatters';

export const ContainerDetailModal: React.FC = () => {
  const {
    selectedContainerId,
    setSelectedContainerId,
    isContainerDetailsOpen,
    setIsContainerDetailsOpen,
    getContainerById,
    updateContainerStatus,
    setSelectedVendorId,
    setIsVendorDetailsOpen,
  } = useApp();

  const [statusUpdateNote, setStatusUpdateNote] = useState('');

  if (!isContainerDetailsOpen || !selectedContainerId) return null;

  const container = getContainerById(selectedContainerId);
  if (!container) return null;

  const badge = getContainerStatusBadge(container.status);
  const etaInfo = getDaysUntil(container.expectedArrival);

  const handleStatusChange = (newStatus: ContainerStatus) => {
    updateContainerStatus(container.id, newStatus, statusUpdateNote || undefined);
    setStatusUpdateNote('');
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-xs">
      <motion.div
        initial={{ opacity: 0, scale: 0.96, y: 8 }}
        animate={{ opacity: 1, scale: 1, y: 0 }}
        exit={{ opacity: 0, scale: 0.96, y: 8 }}
        transition={{ duration: 0.2, ease: 'easeOut' }}
        className="bg-white border border-stone-300 rounded-2xl w-full max-w-4xl max-h-[90vh] flex flex-col shadow-2xl overflow-hidden"
      >
        {/* Modal Header */}
        <div className="p-6 border-b border-stone-200 flex items-start justify-between bg-stone-50/80">
          <div className="flex items-start gap-4">
            <div className="w-12 h-12 rounded-xl bg-amber-100 text-stone-800 border border-amber-200 font-bold flex items-center justify-center text-lg shrink-0 mt-1">
              <ContainerIcon className="w-6 h-6" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <span className="font-mono font-bold text-stone-900 text-xl">
                  {container.containerNumber}
                </span>
                <span className={`text-xs font-mono font-bold px-2.5 py-0.5 rounded-full border ${badge.bg} ${badge.border}`}>
                  {badge.text}
                </span>
              </div>
              <p className="text-xs text-stone-600 mt-1 font-mono">
                Bill of Lading: <strong className="text-stone-900">{container.blNumber}</strong> • Shipping Line: <strong className="text-stone-900">{container.shippingLine}</strong> ({container.vesselName})
              </p>
            </div>
          </div>

          <button
            onClick={() => setIsContainerDetailsOpen(false)}
            className="p-2 rounded-xl text-stone-400 hover:text-stone-800 hover:bg-stone-100 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Modal Body */}
        <div className="p-6 space-y-6 overflow-y-auto flex-1">
          {/* Key Metrics */}
          <div className="grid grid-cols-1 sm:grid-cols-4 gap-3">
            <div className="bg-stone-50 border border-stone-200 rounded-xl p-3.5">
              <span className="text-[11px] font-mono uppercase tracking-wider text-stone-500 font-semibold block">Shipment Valuation (PKR)</span>
              <span className="text-lg font-bold text-stone-900 font-mono-num mt-1 block">
                {formatPKR(container.shipmentValuePKR)}
              </span>
              <span className="text-[10px] text-stone-500 font-mono-num block">
                {formatCurrency(container.shipmentValue, container.currency)} (1 {container.currency} = Rs. {container.exchangeRateToPKR.toFixed(2)})
              </span>
            </div>

            <div className="bg-stone-50 border border-stone-200 rounded-xl p-3.5">
              <span className="text-[11px] font-mono uppercase tracking-wider text-stone-500 font-semibold block">Cargo Volume</span>
              <span className="text-lg font-bold text-stone-900 font-mono-num mt-1 block">
                {container.packagesCount} Cartons
              </span>
              <span className="text-[10px] text-stone-500 block font-mono">
                {container.containerSize} • {container.totalWeightKg.toLocaleString()} kg
              </span>
            </div>

            <div className="bg-stone-50 border border-stone-200 rounded-xl p-3.5">
              <span className="text-[11px] font-mono uppercase tracking-wider text-stone-500 font-semibold block">Port of Discharge</span>
              <span className="text-sm font-bold text-stone-900 mt-1 block">
                {container.destinationPort.split('(')[0]}
              </span>
              <span className="text-[10px] text-stone-500 block">
                From: {container.portOfLoading.split('(')[0]} ({container.originCountry})
              </span>
            </div>

            <div className="bg-stone-50 border border-stone-200 rounded-xl p-3.5">
              <span className="text-[11px] font-mono uppercase tracking-wider text-stone-500 font-semibold block">Arrival ETA</span>
              <span className="text-sm font-bold text-amber-900 mt-1 block">
                {formatDate(container.expectedArrival)}
              </span>
              <span className="text-[10px] text-stone-500 block font-mono">
                {container.actualArrival ? `Berthed: ${formatDate(container.actualArrival)}` : etaInfo.text}
              </span>
            </div>
          </div>

          {/* Supplier & Cargo Specs */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="bg-stone-50 border border-stone-200 rounded-xl p-4 space-y-2">
              <div className="flex items-center justify-between mb-2">
                <span className="text-xs font-mono font-bold text-stone-700 uppercase tracking-wider">
                  Supplier / Vendor Details
                </span>
                <button
                  onClick={() => {
                    setIsContainerDetailsOpen(false);
                    setSelectedVendorId(container.vendorId);
                    setIsVendorDetailsOpen(true);
                  }}
                  className="text-xs text-stone-800 hover:text-amber-900 font-semibold flex items-center gap-1"
                >
                  <span>Open Vendor Profile</span>
                  <ArrowRight className="w-3 h-3" />
                </button>
              </div>
              <p className="text-base font-bold text-stone-900">{container.vendorName}</p>
              <p className="text-xs text-stone-600">Origin: {container.originCountry} • Port: {container.portOfLoading}</p>
              <p className="text-xs text-stone-600 font-mono">Shipped on: <strong className="text-stone-800">{formatDate(container.shipmentDate)}</strong></p>
            </div>

            <div className="bg-stone-50 border border-stone-200 rounded-xl p-4 space-y-2">
              <span className="text-xs font-mono font-bold text-stone-700 uppercase tracking-wider block mb-2">
                Cargo Manifest Description
              </span>
              <p className="text-xs text-stone-800 font-medium leading-relaxed bg-white p-2.5 rounded-xl border border-stone-200">
                {container.cargoDescription}
              </p>
              <div className="flex items-center justify-between text-xs text-stone-600 pt-1">
                <span>Customs Duty Paid (PKR):</span>
                <span className="text-emerald-800 font-bold font-mono-num">
                  {container.customDutyPaidPKR ? formatPKR(container.customDutyPaidPKR) : 'Pending Assessment'}
                </span>
              </div>
            </div>
          </div>

          {/* Visual Step-by-Step Milestone Tracker */}
          <div className="bg-stone-50 border border-stone-200 rounded-xl p-5 space-y-4">
            <div className="flex items-center justify-between border-b border-stone-200 pb-3">
              <h4 className="text-xs font-mono font-bold text-stone-700 uppercase tracking-wider flex items-center gap-2">
                <Clock className="w-4 h-4 text-stone-600" />
                Live Shipment Milestone Journey
              </h4>
              <span className="text-xs text-stone-500 font-medium">Karachi Port Logistics Tracker</span>
            </div>

            <div className="space-y-4 relative pl-4 sm:pl-6 before:content-[''] before:absolute before:left-2 before:top-2 before:bottom-2 before:w-0.5 before:bg-stone-200">
              {container.trackingMilestones.map((m, idx) => (
                <div key={idx} className="relative group">
                  {/* Step dot */}
                  <div
                    className={`absolute -left-4 sm:-left-6 top-1 w-4 h-4 rounded-full border-2 ${
                      m.completed
                        ? 'bg-[#1C1917] border-stone-800 text-amber-100'
                        : 'bg-white border-stone-300 text-stone-400'
                    } flex items-center justify-center text-[8px] font-bold`}
                  >
                    {m.completed ? '✓' : idx + 1}
                  </div>

                  <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-1">
                    <div>
                      <p className={`text-xs font-bold ${m.completed ? 'text-stone-900' : 'text-stone-400'}`}>
                        {m.step}
                      </p>
                      <p className="text-[11px] text-stone-500 flex items-center gap-1 mt-0.5">
                        <MapPin className="w-3 h-3 text-stone-400" /> {m.location}
                      </p>
                    </div>

                    <div className="text-right">
                      <span className={`text-xs font-mono font-medium ${m.completed ? 'text-stone-800' : 'text-stone-400'}`}>
                        {m.timestamp}
                      </span>
                    </div>
                  </div>

                  {m.notes && (
                    <div className="mt-1 p-2 rounded-lg bg-amber-50 border border-amber-200 text-[11px] text-amber-900 font-medium">
                      Note: {m.notes}
                    </div>
                  )}
                </div>
              ))}
            </div>
          </div>

          {/* Status Quick Updater for Logistics Officer */}
          <div className="p-4 rounded-xl bg-stone-100 border border-stone-200 space-y-3">
            <span className="text-xs font-mono font-bold text-stone-700 uppercase tracking-wider block">
              Update Container Status (Logistics Controller)
            </span>

            <div className="flex flex-wrap gap-2">
              <button
                onClick={() => handleStatusChange('In Transit')}
                className={`px-3 py-1.5 rounded-xl text-xs font-bold border transition-colors ${
                  container.status === 'In Transit'
                    ? 'bg-[#1C1917] text-amber-100 border-stone-900'
                    : 'bg-white text-stone-700 border-stone-200 hover:bg-stone-50'
                }`}
              >
                1. In Transit
              </button>

              <button
                onClick={() => handleStatusChange('Arrived')}
                className={`px-3 py-1.5 rounded-xl text-xs font-bold border transition-colors ${
                  container.status === 'Arrived'
                    ? 'bg-amber-800 text-white border-amber-900'
                    : 'bg-white text-stone-700 border-stone-200 hover:bg-stone-50'
                }`}
              >
                2. Mark Arrived at Port
              </button>

              <button
                onClick={() => handleStatusChange('Unloading')}
                className={`px-3 py-1.5 rounded-xl text-xs font-bold border transition-colors ${
                  container.status === 'Unloading'
                    ? 'bg-stone-800 text-white border-stone-900'
                    : 'bg-white text-stone-700 border-stone-200 hover:bg-stone-50'
                }`}
              >
                3. Unloading at Warehouse
              </button>

              <button
                onClick={() => handleStatusChange('Unloaded')}
                className={`px-3 py-1.5 rounded-xl text-xs font-bold border transition-colors ${
                  container.status === 'Unloaded'
                    ? 'bg-stone-700 text-white border-stone-800'
                    : 'bg-white text-stone-700 border-stone-200 hover:bg-stone-50'
                }`}
              >
                4. Unloaded (Under QC)
              </button>

              <button
                onClick={() => handleStatusChange('Completed')}
                className={`px-3 py-1.5 rounded-xl text-xs font-bold border transition-colors ${
                  container.status === 'Completed'
                    ? 'bg-emerald-800 text-white border-emerald-900'
                    : 'bg-white text-stone-700 border-stone-200 hover:bg-stone-50'
                }`}
              >
                5. Completed & Shelved
              </button>
            </div>
          </div>
        </div>

        {/* Modal Footer */}
        <div className="p-4 border-t border-stone-200 bg-stone-50/80 flex items-center justify-between text-xs">
          <span className="text-stone-500 font-mono">DCC File Ref: {container.id}</span>
          <button
            onClick={() => setIsContainerDetailsOpen(false)}
            className="px-4 py-2 bg-stone-200 hover:bg-stone-300 text-stone-800 rounded-xl font-semibold transition-colors"
          >
            Close Container File
          </button>
        </div>
      </motion.div>
    </div>
  );
};
