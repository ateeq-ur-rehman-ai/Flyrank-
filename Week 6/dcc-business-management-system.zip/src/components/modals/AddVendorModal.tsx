import React, { useState } from 'react';
import { X, Building2, MapPin, Mail, Phone, CreditCard, Plus, Check } from 'lucide-react';
import { motion } from 'motion/react';
import confetti from 'canvas-confetti';
import { useApp } from '../../context/AppContext';
import { Country, CurrencyCode, Region } from '../../types';

export const AddVendorModal: React.FC = () => {
  const { isAddVendorOpen, setIsAddVendorOpen, addVendor, currencies } = useApp();

  const [name, setName] = useState('');
  const [code, setCode] = useState(`DCC-V-${Math.floor(10 + Math.random() * 90)}`);
  const [region, setRegion] = useState<Region>('China');
  const [country, setCountry] = useState<Country>('China');
  const [city, setCity] = useState('Guangzhou');
  const [contactPerson, setContactPerson] = useState('');
  const [email, setEmail] = useState('');
  const [phone, setPhone] = useState('');
  const [weChatOrWhatsapp, setWeChatOrWhatsapp] = useState('');
  const [address, setAddress] = useState('');
  const [category, setCategory] = useState('Silk & Brocades');

  // Bank
  const [bankName, setBankName] = useState('Bank of China');
  const [swiftCode, setSwiftCode] = useState('BKCHCNBJ');
  const [accountNumber, setAccountNumber] = useState('');
  const [accountName, setAccountName] = useState('');
  const [currency, setCurrency] = useState<CurrencyCode>('CNY');

  if (!isAddVendorOpen) return null;

  const handleCountryChange = (c: Country) => {
    setCountry(c);
    if (c === 'China') {
      setRegion('China');
      setCurrency('CNY');
      setCity('Guangzhou');
      setBankName('Bank of China');
    } else if (c === 'UAE') {
      setRegion('Gulf');
      setCurrency('AED');
      setCity('Dubai');
      setBankName('Emirates NBD');
    } else if (c === 'Saudi Arabia') {
      setRegion('Gulf');
      setCurrency('SAR');
      setCity('Riyadh');
      setBankName('Al Rajhi Bank');
    } else if (c === 'Kuwait') {
      setRegion('Gulf');
      setCurrency('KWD');
      setCity('Kuwait City');
      setBankName('National Bank of Kuwait');
    } else if (c === 'Qatar') {
      setRegion('Gulf');
      setCurrency('QAR');
      setCity('Doha');
      setBankName('Qatar National Bank');
    } else if (c === 'Bahrain') {
      setRegion('Gulf');
      setCurrency('BHD');
      setCity('Manama');
      setBankName('Bank of Bahrain and Kuwait');
    } else if (c === 'Oman') {
      setRegion('Gulf');
      setCurrency('OMR');
      setCity('Muscat');
      setBankName('Bank Muscat');
    }
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!name.trim()) return;

    addVendor({
      name: name.trim(),
      code: code.trim(),
      region,
      country,
      city: city.trim(),
      contactPerson: contactPerson.trim() || 'General Manager',
      email: email.trim() || `info@${name.toLowerCase().replace(/[^a-z0-9]/g, '')}.com`,
      phone: phone.trim() || '+86 20 8000 0000',
      weChatOrWhatsapp: weChatOrWhatsapp.trim(),
      address: address.trim() || `${city}, ${country}`,
      category: category.trim(),
      bankDetails: {
        bankName: bankName.trim(),
        swiftCode: swiftCode.trim(),
        accountNumber: accountNumber.trim() || '4029 1829 0192 48',
        accountName: accountName.trim() || name.trim(),
        currency,
        branchCity: city.trim(),
      },
    });

    confetti({
      particleCount: 50,
      spread: 60,
      origin: { y: 0.6 },
      colors: ['#D97706', '#10956a', '#1C1917'],
    });

    setIsAddVendorOpen(false);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-xs">
      <motion.div
        initial={{ opacity: 0, scale: 0.95, y: 10 }}
        animate={{ opacity: 1, scale: 1, y: 0 }}
        exit={{ opacity: 0, scale: 0.95, y: 10 }}
        transition={{ duration: 0.2, ease: 'easeOut' }}
        className="bg-white border border-stone-300 rounded-2xl w-full max-w-2xl max-h-[90vh] flex flex-col shadow-2xl overflow-hidden"
      >
        {/* Header */}
        <div className="p-5 border-b border-stone-200 flex items-center justify-between bg-stone-50/80">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-amber-100 text-stone-800 flex items-center justify-center border border-amber-200">
              <Building2 className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-base font-bold text-stone-900">Register New Supplier / Vendor</h3>
              <p className="text-xs text-stone-500">Add international textile mill or Gulf exporter to DCC network</p>
            </div>
          </div>

          <button
            onClick={() => setIsAddVendorOpen(false)}
            className="p-2 text-stone-400 hover:text-stone-800 hover:bg-stone-100 rounded-xl transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Form Body */}
        <form onSubmit={handleSubmit} className="p-6 space-y-4 overflow-y-auto flex-1 text-xs">
          {/* Country & Region selection */}
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
            <div>
              <label className="block font-semibold text-stone-700 mb-1">Country of Origin *</label>
              <select
                value={country}
                onChange={(e) => handleCountryChange(e.target.value as Country)}
                className="w-full px-3 py-2 bg-stone-50 border border-stone-300 rounded-xl text-stone-900 focus:outline-none focus:border-stone-500"
              >
                <option value="China">🇨🇳 China</option>
                <option value="UAE">🇦🇪 UAE (Dubai/Sharjah)</option>
                <option value="Saudi Arabia">🇸🇦 Saudi Arabia</option>
                <option value="Kuwait">🇰🇼 Kuwait</option>
                <option value="Qatar">🇶🇦 Qatar</option>
                <option value="Bahrain">🇧🇭 Bahrain</option>
                <option value="Oman">🇴🇲 Oman</option>
              </select>
            </div>

            <div>
              <label className="block font-semibold text-stone-700 mb-1">City / Hub *</label>
              <input
                type="text"
                value={city}
                onChange={(e) => setCity(e.target.value)}
                placeholder="e.g. Guangzhou / Ningbo"
                className="w-full px-3 py-2 bg-stone-50 border border-stone-300 rounded-xl text-stone-900 focus:outline-none focus:border-stone-500"
                required
              />
            </div>

            <div>
              <label className="block font-semibold text-stone-700 mb-1">DCC Vendor Code</label>
              <input
                type="text"
                value={code}
                onChange={(e) => setCode(e.target.value)}
                className="w-full px-3 py-2 bg-stone-50 border border-stone-300 rounded-xl text-stone-900 font-mono"
              />
            </div>
          </div>

          {/* Name & Category */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div>
              <label className="block font-semibold text-stone-700 mb-1">Company / Mill Name *</label>
              <input
                type="text"
                value={name}
                onChange={(e) => setName(e.target.value)}
                placeholder="e.g. Zhejiang Textile Industrial Ltd"
                className="w-full px-3 py-2 bg-stone-50 border border-stone-300 rounded-xl text-stone-900 focus:outline-none focus:border-stone-500"
                required
              />
            </div>

            <div>
              <label className="block font-semibold text-stone-700 mb-1">Fabric / Material Specialization</label>
              <input
                type="text"
                value={category}
                onChange={(e) => setCategory(e.target.value)}
                placeholder="e.g. Silk Rolls, Denim, Chiffon, Abaya Nida"
                className="w-full px-3 py-2 bg-stone-50 border border-stone-300 rounded-xl text-stone-900 focus:outline-none focus:border-stone-500"
              />
            </div>
          </div>

          {/* Contact Details */}
          <div className="p-3.5 bg-stone-50 border border-stone-200 rounded-xl space-y-3">
            <span className="font-mono font-bold text-stone-700 block uppercase tracking-wider text-[10px]">
              Key Contact Person & Communication
            </span>
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
              <div>
                <label className="block text-stone-600 mb-1">Contact Person</label>
                <input
                  type="text"
                  value={contactPerson}
                  onChange={(e) => setContactPerson(e.target.value)}
                  placeholder="e.g. Mr. David Zhang"
                  className="w-full px-3 py-2 bg-white border border-stone-300 rounded-lg text-stone-900"
                />
              </div>

              <div>
                <label className="block text-stone-600 mb-1">Email</label>
                <input
                  type="email"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  placeholder="david@factory.cn"
                  className="w-full px-3 py-2 bg-white border border-stone-300 rounded-lg text-stone-900 font-mono"
                />
              </div>

              <div>
                <label className="block text-stone-600 mb-1">Phone / WeChat</label>
                <input
                  type="text"
                  value={phone}
                  onChange={(e) => setPhone(e.target.value)}
                  placeholder="+86 138 0000 0000"
                  className="w-full px-3 py-2 bg-white border border-stone-300 rounded-lg text-stone-900 font-mono"
                />
              </div>
            </div>
          </div>

          {/* Banking Details */}
          <div className="p-3.5 bg-stone-50 border border-stone-200 rounded-xl space-y-3">
            <span className="font-mono font-bold text-stone-700 block uppercase tracking-wider text-[10px]">
              Banking Information (For TT / LC Transfers)
            </span>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <div>
                <label className="block text-stone-600 mb-1">Beneficiary Bank</label>
                <input
                  type="text"
                  value={bankName}
                  onChange={(e) => setBankName(e.target.value)}
                  className="w-full px-3 py-2 bg-white border border-stone-300 rounded-lg text-stone-900"
                />
              </div>

              <div>
                <label className="block text-stone-600 mb-1">SWIFT Code</label>
                <input
                  type="text"
                  value={swiftCode}
                  onChange={(e) => setSwiftCode(e.target.value)}
                  className="w-full px-3 py-2 bg-white border border-stone-300 rounded-lg text-amber-900 font-mono font-bold"
                />
              </div>

              <div>
                <label className="block text-stone-600 mb-1">Account Number / IBAN</label>
                <input
                  type="text"
                  value={accountNumber}
                  onChange={(e) => setAccountNumber(e.target.value)}
                  placeholder="e.g. 4532 9812 0041 8291"
                  className="w-full px-3 py-2 bg-white border border-stone-300 rounded-lg text-stone-900 font-mono"
                />
              </div>

              <div>
                <label className="block text-stone-600 mb-1">Settlement Currency</label>
                <select
                  value={currency}
                  onChange={(e) => setCurrency(e.target.value as CurrencyCode)}
                  className="w-full px-3 py-2 bg-white border border-stone-300 rounded-lg text-stone-900 font-mono font-bold"
                >
                  {currencies.map((c) => (
                    <option key={c.code} value={c.code}>
                      {c.flag} {c.code} — {c.name}
                    </option>
                  ))}
                </select>
              </div>
            </div>
          </div>

          {/* Submit */}
          <div className="pt-2 flex items-center justify-end gap-2">
            <button
              type="button"
              onClick={() => setIsAddVendorOpen(false)}
              className="px-4 py-2 bg-stone-200 hover:bg-stone-300 text-stone-800 rounded-xl font-semibold transition-colors"
            >
              Cancel
            </button>
            <button
              type="submit"
              className="px-5 py-2 bg-[#1C1917] hover:bg-stone-800 text-amber-100 rounded-xl font-bold shadow-2xs flex items-center gap-1.5 transition-colors"
            >
              <Plus className="w-4 h-4" />
              <span>Save Vendor to DCC</span>
            </button>
          </div>
        </form>
      </motion.div>
    </div>
  );
};
