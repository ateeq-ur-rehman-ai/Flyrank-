import React, { useState, useEffect } from 'react';
import { X, Ship, Container as ContainerIcon, Plus, Anchor } from 'lucide-react';
import { motion } from 'motion/react';
import confetti from 'canvas-confetti';
import { useApp } from '../../context/AppContext';
import { ContainerStatus, Country, CurrencyCode } from '../../types';

export const AddContainerModal: React.FC = () => {
  const {
    isAddContainerOpen,
    setIsAddContainerOpen,
    vendors,
    currencies,
    addContainer,
  } = useApp();

  const [containerNumber, setContainerNumber] = useState(`MSKU-${Math.floor(1000000 + Math.random() * 9000000)}`);
  const [blNumber, setBlNumber] = useState(`MSK-PK-${Math.floor(10000 + Math.random() * 90000)}`);
  const [shippingLine, setShippingLine] = useState('Maersk Line');
  const [vesselName, setVesselName] = useState('Maersk Mc-Kinney Moller V.2409');
  const [vendorId, setVendorId] = useState('');
  const [portOfLoading, setPortOfLoading] = useState('Guangzhou (Nansha Port), China');
  const [destinationPort, setDestinationPort] = useState('Karachi Port Trust (KPT), Pakistan');
  const [shipmentDate, setShipmentDate] = useState('2026-08-24');
  const [expectedArrival, setExpectedArrival] = useState('2026-09-10');
  const [shipmentValue, setShipmentValue] = useState('320000');
  const [currency, setCurrency] = useState<CurrencyCode>('CNY');
  const [status, setStatus] = useState<ContainerStatus>('In Transit');
  const [cargoDescription, setCargoDescription] = useState('750 Cartons — Premium Silk & Satin Fabrics');
  const [containerSize, setContainerSize] = useState<'20ft Standard' | '40ft High Cube' | '40ft Standard' | 'LCL Cargo'>('40ft High Cube');
  const [packagesCount, setPackagesCount] = useState('750');
  const [totalWeightKg, setTotalWeightKg] = useState('21000');
  const [customDutyPaidPKR, setCustomDutyPaidPKR] = useState('1950000');

  useEffect(() => {
    if (vendors.length > 0 && !vendorId) {
      setVendorId(vendors[0].id);
      setCurrency(vendors[0].bankDetails.currency);
      setPortOfLoading(`${vendors[0].city} Port, ${vendors[0].country}`);
    }
  }, [vendors, vendorId]);

  if (!isAddContainerOpen) return null;

  const handleVendorChange = (id: string) => {
    setVendorId(id);
    const v = vendors.find((vend) => vend.id === id);
    if (v) {
      setCurrency(v.bankDetails.currency);
      setPortOfLoading(`${v.city} Port, ${v.country}`);
    }
  };

  const selectedVendor = vendors.find((v) => v.id === vendorId);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedVendor || !containerNumber.trim()) return;

    const currObj = currencies.find((c) => c.code === currency);
    const rate = currObj ? currObj.rateToPKR : 1;

    addContainer({
      containerNumber: containerNumber.trim().toUpperCase(),
      blNumber: blNumber.trim().toUpperCase(),
      shippingLine,
      vesselName,
      vendorId: selectedVendor.id,
      vendorName: selectedVendor.name,
      originCountry: selectedVendor.country,
      portOfLoading,
      destinationPort,
      shipmentDate,
      expectedArrival,
      shipmentValue: parseFloat(shipmentValue) || 0,
      currency,
      exchangeRateToPKR: rate,
      status,
      cargoDescription: cargoDescription.trim(),
      containerSize,
      packagesCount: parseInt(packagesCount) || 1,
      totalWeightKg: parseFloat(totalWeightKg) || 10000,
      customDutyPaidPKR: parseFloat(customDutyPaidPKR) || undefined,
    });

    confetti({
      particleCount: 50,
      spread: 60,
      origin: { y: 0.6 },
      colors: ['#D97706', '#10956a', '#1C1917'],
    });

    setIsAddContainerOpen(false);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-xs">
      <motion.div
        initial={{ opacity: 0, scale: 0.95, y: 10 }}
        animate={{ opacity: 1, scale: 1, y: 0 }}
        exit={{ opacity: 0, scale: 0.95, y: 10 }}
        transition={{ duration: 0.2, ease: 'easeOut' }}
        className="bg-white border border-stone-300 rounded-2xl w-full max-w-2xl max-h-[90vh] flex flex-col shadow-2xl overflow-hidden"
      >
        {/* Header */}
        <div className="p-5 border-b border-stone-200 flex items-center justify-between bg-stone-50/80">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-amber-100 text-stone-800 flex items-center justify-center border border-amber-200">
              <ContainerIcon className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-base font-bold text-stone-900">Book New Container Shipment</h3>
              <p className="text-xs text-stone-500">Log import manifest, Bill of Lading, and route to Karachi port</p>
            </div>
          </div>

          <button
            onClick={() => setIsAddContainerOpen(false)}
            className="p-2 text-stone-400 hover:text-stone-800 hover:bg-stone-100 rounded-xl transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Form Body */}
        <form onSubmit={handleSubmit} className="p-6 space-y-4 overflow-y-auto flex-1 text-xs">
          {/* Container & BL Numbers */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div>
              <label className="block font-semibold text-stone-700 mb-1">Container Number (ISO) *</label>
              <input
                type="text"
                value={containerNumber}
                onChange={(e) => setContainerNumber(e.target.value)}
                placeholder="e.g. MSKU-9281920"
                className="w-full px-3 py-2 bg-stone-50 border border-stone-300 rounded-xl text-stone-900 font-mono font-bold uppercase"
                required
              />
            </div>

            <div>
              <label className="block font-semibold text-stone-700 mb-1">Bill of Lading (BL #) *</label>
              <input
                type="text"
                value={blNumber}
                onChange={(e) => setBlNumber(e.target.value)}
                placeholder="e.g. MSK-CN-KPT-88910"
                className="w-full px-3 py-2 bg-stone-50 border border-stone-300 rounded-xl text-stone-900 font-mono uppercase"
                required
              />
            </div>
          </div>

          {/* Shipping Line & Vessel */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div>
              <label className="block font-semibold text-stone-700 mb-1">Shipping Line</label>
              <select
                value={shippingLine}
                onChange={(e) => setShippingLine(e.target.value)}
                className="w-full px-3 py-2 bg-stone-50 border border-stone-300 rounded-xl text-stone-900 font-medium"
              >
                <option value="Maersk Line">Maersk Line</option>
                <option value="COSCO Shipping">COSCO Shipping</option>
                <option value="CMA CGM">CMA CGM</option>
                <option value="Hapag-Lloyd">Hapag-Lloyd</option>
                <option value="OOCL">OOCL</option>
                <option value="Evergreen Line">Evergreen Line</option>
                <option value="MSC">MSC (Mediterranean Shipping Co)</option>
              </select>
            </div>

            <div>
              <label className="block font-semibold text-stone-700 mb-1">Vessel & Voyage</label>
              <input
                type="text"
                value={vesselName}
                onChange={(e) => setVesselName(e.target.value)}
                placeholder="e.g. MSC Isabella V.204"
                className="w-full px-3 py-2 bg-stone-50 border border-stone-300 rounded-xl text-stone-900"
              />
            </div>
          </div>

          {/* Vendor */}
          <div>
            <label className="block font-semibold text-stone-700 mb-1">Shipper / Vendor *</label>
            <select
              value={vendorId}
              onChange={(e) => handleVendorChange(e.target.value)}
              className="w-full px-3 py-2.5 bg-stone-50 border border-stone-300 rounded-xl text-stone-900 font-semibold"
              required
            >
              {vendors.map((v) => (
                <option key={v.id} value={v.id}>
                  {v.region === 'China' ? '🇨🇳' : '🇦🇪'} {v.name} ({v.country})
                </option>
              ))}
            </select>
          </div>

          {/* Port of Loading & Destination */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div>
              <label className="block font-semibold text-stone-700 mb-1">Port of Loading</label>
              <input
                type="text"
                value={portOfLoading}
                onChange={(e) => setPortOfLoading(e.target.value)}
                className="w-full px-3 py-2 bg-stone-50 border border-stone-300 rounded-xl text-stone-900"
              />
            </div>

            <div>
              <label className="block font-semibold text-stone-700 mb-1">Destination Port (Pakistan)</label>
              <select
                value={destinationPort}
                onChange={(e) => setDestinationPort(e.target.value)}
                className="w-full px-3 py-2 bg-stone-50 border border-stone-300 rounded-xl text-stone-900"
              >
                <option value="Karachi Port Trust (KPT), Pakistan">Karachi Port Trust (KPT)</option>
                <option value="Port Muhammad Bin Qasim (QICT), Pakistan">Port Muhammad Bin Qasim (QICT)</option>
              </select>
            </div>
          </div>

          {/* Shipment & Arrival Dates */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div>
              <label className="block font-semibold text-stone-700 mb-1">Shipment / Sail Date</label>
              <input
                type="date"
                value={shipmentDate}
                onChange={(e) => setShipmentDate(e.target.value)}
                className="w-full px-3 py-2 bg-stone-50 border border-stone-300 rounded-xl text-stone-900 font-mono"
                required
              />
            </div>

            <div>
              <label className="block font-semibold text-stone-700 mb-1">Expected Arrival Date (ETA)</label>
              <input
                type="date"
                value={expectedArrival}
                onChange={(e) => setExpectedArrival(e.target.value)}
                className="w-full px-3 py-2 bg-stone-50 border border-stone-300 rounded-xl text-stone-900 font-mono"
                required
              />
            </div>
          </div>

          {/* Value & Currency */}
          <div className="p-3.5 bg-stone-50 border border-stone-200 rounded-xl space-y-3">
            <span className="font-mono font-bold text-stone-700 block uppercase tracking-wider text-[10px]">
              Shipment Cargo Value & Specs
            </span>

            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
              <div>
                <label className="block text-stone-600 mb-1">Cargo Value (Foreign)</label>
                <input
                  type="number"
                  value={shipmentValue}
                  onChange={(e) => setShipmentValue(e.target.value)}
                  className="w-full px-3 py-2 bg-white border border-stone-300 rounded-lg text-stone-900 font-mono font-bold"
                  required
                />
              </div>

              <div>
                <label className="block text-stone-600 mb-1">Currency</label>
                <select
                  value={currency}
                  onChange={(e) => setCurrency(e.target.value as CurrencyCode)}
                  className="w-full px-3 py-2 bg-white border border-stone-300 rounded-lg text-stone-900 font-mono font-bold"
                >
                  {currencies.map((c) => (
                    <option key={c.code} value={c.code}>
                      {c.flag} {c.code}
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block text-stone-600 mb-1">Status</label>
                <select
                  value={status}
                  onChange={(e) => setStatus(e.target.value as ContainerStatus)}
                  className="w-full px-3 py-2 bg-white border border-stone-300 rounded-lg text-stone-900 font-bold"
                >
                  <option value="In Transit">In Transit</option>
                  <option value="Arrived">Arrived at Port</option>
                  <option value="Unloading">Unloading</option>
                  <option value="Unloaded">Unloaded</option>
                  <option value="Completed">Completed</option>
                </select>
              </div>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 pt-1">
              <div>
                <label className="block text-stone-600 mb-1">Container Size</label>
                <select
                  value={containerSize}
                  onChange={(e) => setContainerSize(e.target.value as any)}
                  className="w-full px-3 py-2 bg-white border border-stone-300 rounded-lg text-stone-900"
                >
                  <option value="40ft High Cube">40ft High Cube</option>
                  <option value="40ft Standard">40ft Standard</option>
                  <option value="20ft Standard">20ft Standard</option>
                  <option value="LCL Cargo">LCL Cargo</option>
                </select>
              </div>

              <div>
                <label className="block text-stone-600 mb-1">Packages (Cartons)</label>
                <input
                  type="number"
                  value={packagesCount}
                  onChange={(e) => setPackagesCount(e.target.value)}
                  className="w-full px-3 py-2 bg-white border border-stone-300 rounded-lg text-stone-900 font-mono"
                />
              </div>

              <div>
                <label className="block text-stone-600 mb-1">Weight (KG)</label>
                <input
                  type="number"
                  value={totalWeightKg}
                  onChange={(e) => setTotalWeightKg(e.target.value)}
                  className="w-full px-3 py-2 bg-white border border-stone-300 rounded-lg text-stone-900 font-mono"
                />
              </div>
            </div>

            <div>
              <label className="block text-stone-600 mb-1">Cargo Item Description</label>
              <input
                type="text"
                value={cargoDescription}
                onChange={(e) => setCargoDescription(e.target.value)}
                placeholder="e.g. 750 Cartons — High-grade Chiffon & Satin Rolls"
                className="w-full px-3 py-2 bg-white border border-stone-300 rounded-lg text-stone-900"
              />
            </div>
          </div>

          {/* Submit buttons */}
          <div className="pt-2 flex items-center justify-end gap-2">
            <button
              type="button"
              onClick={() => setIsAddContainerOpen(false)}
              className="px-4 py-2 bg-stone-200 hover:bg-stone-300 text-stone-800 rounded-xl font-semibold transition-colors"
            >
              Cancel
            </button>
            <button
              type="submit"
              className="px-5 py-2 bg-[#1C1917] hover:bg-stone-800 text-amber-100 rounded-xl font-bold shadow-2xs flex items-center gap-1.5 transition-colors"
            >
              <Plus className="w-4 h-4" />
              <span>Register Container</span>
            </button>
          </div>
        </form>
      </motion.div>
    </div>
  );
};
