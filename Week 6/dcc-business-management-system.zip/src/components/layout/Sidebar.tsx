import React from 'react';
import {
  LayoutDashboard,
  Users,
  Container as ContainerIcon,
  ArrowRightLeft,
  FileBarChart,
  LogOut,
  TrendingUp,
  X,
} from 'lucide-react';
import { useApp } from '../../context/AppContext';
import { ActiveModule } from '../../types';

export const Sidebar: React.FC = () => {
  const {
    activeModule,
    setActiveModule,
    currentUser,
    logout,
    containers,
    payments,
    currencies,
    isMobileSidebarOpen,
    setIsMobileSidebarOpen,
  } = useApp();

  const inTransitCount = containers.filter((c) => c.status === 'In Transit').length;
  const pendingPaymentsCount = payments.filter((p) => p.status === 'Pending').length;

  const navItems: {
    id: ActiveModule;
    label: string;
    icon: React.ComponentType<{ className?: string }>;
    badge?: number;
    badgeColor?: string;
    subtext: string;
  }[] = [
    {
      id: 'dashboard',
      label: 'Dashboard',
      icon: LayoutDashboard,
      subtext: 'Overview & KPIs',
    },
    {
      id: 'vendors',
      label: 'Vendors & Payments',
      icon: Users,
      badge: pendingPaymentsCount > 0 ? pendingPaymentsCount : undefined,
      badgeColor: 'bg-amber-600 text-white',
      subtext: 'Suppliers & Ledger',
    },
    {
      id: 'containers',
      label: 'Containers & Shipments',
      icon: ContainerIcon,
      badge: inTransitCount > 0 ? inTransitCount : undefined,
      badgeColor: 'bg-stone-700 text-stone-100',
      subtext: 'Tracking & Port Status',
    },
    {
      id: 'converter',
      label: 'Currency Converter',
      icon: ArrowRightLeft,
      subtext: 'Live Rates & Calculator',
    },
    {
      id: 'reports',
      label: 'Reports & Analytics',
      icon: FileBarChart,
      subtext: 'Statements & Exports',
    },
  ];

  const keyRates = currencies.filter((c) => ['CNY', 'AED', 'SAR', 'USD'].includes(c.code));

  const handleNavClick = (id: ActiveModule) => {
    setActiveModule(id);
    setIsMobileSidebarOpen(false);
  };

  return (
    <>
      {/* Mobile Drawer Overlay */}
      {isMobileSidebarOpen && (
        <div
          onClick={() => setIsMobileSidebarOpen(false)}
          className="fixed inset-0 bg-stone-950/60 backdrop-blur-xs z-40 lg:hidden transition-opacity duration-200"
          aria-hidden="true"
        />
      )}

      <aside
        className={`fixed lg:static inset-y-0 left-0 z-50 w-72 bg-[#171513] text-stone-300 border-r border-[#2C2825] flex flex-col h-screen select-none shrink-0 transition-transform duration-300 ease-in-out shadow-2xl lg:shadow-none ${
          isMobileSidebarOpen ? 'translate-x-0' : '-translate-x-full lg:translate-x-0'
        }`}
      >
        {/* Brand Header */}
        <div className="p-4 sm:p-5 border-b border-[#2C2825] flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-11 h-11 rounded-2xl bg-gradient-to-br from-amber-700 to-amber-900 flex items-center justify-center text-amber-100 font-bold shadow-md border border-amber-600/30">
              <span className="tracking-wide text-sm font-bold">DCC</span>
            </div>
            <div>
              <h1 className="font-bold text-stone-100 text-[15px] leading-snug">
                Dubai Clothing Center
              </h1>
              <p className="text-xs text-amber-400 font-medium flex items-center gap-1.5 mt-0.5">
                <span className="inline-block w-2 h-2 rounded-full bg-emerald-400"></span>
                EST. 1994 • Import Registry
              </p>
            </div>
          </div>

          {/* Close button on mobile */}
          <button
            onClick={() => setIsMobileSidebarOpen(false)}
            className="lg:hidden p-1.5 rounded-lg text-stone-400 hover:text-white hover:bg-stone-800 transition-colors"
            title="Close menu"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Navigation Modules */}
        <div className="flex-1 py-4 px-3 space-y-1.5 overflow-y-auto">
          <div className="px-3 pb-2 text-xs font-semibold tracking-wider text-stone-400 uppercase">
            Menu
          </div>

          {navItems.map((item) => {
            const Icon = item.icon;
            const isActive = activeModule === item.id;
            return (
              <button
                key={item.id}
                id={`nav-item-${item.id}`}
                onClick={() => handleNavClick(item.id)}
                className={`w-full flex items-center gap-3 px-3.5 py-3 rounded-2xl text-left transition-all duration-150 group relative ${
                  isActive
                    ? 'bg-[#292420] text-amber-100 font-semibold border border-amber-800/40 shadow-sm'
                    : 'text-stone-300 hover:bg-[#201C19] hover:text-white'
                }`}
              >
                <div
                  className={`p-2.5 rounded-xl transition-colors ${
                    isActive
                      ? 'bg-amber-600/25 text-amber-300 border border-amber-500/30'
                      : 'bg-[#201D1A] text-stone-400 group-hover:text-amber-300'
                  }`}
                >
                  <Icon className="w-4 h-4" />
                </div>

                <div className="flex-1 min-w-0">
                  <div className="flex items-center justify-between">
                    <span className={`text-[13px] ${isActive ? 'font-bold text-white' : 'font-semibold text-stone-200'}`}>
                      {item.label}
                    </span>
                    {item.badge !== undefined && (
                      <span
                        className={`text-[10px] font-bold px-1.5 py-0.5 rounded-full ${
                          item.badgeColor || 'bg-stone-700 text-stone-200'
                        }`}
                      >
                        {item.badge}
                      </span>
                    )}
                  </div>
                  <span
                    className={`text-xs block mt-0.5 truncate ${
                      isActive ? 'text-amber-300/90 font-medium' : 'text-stone-400'
                    }`}
                  >
                    {item.subtext}
                  </span>
                </div>

                {isActive && (
                  <div className="absolute right-2.5 w-1.5 h-6 bg-amber-500 rounded-full shadow-xs"></div>
                )}
              </button>
            );
          })}

          {/* Live Forex Quick Glance */}
          <div className="mt-6 pt-4 border-t border-[#2C2825] px-2">
            <div className="flex items-center justify-between text-xs text-stone-400 font-medium px-1 mb-2.5">
              <span className="flex items-center gap-1.5 text-amber-300/90 font-semibold text-[11px] tracking-wide">
                <TrendingUp className="w-3.5 h-3.5 text-amber-400" /> Spot Forex
              </span>
              <span className="text-[11px] text-stone-400">in PKR</span>
            </div>
            <div className="grid grid-cols-2 gap-2">
              {keyRates.map((curr) => (
                <div
                  key={curr.code}
                  className="bg-[#201C19] border border-[#2C2825] rounded-xl p-2 flex flex-col hover:border-amber-800/40 transition-colors"
                >
                  <div className="flex items-center justify-between text-xs">
                    <span className="font-semibold text-stone-300 flex items-center gap-1 text-[11px]">
                      <span>{curr.flag}</span> {curr.code}
                    </span>
                  </div>
                  <span className="text-xs font-bold text-amber-200 font-mono-num mt-1">
                    Rs. {curr.rateToPKR.toFixed(2)}
                  </span>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Footer User Profile & Actions */}
        <div className="p-3 border-t border-[#2C2825] bg-[#141210]">
          <div className="flex items-center justify-between gap-2 p-2 rounded-xl bg-[#201C19] border border-[#2C2825]">
            <div className="flex items-center gap-2.5 min-w-0">
              <div className="w-8 h-8 rounded-lg bg-[#3D3228] text-amber-200 font-bold text-xs flex items-center justify-center shrink-0 border border-amber-600/30">
                {currentUser.avatarText}
              </div>
              <div className="min-w-0">
                <p className="text-xs font-semibold text-stone-200 truncate">
                  {currentUser.name}
                </p>
                <p className="text-[10px] text-stone-400 truncate">
                  {currentUser.role}
                </p>
              </div>
            </div>
            <button
              id="btn-logout"
              onClick={logout}
              title="Log Out"
              className="p-1.5 rounded-lg text-stone-400 hover:text-amber-300 hover:bg-[#2A2420] transition-colors"
            >
              <LogOut className="w-4 h-4" />
            </button>
          </div>
        </div>
      </aside>
    </>
  );
};
