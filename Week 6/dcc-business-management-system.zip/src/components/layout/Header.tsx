import React, { useState } from 'react';
import {
  Search,
  Plus,
  Bell,
  RefreshCw,
  ChevronDown,
  Container as ContainerIcon,
  Users,
  Menu,
} from 'lucide-react';
import { useApp } from '../../context/AppContext';
import { ActiveModule } from '../../types';

export const Header: React.FC = () => {
  const {
    activeModule,
    setActiveModule,
    globalSearch,
    setGlobalSearch,
    setIsAddVendorOpen,
    setIsAddPaymentOpen,
    setIsAddContainerOpen,
    currentUser,
    switchUser,
    availableUsers,
    activities,
    resetAllData,
    setIsMobileSidebarOpen,
    currencies,
  } = useApp();

  const [showUserMenu, setShowUserMenu] = useState(false);
  const [showNotifications, setShowNotifications] = useState(false);

  const cnyRate = currencies.find((c) => c.code === 'CNY')?.rateToPKR || 38.65;
  const usdRate = currencies.find((c) => c.code === 'USD')?.rateToPKR || 279.40;
  const aedRate = currencies.find((c) => c.code === 'AED')?.rateToPKR || 76.10;

  const getModuleHeader = (module: ActiveModule) => {
    switch (module) {
      case 'dashboard':
        return {
          title: 'Dashboard',
          subtitle: 'Overview of imports, payments, and shipments',
        };
      case 'vendors':
        return {
          title: 'Vendors & Payments',
          subtitle: 'Supplier directory, bank details, and payment records',
        };
      case 'containers':
        return {
          title: 'Containers & Shipments',
          subtitle: 'Live vessel tracking, port arrival, and unloading status',
        };
      case 'converter':
        return {
          title: 'Currency Converter',
          subtitle: 'Live exchange rates and PKR conversion calculator',
        };
      case 'reports':
        return {
          title: 'Reports & Statements',
          subtitle: 'Monthly summaries, supplier balances, and export data',
        };
    }
  };

  const headerInfo = getModuleHeader(activeModule);

  return (
    <header className="bg-white/95 backdrop-blur-md border-b border-stone-200 text-stone-900 px-3 sm:px-6 py-3 flex items-center justify-between gap-2 sm:gap-4 sticky top-0 z-30 shadow-[0_1px_3px_rgba(0,0,0,0.02)]">
      {/* Left: Mobile Hamburger & Title */}
      <div className="flex items-center gap-2 sm:gap-3 min-w-0">
        {/* Mobile Hamburger Toggle */}
        <button
          id="btn-open-mobile-sidebar"
          onClick={() => setIsMobileSidebarOpen(true)}
          className="lg:hidden p-2 text-stone-700 hover:text-stone-900 hover:bg-stone-100 rounded-xl border border-stone-200 transition-colors shrink-0"
          title="Open Navigation Menu"
        >
          <Menu className="w-5 h-5" />
        </button>

        <div className="min-w-0">
          <h2 className="text-base sm:text-lg md:text-xl font-bold text-stone-900 tracking-tight flex items-center gap-2 truncate">
            {headerInfo.title}
          </h2>
          <p className="text-[11px] sm:text-xs text-stone-500 truncate max-w-xs sm:max-w-md hidden md:block">
            {headerInfo.subtitle}
          </p>
        </div>
      </div>

      {/* Center Search */}
      <div className="flex-1 max-w-xs sm:max-w-md mx-1 sm:mx-2">
        <div className="relative">
          <Search className="w-3.5 sm:w-4 h-3.5 sm:h-4 text-stone-400 absolute left-3 top-1/2 -translate-y-1/2 pointer-events-none" />
          <input
            id="global-search-input"
            type="text"
            value={globalSearch}
            onChange={(e) => setGlobalSearch(e.target.value)}
            placeholder="Search vendors, containers, BL #, payments..."
            className="w-full pl-8 sm:pl-9 pr-3 sm:pr-4 py-1.5 sm:py-2 text-xs bg-stone-50 border border-stone-300 rounded-xl text-stone-900 placeholder-stone-400 focus:outline-none focus:border-stone-800 focus:ring-1 focus:ring-stone-800 transition-all shadow-inner"
          />
          {globalSearch && (
            <button
              onClick={() => setGlobalSearch('')}
              className="absolute right-2.5 top-1/2 -translate-y-1/2 text-xs text-stone-400 hover:text-stone-700 px-1"
            >
              ✕
            </button>
          )}
        </div>
      </div>

      {/* Action Buttons & Profile Controls */}
      <div className="flex items-center gap-1.5 sm:gap-2.5 shrink-0">
        {/* Live Forex Rates Ticker Button */}
        <button
          id="btn-header-forex-ticker"
          onClick={() => setActiveModule('converter')}
          className="hidden 2xl:flex items-center gap-2 px-3 py-1.5 text-xs font-semibold text-stone-700 bg-stone-50 hover:bg-stone-100 border border-stone-200 rounded-xl transition-colors shadow-2xs"
          title="Open Live Currency Converter"
        >
          <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse"></span>
          <span className="text-stone-500 font-mono text-[11px]">LIVE:</span>
          <span className="font-mono text-stone-900">¥ {cnyRate.toFixed(2)}</span>
          <span className="text-stone-300">|</span>
          <span className="font-mono text-stone-900">$ {usdRate.toFixed(2)}</span>
        </button>

        {/* Quick Action: Add Vendor */}
        <button
          id="btn-quick-add-vendor"
          onClick={() => setIsAddVendorOpen(true)}
          className="hidden xl:flex items-center gap-1.5 px-3 py-2 text-xs font-semibold text-stone-700 bg-white hover:bg-stone-50 border border-stone-300 rounded-xl transition-colors shadow-sm"
          title="Add New Vendor"
        >
          <Users className="w-3.5 h-3.5 text-stone-600" />
          <span>Add Vendor</span>
        </button>

        {/* Quick Action: Add Container */}
        <button
          id="btn-quick-add-container"
          onClick={() => setIsAddContainerOpen(true)}
          className="hidden md:flex items-center gap-1.5 px-3 py-2 text-xs font-semibold text-stone-700 bg-white hover:bg-stone-50 border border-stone-300 rounded-xl transition-colors shadow-sm"
          title="Add Container Shipment"
        >
          <ContainerIcon className="w-3.5 h-3.5 text-amber-700" />
          <span>Add Container</span>
        </button>

        {/* Quick Action: Add Payment */}
        <button
          id="btn-quick-add-payment"
          onClick={() => setIsAddPaymentOpen(true)}
          className="flex items-center gap-1 sm:gap-1.5 px-2.5 sm:px-3.5 py-1.5 sm:py-2 text-xs font-bold text-amber-50 bg-[#1C1917] hover:bg-[#292524] rounded-xl transition-all shadow-sm border border-stone-900"
          title="Record Payment"
        >
          <Plus className="w-3.5 h-3.5" />
          <span className="hidden sm:inline">Add Payment</span>
          <span className="sm:hidden">Payment</span>
        </button>

        {/* Activity & Notifications */}
        <div className="relative">
          <button
            id="btn-toggle-notifications"
            onClick={() => setShowNotifications(!showNotifications)}
            className="p-1.5 sm:p-2 text-stone-600 hover:text-stone-900 hover:bg-stone-100 rounded-xl border border-stone-200 transition-colors relative"
            title="Recent Activity"
          >
            <Bell className="w-4 h-4" />
            <span className="absolute top-1.5 right-1.5 w-2 h-2 rounded-full bg-amber-600 ring-2 ring-white"></span>
          </button>

          {showNotifications && (
            <div className="absolute right-0 mt-2 w-72 sm:w-80 bg-white border border-stone-200 rounded-2xl shadow-xl p-3 z-50 animate-in fade-in zoom-in-95">
              <div className="flex items-center justify-between pb-2 border-b border-stone-100 mb-2">
                <span className="text-xs font-bold text-stone-900">Activity Log</span>
                <span className="text-[10px] font-mono text-stone-400">{activities.length} items</span>
              </div>
              <div className="space-y-2 max-h-72 overflow-y-auto pr-1">
                {activities.slice(0, 5).map((act) => (
                  <div key={act.id} className="p-2 rounded-lg bg-stone-50 border border-stone-200/80 text-xs">
                    <div className="flex items-center justify-between text-[10px] text-stone-400 mb-1 font-mono">
                      <span className="font-semibold text-amber-800">{act.tag || act.type}</span>
                      <span>{act.timestamp}</span>
                    </div>
                    <p className="font-semibold text-stone-800 text-xs">{act.title}</p>
                    <p className="text-[11px] text-stone-500 mt-0.5">{act.description}</p>
                  </div>
                ))}
              </div>
              <div className="mt-2 pt-2 border-t border-stone-100 text-center">
                <button
                  onClick={() => {
                    setShowNotifications(false);
                    setActiveModule('dashboard');
                  }}
                  className="text-xs text-amber-800 hover:text-amber-900 font-medium"
                >
                  View full history on Dashboard →
                </button>
              </div>
            </div>
          )}
        </div>

        {/* User Role Switcher Dropdown */}
        <div className="relative">
          <button
            id="btn-user-profile-menu"
            onClick={() => setShowUserMenu(!showUserMenu)}
            className="flex items-center gap-1.5 sm:gap-2 pl-1.5 sm:pl-2 pr-2 sm:pr-2.5 py-1 sm:py-1.5 bg-stone-100 hover:bg-stone-200/80 border border-stone-300 rounded-xl transition-colors"
          >
            <div className="w-6 h-6 rounded-md bg-[#292524] text-amber-100 font-bold text-[10px] flex items-center justify-center">
              {currentUser.avatarText}
            </div>
            <span className="text-xs font-medium text-stone-800 hidden md:inline max-w-[90px] truncate">
              {currentUser.name.split(' ')[0]}
            </span>
            <ChevronDown className="w-3 h-3 text-stone-500" />
          </button>

          {showUserMenu && (
            <div className="absolute right-0 mt-2 w-64 bg-white border border-stone-200 rounded-2xl shadow-xl p-2 z-50">
              <div className="p-2 border-b border-stone-100 mb-1">
                <p className="text-xs font-bold text-stone-900">{currentUser.name}</p>
                <p className="text-[10px] font-mono text-stone-500">{currentUser.email}</p>
                <span className="inline-block mt-1 text-[10px] font-mono px-2 py-0.5 rounded-full bg-amber-50 text-amber-900 border border-amber-200">
                  {currentUser.role}
                </span>
              </div>

              <div className="py-1">
                <div className="px-2 py-1 text-[10px] font-mono font-semibold text-stone-400 uppercase tracking-wider">
                  Switch Active Persona
                </div>
                {availableUsers.map((u) => (
                  <button
                    key={u.email}
                    onClick={() => {
                      switchUser(u);
                      setShowUserMenu(false);
                    }}
                    className={`w-full text-left px-2.5 py-1.5 rounded-lg text-xs flex items-center justify-between ${
                      currentUser.email === u.email
                        ? 'bg-[#1C1917] text-white font-semibold'
                        : 'text-stone-700 hover:bg-stone-100'
                    }`}
                  >
                    <div>
                      <p className="font-medium leading-none">{u.name}</p>
                      <p className={`text-[10px] mt-0.5 font-mono ${currentUser.email === u.email ? 'text-amber-200' : 'text-stone-400'}`}>
                        {u.role}
                      </p>
                    </div>
                    {currentUser.email === u.email && (
                      <span className="text-xs">✓</span>
                    )}
                  </button>
                ))}
              </div>

              <div className="pt-2 border-t border-stone-100">
                <button
                  onClick={() => {
                    if (window.confirm('Reset all demo data to initial factory state?')) {
                      resetAllData();
                      setShowUserMenu(false);
                    }
                  }}
                  className="w-full flex items-center gap-2 px-2.5 py-1.5 text-xs text-stone-600 hover:text-rose-700 hover:bg-rose-50 rounded-lg transition-colors"
                >
                  <RefreshCw className="w-3.5 h-3.5" />
                  <span>Reset Demo Data</span>
                </button>
              </div>
            </div>
          )}
        </div>
      </div>
    </header>
  );
};
