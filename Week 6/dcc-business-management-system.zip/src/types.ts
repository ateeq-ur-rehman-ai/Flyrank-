export type CurrencyCode = 'PKR' | 'CNY' | 'AED' | 'SAR' | 'QAR' | 'KWD' | 'BHD' | 'OMR' | 'USD';

export interface CurrencyInfo {
  code: CurrencyCode;
  name: string;
  symbol: string;
  flag: string;
  rateToPKR: number; // 1 Foreign Unit = X PKR
  country: string;
}

export type Region = 'China' | 'Gulf';

export type Country = 'China' | 'UAE' | 'Saudi Arabia' | 'Qatar' | 'Kuwait' | 'Bahrain' | 'Oman';

export interface BankDetails {
  bankName: string;
  swiftCode: string;
  accountNumber: string;
  accountName: string;
  currency: CurrencyCode;
  branchCity: string;
}

export interface Vendor {
  id: string;
  code: string;
  name: string;
  region: Region;
  country: Country;
  city: string;
  contactPerson: string;
  email: string;
  phone: string;
  weChatOrWhatsapp?: string;
  address: string;
  category: string;
  bankDetails: BankDetails;
  totalImportValuePKR: number;
  totalPaidPKR: number;
  pendingBalancePKR: number;
  activeContainersCount: number;
  totalContainersCount: number;
  createdAt: string;
}

export type PaymentMethod = 
  | 'Telegraphic Transfer (TT)' 
  | 'Letter of Credit (LC)' 
  | 'Hawala / Exchange House' 
  | 'Direct Bank Wire' 
  | 'Cash Advance';

export type PaymentStatus = 'Completed' | 'Pending' | 'Scheduled';

export interface Payment {
  id: string;
  paymentRef: string;
  vendorId: string;
  vendorName: string;
  vendorCountry: Country;
  containerId?: string;
  containerNumber?: string;
  invoiceNumber: string;
  paymentDate: string;
  amount: number; // In original foreign currency
  currency: CurrencyCode;
  exchangeRateToPKR: number;
  amountPKR: number;
  paymentMethod: PaymentMethod;
  status: PaymentStatus;
  notes?: string;
  createdAt: string;
}

export type ContainerStatus = 'In Transit' | 'Arrived' | 'Unloading' | 'Unloaded' | 'Completed';

export interface TrackingMilestone {
  step: string;
  location: string;
  timestamp: string;
  completed: boolean;
  notes?: string;
}

export interface Container {
  id: string;
  containerNumber: string;
  blNumber: string;
  shippingLine: string;
  vesselName: string;
  vendorId: string;
  vendorName: string;
  originCountry: Country;
  portOfLoading: string;
  destinationPort: string;
  shipmentDate: string;
  expectedArrival: string;
  actualArrival?: string;
  unloadingDate?: string;
  completedDate?: string;
  shipmentValue: number; // Foreign currency
  currency: CurrencyCode;
  exchangeRateToPKR: number;
  shipmentValuePKR: number;
  status: ContainerStatus;
  cargoDescription: string;
  containerSize: '20ft Standard' | '40ft High Cube' | '40ft Standard' | 'LCL Cargo';
  packagesCount: number; // e.g. 750 cartons
  totalWeightKg: number;
  customDutyPaidPKR?: number;
  trackingMilestones: TrackingMilestone[];
  createdAt: string;
}

export interface ActivityLog {
  id: string;
  timestamp: string;
  type: 'payment' | 'container' | 'vendor' | 'rate';
  title: string;
  description: string;
  amountPKR?: number;
  tag?: string;
}

export type ActiveModule = 'dashboard' | 'vendors' | 'containers' | 'converter' | 'reports';

export interface UserProfile {
  name: string;
  role: string;
  email: string;
  avatarText: string;
}
