import React from 'react';
import {
  LayoutDashboard,
  Users,
  Container as ContainerIcon,
  ArrowRightLeft,
  FileBarChart,
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { AppProvider, useApp } from './context/AppContext';
import { Sidebar } from './components/layout/Sidebar';
import { Header } from './components/layout/Header';
import { LoginScreen } from './components/auth/LoginScreen';
import { DashboardModule } from './components/dashboard/DashboardModule';
import { VendorsModule } from './components/vendors/VendorsModule';
import { ContainersModule } from './components/containers/ContainersModule';
import { CurrencyConverterModule } from './components/currency/CurrencyConverterModule';
import { ReportsModule } from './components/reports/ReportsModule';

// Modals
import { VendorDetailModal } from './components/modals/VendorDetailModal';
import { ContainerDetailModal } from './components/modals/ContainerDetailModal';
import { AddVendorModal } from './components/modals/AddVendorModal';
import { AddPaymentModal } from './components/modals/AddPaymentModal';
import { AddContainerModal } from './components/modals/AddContainerModal';

const MainLayout: React.FC = () => {
  const { currentUser, activeModule, setActiveModule } = useApp();

  if (!currentUser) {
    return <LoginScreen />;
  }

  const renderModule = () => {
    switch (activeModule) {
      case 'dashboard':
        return <DashboardModule />;
      case 'vendors':
        return <VendorsModule />;
      case 'containers':
        return <ContainersModule />;
      case 'converter':
        return <CurrencyConverterModule />;
      case 'reports':
        return <ReportsModule />;
      default:
        return <DashboardModule />;
    }
  };

  const mobileNavItems = [
    { id: 'dashboard' as const, label: 'Dashboard', icon: LayoutDashboard },
    { id: 'vendors' as const, label: 'Vendors', icon: Users },
    { id: 'containers' as const, label: 'Containers', icon: ContainerIcon },
    { id: 'converter' as const, label: 'Forex', icon: ArrowRightLeft },
    { id: 'reports' as const, label: 'Reports', icon: FileBarChart },
  ];

  return (
    <div className="flex h-screen bg-[#FBF9F5] text-stone-900 font-sans overflow-hidden">
      {/* Navigation Sidebar (Desktop + Mobile Drawer) */}
      <Sidebar />

      {/* Main Workspace Area */}
      <div className="flex-1 flex flex-col min-w-0 overflow-hidden">
        {/* Global DCC Header */}
        <Header />

        {/* Scrollable Viewport with Motion Fade Transitions */}
        <main className="flex-1 overflow-y-auto bg-[#FBF9F5] scroll-smooth pb-16 lg:pb-0">
          <AnimatePresence mode="wait">
            <motion.div
              key={activeModule}
              initial={{ opacity: 0, y: 8 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -8 }}
              transition={{ duration: 0.22, ease: 'easeOut' }}
            >
              {renderModule()}
            </motion.div>
          </AnimatePresence>
        </main>

        {/* Mobile Bottom Navigation Bar */}
        <nav className="lg:hidden fixed bottom-0 left-0 right-0 z-30 bg-white/95 backdrop-blur-md border-t border-stone-200 px-2 py-1.5 flex items-center justify-around shadow-[0_-2px_10px_rgba(0,0,0,0.04)]">
          {mobileNavItems.map((tab) => {
            const Icon = tab.icon;
            const isActive = activeModule === tab.id;
            return (
              <button
                key={tab.id}
                onClick={() => setActiveModule(tab.id)}
                className={`flex flex-col items-center justify-center py-1 px-2.5 rounded-xl transition-all cursor-pointer ${
                  isActive
                    ? 'text-stone-950 font-bold'
                    : 'text-stone-500 hover:text-stone-800'
                }`}
              >
                <div
                  className={`p-1 rounded-lg transition-colors ${
                    isActive ? 'bg-amber-100 text-amber-950' : ''
                  }`}
                >
                  <Icon className="w-4 h-4" />
                </div>
                <span className="text-[10px] mt-0.5 tracking-tight">{tab.label}</span>
              </button>
            );
          })}
        </nav>
      </div>

      {/* Global Modals */}
      <VendorDetailModal />
      <ContainerDetailModal />
      <AddVendorModal />
      <AddPaymentModal />
      <AddContainerModal />
    </div>
  );
};

export default function App() {
  return (
    <AppProvider>
      <MainLayout />
    </AppProvider>
  );
}
