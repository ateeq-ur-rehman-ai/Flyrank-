import { CurrencyCode, ContainerStatus, PaymentStatus } from '../types';

export function formatPKR(amount: number, compact: boolean = false): string {
  if (isNaN(amount) || amount === null || amount === undefined) return 'Rs 0';
  
  if (compact) {
    if (Math.abs(amount) >= 10000000) {
      return `Rs ${(amount / 10000000).toFixed(2)} Cr`;
    }
    if (Math.abs(amount) >= 1000000) {
      return `Rs ${(amount / 1000000).toFixed(2)}M`;
    }
    if (Math.abs(amount) >= 1000) {
      return `Rs ${(amount / 1000).toFixed(1)}k`;
    }
  }

  return 'Rs ' + Math.round(amount).toLocaleString('en-PK');
}

export function formatCurrency(amount: number, currency: CurrencyCode): string {
  if (isNaN(amount) || amount === null || amount === undefined) return `${currency} 0`;

  const symbols: Record<CurrencyCode, string> = {
    PKR: 'Rs',
    CNY: '¥',
    AED: 'AED',
    SAR: 'SAR',
    QAR: 'QAR',
    KWD: 'KWD',
    BHD: 'BHD',
    OMR: 'OMR',
    USD: '$',
  };

  const symbol = symbols[currency] || currency;
  const formatted = Math.round(amount * 100) / 100;
  
  if (currency === 'USD' || currency === 'CNY') {
    return `${symbol}${formatted.toLocaleString('en-US', { minimumFractionDigits: 0, maximumFractionDigits: 2 })}`;
  }
  
  return `${symbol} ${formatted.toLocaleString('en-US', { minimumFractionDigits: 0, maximumFractionDigits: 2 })}`;
}

export function formatDate(dateString?: string): string {
  if (!dateString) return '—';
  try {
    const d = new Date(dateString);
    if (isNaN(d.getTime())) return dateString;
    return d.toLocaleDateString('en-GB', { day: '2-digit', month: 'short', year: 'numeric' });
  } catch {
    return dateString;
  }
}

export function getDaysUntil(dateString?: string): { text: string; isPast: boolean; days: number } {
  if (!dateString) return { text: '—', isPast: false, days: 0 };
  const target = new Date(dateString).getTime();
  const now = new Date('2026-08-24T08:52:00').getTime(); // Current system mock time
  const diffDays = Math.round((target - now) / (1000 * 60 * 60 * 24));

  if (diffDays === 0) return { text: 'Today', isPast: false, days: 0 };
  if (diffDays === 1) return { text: 'Tomorrow', isPast: false, days: 1 };
  if (diffDays === -1) return { text: 'Yesterday', isPast: true, days: -1 };
  if (diffDays > 0) return { text: `In ${diffDays} days`, isPast: false, days: diffDays };
  return { text: `${Math.abs(diffDays)} days ago`, isPast: true, days: diffDays };
}

export function getContainerStatusBadge(status: ContainerStatus): { bg: string; text: string; border: string; dot: string } {
  switch (status) {
    case 'In Transit':
      return {
        bg: 'bg-blue-50 text-blue-700',
        text: 'In Transit',
        border: 'border-blue-200',
        dot: 'bg-blue-600 animate-pulse',
      };
    case 'Arrived':
      return {
        bg: 'bg-amber-50 text-amber-700',
        text: 'Arrived at Port',
        border: 'border-amber-200',
        dot: 'bg-amber-500',
      };
    case 'Unloading':
      return {
        bg: 'bg-purple-50 text-purple-700',
        text: 'Unloading',
        border: 'border-purple-200',
        dot: 'bg-purple-600 animate-spin',
      };
    case 'Unloaded':
      return {
        bg: 'bg-teal-50 text-teal-700',
        text: 'Unloaded (In QC)',
        border: 'border-teal-200',
        dot: 'bg-teal-600',
      };
    case 'Completed':
      return {
        bg: 'bg-emerald-50 text-emerald-700',
        text: 'Completed',
        border: 'border-emerald-200',
        dot: 'bg-emerald-500',
      };
    default:
      return {
        bg: 'bg-slate-100 text-slate-700',
        text: status,
        border: 'border-slate-200',
        dot: 'bg-slate-500',
      };
  }
}

export function getPaymentStatusBadge(status: PaymentStatus): { bg: string; text: string; border: string } {
  switch (status) {
    case 'Completed':
      return { bg: 'bg-emerald-50 text-emerald-700 border-emerald-200', text: 'Completed', border: 'border-emerald-200' };
    case 'Pending':
      return { bg: 'bg-rose-50 text-rose-700 border-rose-200', text: 'Pending Approval', border: 'border-rose-200' };
    case 'Scheduled':
      return { bg: 'bg-blue-50 text-blue-700 border-blue-200', text: 'Scheduled', border: 'border-blue-200' };
    default:
      return { bg: 'bg-slate-100 text-slate-700 border-slate-200', text: status, border: 'border-slate-200' };
  }
}
