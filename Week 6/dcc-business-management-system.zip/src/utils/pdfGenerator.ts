import jsPDF from 'jspdf';
import autoTable from 'jspdf-autotable';
import { Vendor, Container, Payment, CurrencyInfo } from '../types';
import { formatPKR } from './formatters';

interface ReportPDFOptions {
  reportType: 'monthly' | 'vendor' | 'container' | 'import_value' | 'outstanding' | 'forex' | 'full_audit';
  reportTitle: string;
  scope: string;
  vendors: Vendor[];
  containers: Container[];
  payments: Payment[];
  currencies: CurrencyInfo[];
  userName?: string;
}

export const generateDCCReportPDF = (options: ReportPDFOptions) => {
  const { reportType, reportTitle, scope, vendors, containers, payments, currencies, userName = 'Admin Manager' } = options;

  // Create A4 Document (Landscape for wide financial tables, Portrait for others)
  const doc = new jsPDF({
    orientation: reportType === 'container' || reportType === 'full_audit' ? 'landscape' : 'portrait',
    unit: 'mm',
    format: 'a4',
  });

  const pageWidth = doc.internal.pageSize.getWidth();
  const pageHeight = doc.internal.pageSize.getHeight();

  // Color Palette
  const darkCharcoal: [number, number, number] = [28, 25, 23]; // #1C1917
  const warmAmber: [number, number, number] = [217, 119, 6]; // #D97706
  const emeraldGreen: [number, number, number] = [16, 149, 106]; // #10956a
  const softBg: [number, number, number] = [251, 249, 245]; // #FBF9F5
  const slateGray: [number, number, number] = [100, 116, 139];

  // 1. Top Decorative Brand Banner
  doc.setFillColor(darkCharcoal[0], darkCharcoal[1], darkCharcoal[2]);
  doc.rect(0, 0, pageWidth, 38, 'F');

  // Gold accent bar
  doc.setFillColor(warmAmber[0], warmAmber[1], warmAmber[2]);
  doc.rect(0, 38, pageWidth, 2, 'F');

  // DCC Monogram Logo Badge
  doc.setFillColor(245, 158, 11);
  doc.roundedRect(14, 8, 22, 22, 3, 3, 'F');
  doc.setTextColor(28, 25, 23);
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(11);
  doc.text('DCC', 25, 21, { align: 'center' });

  // Company Name & Subtitle
  doc.setTextColor(255, 255, 255);
  doc.setFontSize(16);
  doc.setFont('helvetica', 'bold');
  doc.text('DUBAI CLOTHING CENTER', 42, 17);

  doc.setFontSize(8.5);
  doc.setFont('helvetica', 'normal');
  doc.setTextColor(253, 230, 138); // light amber
  doc.text('EST. 1994 • Import Registry & Foreign Trade Financials • Karachi, Pakistan', 42, 24);

  // Right Side Header Metadata
  doc.setTextColor(220, 220, 220);
  doc.setFontSize(7.5);
  doc.text(`REPORT: ${reportTitle.toUpperCase()}`, pageWidth - 14, 14, { align: 'right' });
  doc.text(`DATE: ${new Date().toLocaleDateString('en-PK', { dateStyle: 'medium' })}`, pageWidth - 14, 20, { align: 'right' });
  doc.text(`PRINTED BY: ${userName}`, pageWidth - 14, 26, { align: 'right' });
  doc.text(`SCOPE: ${scope}`, pageWidth - 14, 32, { align: 'right' });

  // Aggregates for Metric Strip
  const totalSpend = vendors.reduce((sum, v) => sum + v.totalImportValuePKR, 0);
  const totalPaid = vendors.reduce((sum, v) => sum + v.totalPaidPKR, 0);
  const totalPending = vendors.reduce((sum, v) => sum + v.pendingBalancePKR, 0);
  const totalContainers = containers.length;

  // 2. Executive Summary Metrics Cards
  const cardY = 44;
  const cardHeight = 18;
  const cardWidth = (pageWidth - 28 - 9) / 4;

  const cards = [
    { title: 'TOTAL TRADE VALUE', val: `PKR ${(totalSpend / 1000000).toFixed(2)}M`, sub: `${vendors.length} Foreign Vendors`, color: [241, 245, 249], textCol: darkCharcoal },
    { title: 'SETTLED PAYMENTS', val: `PKR ${(totalPaid / 1000000).toFixed(2)}M`, sub: `${((totalPaid / (totalSpend || 1)) * 100).toFixed(1)}% Completed`, color: [236, 253, 245], textCol: emeraldGreen },
    { title: 'PENDING LIABILITIES', val: `PKR ${(totalPending / 1000000).toFixed(2)}M`, sub: 'Awaiting Customs/BL', color: [254, 243, 199], textCol: warmAmber },
    { title: 'ACTIVE CONTAINERS', val: `${totalContainers} Total`, sub: `${containers.filter(c => c.status === 'In Transit' || c.status === 'Arrived').length} In Port/Transit`, color: [248, 250, 252], textCol: darkCharcoal },
  ];

  cards.forEach((card, idx) => {
    const x = 14 + idx * (cardWidth + 3);
    doc.setFillColor(card.color[0], card.color[1], card.color[2]);
    doc.roundedRect(x, cardY, cardWidth, cardHeight, 2, 2, 'F');
    doc.setDrawColor(226, 232, 240);
    doc.roundedRect(x, cardY, cardWidth, cardHeight, 2, 2, 'S');

    doc.setFontSize(6.5);
    doc.setFont('helvetica', 'bold');
    doc.setTextColor(100, 116, 139);
    doc.text(card.title, x + 4, cardY + 5);

    doc.setFontSize(10);
    doc.setFont('helvetica', 'bold');
    doc.setTextColor(card.textCol[0], card.textCol[1], card.textCol[2]);
    doc.text(card.val, x + 4, cardY + 11.5);

    doc.setFontSize(6.5);
    doc.setFont('helvetica', 'normal');
    doc.setTextColor(120, 120, 120);
    doc.text(card.sub, x + 4, cardY + 15.5);
  });

  let startTableY = 67;

  // 3. Build Tables based on report type
  if (reportType === 'vendor' || reportType === 'full_audit') {
    const tableData = vendors.map((v) => [
      v.code,
      v.name,
      `${v.country} (${v.region})`,
      v.category,
      formatPKR(v.totalImportValuePKR),
      formatPKR(v.totalPaidPKR),
      formatPKR(v.pendingBalancePKR),
      `${v.totalContainersCount} Units`,
    ]);

    autoTable(doc, {
      startY: startTableY,
      head: [['Code', 'Vendor Name', 'Country & Region', 'Category', 'Total Imported', 'Total Paid', 'Pending Balance', 'Shipments']],
      body: tableData,
      theme: 'striped',
      headStyles: {
        fillColor: [28, 25, 23],
        textColor: [253, 230, 138],
        fontSize: 8,
        fontStyle: 'bold',
        halign: 'left',
      },
      columnStyles: {
        0: { fontStyle: 'bold', cellWidth: 16 },
        4: { fontStyle: 'bold', halign: 'right' },
        5: { textColor: [16, 149, 106], fontStyle: 'bold', halign: 'right' },
        6: { textColor: [180, 83, 9], fontStyle: 'bold', halign: 'right' },
        7: { halign: 'center' },
      },
      styles: {
        fontSize: 7.5,
        cellPadding: 2.5,
      },
      alternateRowStyles: {
        fillColor: [250, 248, 245],
      },
      margin: { left: 14, right: 14 },
    });
  } else if (reportType === 'container') {
    const tableData = containers.map((c) => [
      c.containerNumber,
      c.blNumber,
      c.vendorName,
      c.originCountry,
      c.status.replace('_', ' '),
      `${c.currency} ${c.shipmentValue.toLocaleString()}`,
      formatPKR(c.shipmentValuePKR),
      c.shipmentDate,
      c.actualArrival || c.expectedArrival,
    ]);

    autoTable(doc, {
      startY: startTableY,
      head: [['Container #', 'BL Number', 'Vendor / Supplier', 'Origin', 'Status', 'Invoice Amount', 'Value in PKR', 'Ship Date', 'Port Arrival']],
      body: tableData,
      theme: 'striped',
      headStyles: {
        fillColor: [28, 25, 23],
        textColor: [253, 230, 138],
        fontSize: 8,
        fontStyle: 'bold',
      },
      columnStyles: {
        0: { fontStyle: 'bold' },
        4: { fontStyle: 'bold' },
        6: { fontStyle: 'bold', halign: 'right' },
      },
      styles: {
        fontSize: 7.5,
        cellPadding: 2.5,
      },
      alternateRowStyles: {
        fillColor: [250, 248, 245],
      },
      margin: { left: 14, right: 14 },
    });
  } else if (reportType === 'monthly') {
    const tableData = [
      ['August 2026 (Current)', '6 Transactions', 'Rs. 43,267,700', 'Rs. 14,028,250', 'Rs. 57,295,950', 'CNY, AED, USD, SAR, KWD'],
      ['July 2026', '7 Transactions', 'Rs. 45,600,000', 'Rs. 0', 'Rs. 45,600,000', 'CNY, AED, USD'],
      ['June 2026', '8 Transactions', 'Rs. 37,800,000', 'Rs. 0', 'Rs. 37,800,000', 'CNY, AED, SAR'],
      ['May 2026', '6 Transactions', 'Rs. 32,450,000', 'Rs. 0', 'Rs. 32,450,000', 'CNY, USD, QAR'],
      ['April 2026', '9 Transactions', 'Rs. 48,100,000', 'Rs. 0', 'Rs. 48,100,000', 'CNY, AED, BHD, OMR'],
    ];

    autoTable(doc, {
      startY: startTableY,
      head: [['Month', 'Transactions Count', 'Paid Volume (PKR)', 'Pending Liabilities', 'Total Month Turnover', 'Currencies Settled']],
      body: tableData,
      theme: 'striped',
      headStyles: {
        fillColor: [28, 25, 23],
        textColor: [253, 230, 138],
        fontSize: 8,
        fontStyle: 'bold',
      },
      columnStyles: {
        0: { fontStyle: 'bold' },
        2: { textColor: [16, 149, 106], fontStyle: 'bold', halign: 'right' },
        3: { textColor: [180, 83, 9], fontStyle: 'bold', halign: 'right' },
        4: { fontStyle: 'bold', halign: 'right' },
      },
      styles: {
        fontSize: 8,
        cellPadding: 3,
      },
      alternateRowStyles: {
        fillColor: [250, 248, 245],
      },
      margin: { left: 14, right: 14 },
    });
  } else if (reportType === 'outstanding') {
    const tableData = vendors
      .filter((v) => v.pendingBalancePKR > 0)
      .map((v) => [
        v.code,
        v.name,
        v.country,
        formatPKR(v.totalImportValuePKR),
        formatPKR(v.totalPaidPKR),
        formatPKR(v.pendingBalancePKR),
        v.bankDetails.bankName,
        v.bankDetails.currency,
        `${v.activeContainersCount} En Route`,
      ]);

    autoTable(doc, {
      startY: startTableY,
      head: [['Code', 'Vendor Name', 'Country', 'Total Invoice Value', 'Paid (PKR)', 'Pending Balance (PKR)', 'Beneficiary Bank', 'Currency', 'Active Containers']],
      body: tableData,
      theme: 'striped',
      headStyles: {
        fillColor: [180, 83, 9],
        textColor: [255, 255, 255],
        fontSize: 8,
        fontStyle: 'bold',
      },
      columnStyles: {
        0: { fontStyle: 'bold' },
        5: { textColor: [180, 83, 9], fontStyle: 'bold', halign: 'right' },
      },
      styles: {
        fontSize: 7.5,
        cellPadding: 2.5,
      },
      margin: { left: 14, right: 14 },
    });
  } else if (reportType === 'forex') {
    const tableData = currencies.map((c) => [
      `${c.flag} ${c.code}`,
      c.name,
      c.country,
      `Rs. ${c.rateToPKR.toFixed(2)}`,
      formatPKR(c.rateToPKR * 10000),
      formatPKR(c.rateToPKR * 100000),
      formatPKR(c.rateToPKR * 500000),
    ]);

    autoTable(doc, {
      startY: startTableY,
      head: [['Currency', 'Name', 'Origin Country', 'Live Rate (PKR)', '10,000 Units (PKR)', '100,000 Units (PKR)', '500,000 Units (PKR)']],
      body: tableData,
      theme: 'striped',
      headStyles: {
        fillColor: [28, 25, 23],
        textColor: [253, 230, 138],
        fontSize: 8,
        fontStyle: 'bold',
      },
      columnStyles: {
        0: { fontStyle: 'bold' },
        3: { textColor: [16, 149, 106], fontStyle: 'bold', halign: 'right' },
        4: { halign: 'right' },
        5: { fontStyle: 'bold', halign: 'right' },
        6: { textColor: [180, 83, 9], fontStyle: 'bold', halign: 'right' },
      },
      styles: {
        fontSize: 7.5,
        cellPadding: 2.5,
      },
      alternateRowStyles: {
        fillColor: [250, 248, 245],
      },
      margin: { left: 14, right: 14 },
    });
  } else {
    // Import value / default payment ledger
    const tableData = payments.map((p) => [
      p.paymentRef,
      p.invoiceNumber,
      p.vendorName,
      p.paymentDate,
      `${p.currency} ${p.amount.toLocaleString()}`,
      `Rs. ${p.exchangeRateToPKR.toFixed(2)}`,
      formatPKR(p.amountPKR),
      p.paymentMethod,
      p.status,
    ]);

    autoTable(doc, {
      startY: startTableY,
      head: [['Payment Ref', 'Invoice #', 'Vendor Name', 'Payment Date', 'Forex Amount', 'Rate (PKR)', 'Total in PKR', 'Method', 'Status']],
      body: tableData,
      theme: 'striped',
      headStyles: {
        fillColor: [28, 25, 23],
        textColor: [253, 230, 138],
        fontSize: 8,
        fontStyle: 'bold',
      },
      columnStyles: {
        0: { fontStyle: 'bold' },
        6: { textColor: [16, 149, 106], fontStyle: 'bold', halign: 'right' },
      },
      styles: {
        fontSize: 7.5,
        cellPadding: 2.5,
      },
      alternateRowStyles: {
        fillColor: [250, 248, 245],
      },
      margin: { left: 14, right: 14 },
    });
  }

  // 4. Professional Stamp, Signature & Disclaimer Footer on all pages
  const totalPages = (doc as any).internal.getNumberOfPages();
  for (let i = 1; i <= totalPages; i++) {
    doc.setPage(i);

    // Decorative footer bar
    doc.setFillColor(245, 245, 244);
    doc.rect(0, pageHeight - 16, pageWidth, 16, 'F');
    doc.setFillColor(217, 119, 6);
    doc.rect(0, pageHeight - 16, pageWidth, 0.8, 'F');

    // Footer text
    doc.setFontSize(7);
    doc.setFont('helvetica', 'normal');
    doc.setTextColor(100, 116, 139);
    doc.text(
      'Dubai Clothing Center (DCC) • Official Internal Financial Record • Confidential • Subject to Bank Realization',
      14,
      pageHeight - 8
    );

    doc.setFont('helvetica', 'bold');
    doc.text(`Page ${i} of ${totalPages}`, pageWidth - 14, pageHeight - 8, { align: 'right' });
  }

  // Save the PDF
  const filename = `DCC_${reportTitle.replace(/[^a-zA-Z0-9]/g, '_')}_${new Date().toISOString().slice(0, 10)}.pdf`;
  doc.save(filename);
};
