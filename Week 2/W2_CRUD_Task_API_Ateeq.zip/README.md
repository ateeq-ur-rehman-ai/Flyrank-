# Task API — FlyRank Week 2

A small Express.js REST API that manages an in-memory to-do list.

## Requirements

- Node.js
- npm

## Install and run

```bash
npm install
npm start
```

The server runs at:

`http://localhost:3000`

Swagger UI:

`http://localhost:3000/docs`

> Data is stored only in memory, so it resets when the server restarts. This is intentional for Week 2.

## Endpoints

| Method | Endpoint | Purpose | Success |
|---|---|---|---|
| GET | `/` | API information | 200 |
| GET | `/health` | Health check | 200 |
| GET | `/tasks` | List all tasks | 200 |
| GET | `/tasks/:id` | Get one task | 200 / 404 |
| POST | `/tasks` | Create task | 201 / 400 |
| PUT | `/tasks/:id` | Update task | 200 / 400 / 404 |
| DELETE | `/tasks/:id` | Delete task | 204 / 404 |

## Example curl tests

### Read all

```bash
curl -i http://localhost:3000/tasks
```

### Read one

```bash
curl -i http://localhost:3000/tasks/1
```

### Missing task

```bash
curl -i http://localhost:3000/tasks/99
```

Expected: `404` with a JSON error.

### Create

```bash
curl -i -X POST http://localhost:3000/tasks -H "Content-Type: application/json" -d "{\"title\":\"Buy milk\"}"
```

Expected: `201`.

### Invalid create

```bash
curl -i -X POST http://localhost:3000/tasks -H "Content-Type: application/json" -d "{}"
```

Expected: `400`.

### Update

```bash
curl -i -X PUT http://localhost:3000/tasks/1 -H "Content-Type: application/json" -d "{\"done\":true}"
```

Expected: `200`.

### Delete

```bash
curl -i -X DELETE http://localhost:3000/tasks/1
```

Expected: `204`.

## Swagger

Open `/docs` and use **Try it out** to complete the CRUD cycle.

## AI vs Me — bonus stage

For the bonus stage, the AI-generated version must be kept separate from this hand-built version. Do not replace the hand-built submission with AI-generated code.

Use a separate folder such as `ai-version/`, run the same Stage 4 curl checks against it, compare the implementations, and record:

1. What the AI did better and whether I understand its implementation.
2. What the AI got wrong or silently ignored.
3. What my prompt failed to specify and what the AI decided itself.

Then improve the prompt once and record what changed.

## Commit plan

Create at least six meaningful commits, one per required stage:

1. `Stage 0: hello server`
2. `Stage 1: root and health endpoints`
3. `Stage 2: read endpoints with 404`
4. `Stage 3: create with validation`
5. `Stage 4: full CRUD`
6. `Stage 5: Swagger UI`
7. `Stage 6: publish and docs`

The assignment requires the public GitHub repository to contain at least six meaningful commits.
