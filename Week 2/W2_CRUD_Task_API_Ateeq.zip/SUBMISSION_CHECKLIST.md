# Submission Checklist

- [ ] Run `npm install` and `npm start`.
- [ ] Verify `/`, `/health`, `/tasks`, and `/tasks/:id`.
- [ ] Test POST, PUT, DELETE with correct status codes.
- [ ] Open `/docs` and test the CRUD cycle using Swagger UI.
- [ ] Add a Swagger screenshot to README.
- [ ] Add one real `curl -i` output to README.
- [ ] Create at least 6 meaningful Git commits.
- [ ] Create a public GitHub repository and push the project.
- [ ] If doing bonus Stage 7, keep AI code separate and add the real AI-vs-me findings.
