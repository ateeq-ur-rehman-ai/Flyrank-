# Task API

A simple CRUD API for managing tasks, built with Node.js and Express, backed by a SQLite database.

This project started as an in-memory CRUD API (Assignment 1) and was upgraded to use a real database (Assignment 2) — the API itself didn't change, only how the data is stored.

## Why SQLite?

SQLite was chosen because it's a **single file** database with **zero setup** — there's no separate database server to install, configure, or run. The entire database lives in one file (`tasks.db`) right next to the project code. It's perfect for small projects and learning, and it guarantees that data **survives a server restart**, unlike storing tasks in a JavaScript array in memory.

## Where the database lives

The database file is `tasks.db`, created automatically in the project's root folder the first time the server runs. It is **git-ignored** (see `.gitignore`), so every fresh clone of this repo starts with a clean database — the app creates the file and table, and seeds 3 example tasks automatically.

## How to run this project

```bash
git clone <this-repo-url>
cd task-api
npm install
node server.js
```

The server will start on `http://localhost:3000`. On first run, it automatically creates `tasks.db`, creates the `tasks` table, and seeds it with 3 example tasks.

## API Endpoints

| Method | Endpoint | Description |
|--------|--------------|----------------------------|
| GET | `/tasks` | Get all tasks |
| GET | `/tasks/:id` | Get a single task by id |
| POST | `/tasks` | Create a new task |
| PUT | `/tasks/:id` | Update an existing task |
| DELETE | `/tasks/:id` | Delete a task |
| GET | `/stats` | Get task counts (total/done/open) |
| GET | `/health` | Health check |
| GET | `/docs` | Swagger API documentation |

All endpoints behave exactly as they did in Assignment 1 — the only thing that changed is that data now persists in SQLite instead of disappearing on restart.

## Exploring the database directly

The database can be opened and inspected using [DB Browser for SQLite](https://sqlitebrowser.org/) (free). Below is a screenshot of the `tasks` table, queried directly in DB Browser's "Execute SQL" tab:

![DB Browser - Execute SQL showing all tasks](./db-browser-screenshot.png)

### Proof: the API and the database are the same file

After running `UPDATE tasks SET done = 1;` in DB Browser and clicking "Write Changes," the API immediately reflected the change — with no server restart:

![API showing live-updated data after a manual SQL change](./live-update-proof.png)

### Example SQL query I ran

```sql
UPDATE tasks SET done = 1;
```

I ran this query directly in DB Browser's "Execute SQL" tab, then clicked "Write Changes." Without restarting the server, refreshing `GET /tasks` in the browser immediately showed every task with `done: 1`. This proved that the API and DB Browser were reading and writing the exact same `tasks.db` file — there is no syncing step, just one shared source of truth.

## What I learned

The biggest takeaway from this assignment: **the API is a promise, and the database is where that promise is kept.** Swapping the storage layer from an in-memory array to SQLite required zero changes to the routes, request bodies, or response shapes — only the code behind each endpoint that reads/writes data changed. This separation between the API layer and the data layer is one of the foundational ideas in backend development.
