const { Pool } = require('pg');

const pool = new Pool({
  connectionString: process.env.DATABASE_URL
});

const mapTask = (row) => ({
  id: Number(row.id),
  title: row.title,
  done: Boolean(row.done)
});

const taskRepository = {
  async findAll() {
    const { rows } = await pool.query(
      'SELECT id, title, done FROM tasks ORDER BY id'
    );
    return rows.map(mapTask);
  },

  async findById(id) {
    const { rows } = await pool.query(
      'SELECT id, title, done FROM tasks WHERE id = $1',
      [id]
    );
    return rows[0] ? mapTask(rows[0]) : null;
  },

  async create(title) {
    const { rows } = await pool.query(
      'INSERT INTO tasks (title, done) VALUES ($1, $2) RETURNING id, title, done',
      [title, false]
    );
    return mapTask(rows[0]);
  },

  async update(id, title, done) {
    const { rows } = await pool.query(
      'UPDATE tasks SET title = $1, done = $2 WHERE id = $3 RETURNING id, title, done',
      [title, done, id]
    );
    return rows[0] ? mapTask(rows[0]) : null;
  },

  async delete(id) {
    const result = await pool.query('DELETE FROM tasks WHERE id = $1', [id]);
    return result.rowCount > 0;
  },

  async stats() {
    const { rows } = await pool.query(`
      SELECT
        COUNT(*)::int AS total,
        COUNT(*) FILTER (WHERE done = TRUE)::int AS done
      FROM tasks
    `);
    const total = rows[0].total;
    const done = rows[0].done;
    return { total, done, open: total - done };
  },

  async close() {
    await pool.end();
  }
};

module.exports = taskRepository;
