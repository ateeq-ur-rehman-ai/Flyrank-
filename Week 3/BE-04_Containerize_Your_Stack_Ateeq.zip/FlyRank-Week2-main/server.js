const express = require('express');
const swaggerUi = require('swagger-ui-express');
const openapiSpec = require('./openapi.json');
const repository = require('./repository');

const app = express();
const PORT = process.env.PORT || 3000;

app.use(express.json());

app.get('/', (req, res) => {
  res.json({
    name: 'Task API',
    version: '1.0',
    endpoints: ['/tasks']
  });
});

app.get('/health', async (req, res) => {
  try {
    await repository.findAll();
    res.json({ status: 'ok' });
  } catch (error) {
    res.status(503).json({ status: 'error', database: 'unavailable' });
  }
});

app.get('/tasks', async (req, res, next) => {
  try {
    res.json(await repository.findAll());
  } catch (error) {
    next(error);
  }
});

app.get('/tasks/:id', async (req, res, next) => {
  try {
    const task = await repository.findById(req.params.id);

    if (!task) {
      return res.status(404).json({ error: `Task ${req.params.id} not found` });
    }

    res.json(task);
  } catch (error) {
    next(error);
  }
});

app.post('/tasks', async (req, res, next) => {
  try {
    const { title } = req.body || {};

    if (!title || typeof title !== 'string' || title.trim() === '') {
      return res.status(400).json({ error: 'title is required and cannot be empty' });
    }

    res.status(201).json(await repository.create(title.trim()));
  } catch (error) {
    next(error);
  }
});

app.put('/tasks/:id', async (req, res, next) => {
  try {
    const task = await repository.findById(req.params.id);

    if (!task) {
      return res.status(404).json({ error: `Task ${req.params.id} not found` });
    }

    const { title, done } = req.body || {};

    if (title === undefined && done === undefined) {
      return res.status(400).json({ error: 'Provide at least title or done to update' });
    }

    if (title !== undefined && (typeof title !== 'string' || title.trim() === '')) {
      return res.status(400).json({ error: 'title cannot be empty' });
    }

    if (done !== undefined && typeof done !== 'boolean') {
      return res.status(400).json({ error: 'done must be true or false' });
    }

    const newTitle = title !== undefined ? title.trim() : task.title;
    const newDone = done !== undefined ? done : task.done;

    res.json(await repository.update(req.params.id, newTitle, newDone));
  } catch (error) {
    next(error);
  }
});

app.delete('/tasks/:id', async (req, res, next) => {
  try {
    const deleted = await repository.delete(req.params.id);

    if (!deleted) {
      return res.status(404).json({ error: `Task ${req.params.id} not found` });
    }

    res.status(204).send();
  } catch (error) {
    next(error);
  }
});

app.get('/stats', async (req, res, next) => {
  try {
    res.json(await repository.stats());
  } catch (error) {
    next(error);
  }
});

app.use('/docs', swaggerUi.serve, swaggerUi.setup(openapiSpec));

app.use((error, req, res, next) => {
  console.error(error);
  res.status(500).json({ error: 'Internal server error' });
});

const server = app.listen(PORT, () => {
  console.log(`Server running on http://localhost:${PORT}`);
  console.log(`Swagger docs at http://localhost:${PORT}/docs`);
});

const shutdown = async () => {
  server.close(async () => {
    await repository.close();
    process.exit(0);
  });
};

process.on('SIGINT', shutdown);
process.on('SIGTERM', shutdown);
