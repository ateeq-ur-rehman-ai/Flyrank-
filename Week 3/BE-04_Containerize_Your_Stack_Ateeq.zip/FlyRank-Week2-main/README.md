# Task API — Dockerized PostgreSQL CRUD

A RESTful CRUD API for managing tasks, built with **Node.js**, **Express.js**, and **PostgreSQL**, and containerized with **Docker Compose**.

This project is the Week 3 BE-04 continuation of the earlier CRUD/database work. The API contract and endpoint behavior are preserved while the persistence layer moves into PostgreSQL running in Docker.

## Goal

The stack demonstrates:

- PostgreSQL running in Docker
- Persistent Docker volume
- Database configuration through `.env`
- A committed `.env.example`
- SQL schema/seed initialization
- A dedicated PostgreSQL repository
- App + database started together with `docker compose up`
- Data surviving an app and database container restart

## Architecture

```text
Client
  ↓
Express API
  ↓
Task Repository
  ↓
PostgreSQL
  ↓
Docker volume (persistent data)
```

### A2 → A3 architecture note

The previous project stored tasks in SQLite. For BE-04, the storage implementation was replaced with a PostgreSQL repository while keeping the public API contract and validation behavior unchanged.

The previous A2 code did not expose a separate service class; therefore this version introduces the repository boundary required by BE-04 rather than falsely claiming that an existing service layer was unchanged. The route paths, HTTP methods, request/response shapes, and status-code behavior remain the same.

## Project structure

```text
.
├── Dockerfile
├── docker-compose.yml
├── .dockerignore
├── .env.example
├── .gitignore
├── init.sql
├── openapi.json
├── package.json
├── package-lock.json
├── repository.js
├── server.js
└── README.md
```

## Environment variables

Local secrets/configuration live in `.env`, which is gitignored.

Copy the example file if needed:

```bash
copy .env.example .env
```

For Docker Compose, the application connects to the database service using the `db` hostname.

`.env.example` is committed so another developer can see the required configuration without receiving the real `.env` file.

## Start the whole stack

From the project directory:

```bash
docker compose up --build
```

The app will be available at:

```text
http://localhost:3000
```

Swagger UI:

```text
http://localhost:3000/docs
```

Health check:

```text
http://localhost:3000/health
```

## Stop the stack

```bash
docker compose down
```

Do **not** use `docker compose down -v` when testing persistence because `-v` removes the PostgreSQL volume.

## Database persistence

PostgreSQL stores its data in the named Docker volume:

```text
postgres_data
```

The volume is mounted at PostgreSQL's data directory, so removing/recreating the database container does not remove the stored rows.

### Persistence proof

1. Start the stack:

```bash
docker compose up --build -d
```

2. Create a task:

```bash
curl -X POST http://localhost:3000/tasks ^
  -H "Content-Type: application/json" ^
  -d "{\"title\":\"Persistence test\"}"
```

3. Confirm it exists:

```bash
curl http://localhost:3000/tasks
```

4. Restart both containers without deleting the volume:

```bash
docker compose restart app db
```

5. Check the tasks again:

```bash
curl http://localhost:3000/tasks
```

The `Persistence test` row remains because PostgreSQL data is stored in `postgres_data`, not inside the app container.

## API endpoints

| Method | Endpoint | Purpose |
|---|---|---|
| GET | `/tasks` | Return all tasks |
| GET | `/tasks/:id` | Return one task |
| POST | `/tasks` | Create a task |
| PUT | `/tasks/:id` | Update a task |
| DELETE | `/tasks/:id` | Delete a task |
| GET | `/stats` | Return total/done/open counts |
| GET | `/health` | Check API/database health |
| GET | `/docs` | Swagger UI |

## Validation

The API keeps the previous validation behavior:

- Missing or empty `title` on POST → `400`
- Empty/invalid `title` on PUT → `400`
- Non-boolean `done` on PUT → `400`
- PUT with no fields → `400`
- Unknown task ID → `404`
- Successful create → `201`
- Successful delete → `204`

## SQL initialization

`init.sql` creates the `tasks` table:

```sql
CREATE TABLE IF NOT EXISTS tasks (
  id SERIAL PRIMARY KEY,
  title TEXT NOT NULL,
  done BOOLEAN NOT NULL DEFAULT FALSE
);
```

It also inserts three starter tasks only when the table is empty.

Important: PostgreSQL's Docker entrypoint runs files in `/docker-entrypoint-initdb.d/` only when the database is initialized for the first time. Existing volume data is not reseeded on every restart.

## Repository layer

`repository.js` is the only application layer responsible for PostgreSQL operations. It provides:

- `findAll()`
- `findById(id)`
- `create(title)`
- `update(id, title, done)`
- `delete(id)`
- `stats()`

SQL uses parameterized queries (`$1`, `$2`, etc.) so user input is passed separately from SQL text.

## Local development without Docker

Docker is the intended BE-04 path. If PostgreSQL is installed locally, create the database and set `DATABASE_URL` in `.env`, then run:

```bash
npm install
npm start
```

## Useful Docker commands

View running containers:

```bash
docker compose ps
```

View app logs:

```bash
docker compose logs app
```

View database logs:

```bash
docker compose logs db
```

Open a PostgreSQL shell:

```bash
docker compose exec db psql -U taskuser -d tasksdb
```

Inside `psql`:

```sql
SELECT * FROM tasks;
```

## BE-04 checklist

- [x] PostgreSQL runs in Docker
- [x] PostgreSQL uses a named volume
- [x] `.env` is gitignored
- [x] `.env.example` is committed
- [x] Table is created by one SQL file
- [x] PostgreSQL repository replaces SQLite storage
- [x] Public API contract remains unchanged
- [x] App + database start with `docker compose up`
- [x] README documents the persistence test

The persistence checkbox should only be treated as demonstrated after running the restart test locally and confirming the created row is still present.
