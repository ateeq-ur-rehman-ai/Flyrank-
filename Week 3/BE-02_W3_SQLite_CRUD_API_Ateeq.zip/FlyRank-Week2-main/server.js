const express = require('express');
const swaggerUi = require('swagger-ui-express');
const openapiSpec = require('./openapi.json');
const db = require('./db');

const app = express();
const PORT = process.env.PORT || 3000;

app.use(express.json());

const toTask = (row) => ({
  id: row.id,
  title: row.title,
  done: Boolean(row.done)
});

// Root + health
app.get('/', (req, res) => {
  res.json({
    name: 'Task API',
    version: '1.0',
    endpoints: ['/tasks']
  });
});

app.get('/health', (req, res) => {
  res.json({ status: 'ok' });
});

// Read
app.get('/tasks', (req, res) => {
  const rows = db.prepare('SELECT id, title, done FROM tasks ORDER BY id').all();
  res.json(rows.map(toTask));
});

app.get('/tasks/:id', (req, res) => {
  const task = db.prepare('SELECT id, title, done FROM tasks WHERE id = ?').get(req.params.id);

  if (!task) {
    return res.status(404).json({ error: `Task ${req.params.id} not found` });
  }

  res.json(toTask(task));
});

// Create
app.post('/tasks', (req, res) => {
  const { title } = req.body || {};

  if (!title || typeof title !== 'string' || title.trim() === '') {
    return res.status(400).json({ error: 'title is required and cannot be empty' });
  }

  const result = db
    .prepare('INSERT INTO tasks (title, done) VALUES (?, ?)')
    .run(title.trim(), 0);

  const task = db
    .prepare('SELECT id, title, done FROM tasks WHERE id = ?')
    .get(result.lastInsertRowid);

  res.status(201).json(toTask(task));
});

// Update
app.put('/tasks/:id', (req, res) => {
  const task = db
    .prepare('SELECT id, title, done FROM tasks WHERE id = ?')
    .get(req.params.id);

  if (!task) {
    return res.status(404).json({ error: `Task ${req.params.id} not found` });
  }

  const { title, done } = req.body || {};

  if (title === undefined && done === undefined) {
    return res.status(400).json({ error: 'Provide at least title or done to update' });
  }

  if (title !== undefined && (typeof title !== 'string' || title.trim() === '')) {
    return res.status(400).json({ error: 'title cannot be empty' });
  }

  if (done !== undefined && typeof done !== 'boolean') {
    return res.status(400).json({ error: 'done must be true or false' });
  }

  const newTitle = title !== undefined ? title.trim() : task.title;
  const newDone = done !== undefined ? (done ? 1 : 0) : task.done;

  db.prepare('UPDATE tasks SET title = ?, done = ? WHERE id = ?')
    .run(newTitle, newDone, req.params.id);

  const updated = db
    .prepare('SELECT id, title, done FROM tasks WHERE id = ?')
    .get(req.params.id);

  res.json(toTask(updated));
});

// Delete
app.delete('/tasks/:id', (req, res) => {
  const result = db.prepare('DELETE FROM tasks WHERE id = ?').run(req.params.id);

  if (result.changes === 0) {
    return res.status(404).json({ error: `Task ${req.params.id} not found` });
  }

  res.status(204).send();
});

// Bonus: statistics
app.get('/stats', (req, res) => {
  const total = db.prepare('SELECT COUNT(*) AS count FROM tasks').get().count;
  const done = db.prepare('SELECT COUNT(*) AS count FROM tasks WHERE done = 1').get().count;

  res.json({
    total,
    done,
    open: total - done
  });
});

app.use('/docs', swaggerUi.serve, swaggerUi.setup(openapiSpec));

const server = app.listen(PORT, () => {
  console.log(`Server running on http://localhost:${PORT}`);
  console.log(`Swagger docs at http://localhost:${PORT}/docs`);
  console.log(`SQLite database: ${require('path').join(__dirname, 'tasks.db')}`);
});

process.on('SIGINT', () => {
  db.close();
  server.close(() => process.exit(0));
});
