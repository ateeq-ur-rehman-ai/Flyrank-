# Task API — SQLite CRUD

A RESTful CRUD API for managing tasks, built with **Node.js**, **Express.js**, and **SQLite** using `better-sqlite3`.

This project continues the Week 2 CRUD API. The API contract stays the same while the storage layer changes from an in-memory JavaScript array to a persistent SQLite database.

## Architecture

```text
Client → Express API → SQLite database (tasks.db)
```

The client still uses the same CRUD endpoints. Restarting the server no longer deletes tasks.

## Why SQLite?

SQLite is a lightweight relational database stored in a single file. It requires no separate database server, which makes it a good fit for this assignment and for learning SQL and persistence.

## Database

The application uses:

- Database file: `tasks.db`
- Table: `tasks`
- Columns: `id`, `title`, `done`
- Library: `better-sqlite3`

On startup, `db.js` automatically:

1. Opens `tasks.db` (or creates it if missing).
2. Creates the `tasks` table if it does not exist.
3. Inserts three example tasks only when the table is empty.

The database file is intentionally ignored by Git so a fresh clone can create its own local database.

## Requirements

- Node.js 18+
- npm

## Run locally

```bash
npm install
npm start
```

Server:

```text
http://localhost:3000
```

Swagger documentation:

```text
http://localhost:3000/docs
```

## API endpoints

| Method | Endpoint | Purpose |
|---|---|---|
| GET | `/tasks` | Return all tasks |
| GET | `/tasks/:id` | Return one task |
| POST | `/tasks` | Create a task |
| PUT | `/tasks/:id` | Update a task |
| DELETE | `/tasks/:id` | Delete a task |
| GET | `/stats` | Return total/done/open counts |
| GET | `/health` | Health check |
| GET | `/docs` | Swagger UI |

### Create a task

```bash
curl -X POST http://localhost:3000/tasks \
  -H "Content-Type: application/json" \
  -d '{"title":"Learn SQLite"}'
```

Successful creation returns HTTP `201`.

### Update a task

```bash
curl -X PUT http://localhost:3000/tasks/1 \
  -H "Content-Type: application/json" \
  -d '{"done":true}'
```

### Delete a task

```bash
curl -X DELETE http://localhost:3000/tasks/1
```

Successful deletion returns HTTP `204`.

## Validation

- Missing or empty `title` on POST → `400`
- Empty/invalid `title` on PUT → `400`
- Non-boolean `done` on PUT → `400`
- PUT with no fields → `400`
- Unknown task ID → `404`

Example `404`:

```json
{
  "error": "Task 999 not found"
}
```

## Persistence checkpoint

After creating a task:

1. Stop the server.
2. Start it again with `npm start`.
3. Run `GET /tasks`.
4. The created task should still exist.

This demonstrates persistence because the task is stored in `tasks.db`, not in a JavaScript array.

## Stage 4 — SQL practice

Open `tasks.db` in **DB Browser for SQLite** and run these queries manually:

```sql
SELECT * FROM tasks;
```

```sql
SELECT * FROM tasks WHERE done = 1;
```

```sql
SELECT COUNT(*) FROM tasks;
```

```sql
UPDATE tasks SET done = 1;
```

```sql
DELETE FROM tasks WHERE done = 1;
```

After making changes in the database viewer, call `GET /tasks` again to verify that the API reads the same database file.

## Stage 5 — Evidence

For the FlyRank submission, add a screenshot from DB Browser for SQLite showing the `tasks` table or an executed query. Save it in the repository as:

```text
db-browser-screenshot.png
```

Then add it to this README if desired:

```markdown
![SQLite database screenshot](./db-browser-screenshot.png)
```

## Stage commits

Use these commit messages when completing the stages:

```text
Stage 0: create SQLite database
Stage 1: database read endpoints
Stage 2: insert into database
Stage 3: update and delete with SQL
Stage 4: explored SQLite
Stage 5: database documentation
```

## Notes

The `tasks.db` file is local runtime data and is not committed to Git. The schema is recreated automatically by `db.js`, which means another developer can clone the repository, run `npm install`, and start the application without manually creating the database.
