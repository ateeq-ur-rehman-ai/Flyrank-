import httpx
from .config import settings

async def provider_a(ip: str):
    if not settings.geo_provider_a_enabled: raise RuntimeError("provider A disabled")
    r = await httpx.AsyncClient(timeout=3).get(f"http://ip-api.com/json/{ip}?fields=status,country,city")
    r.raise_for_status(); data = r.json()
    if data.get("status") != "success": raise RuntimeError("provider A failed")
    return {"country": data.get("country"), "city": data.get("city"), "provider": "ip-api"}

async def provider_b(ip: str):
    if not settings.geo_provider_b_enabled: raise RuntimeError("provider B disabled")
    r = await httpx.AsyncClient(timeout=3).get(f"https://ipapi.co/{ip}/json/")
    r.raise_for_status(); data = r.json()
    if data.get("error"): raise RuntimeError("provider B failed")
    return {"country": data.get("country_name"), "city": data.get("city"), "provider": "ipapi.co"}

async def enrich(ip: str):
    for fn in (provider_a, provider_b):
        try: return await fn(ip)
        except Exception as exc: print(f"geo fallback: {exc}")
    return {"country": None, "city": None, "provider": None}
