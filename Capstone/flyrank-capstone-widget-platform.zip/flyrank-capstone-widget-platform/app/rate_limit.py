import time
from collections import defaultdict, deque
from threading import Lock
from .config import settings

class RateLimiter:
    def __init__(self):
        self.events = defaultdict(deque)
        self.lock = Lock()
    def allow(self, key: str) -> bool:
        now = time.monotonic()
        with self.lock:
            q = self.events[key]
            while q and now - q[0] > settings.rate_limit_window_seconds:
                q.popleft()
            if len(q) >= settings.rate_limit_max_requests:
                return False
            q.append(now)
            return True
    def reset(self):
        with self.lock: self.events.clear()

limiter = RateLimiter()
