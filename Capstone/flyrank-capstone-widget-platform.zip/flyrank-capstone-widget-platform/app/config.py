from pydantic_settings import BaseSettings, SettingsConfigDict

class Settings(BaseSettings):
    database_url: str = "sqlite:///./widget_platform.db"
    api_host: str = "0.0.0.0"
    api_port: int = 8000
    cors_allow_origins: str = "http://localhost:3001,http://127.0.0.1:3001"
    rate_limit_window_seconds: int = 60
    rate_limit_max_requests: int = 5
    max_submission_bytes: int = 10000
    geo_provider_a_enabled: bool = True
    geo_provider_b_enabled: bool = True
    side_effect_enabled: bool = True
    model_config = SettingsConfigDict(env_file=".env", case_sensitive=False, extra="ignore")

settings = Settings()
