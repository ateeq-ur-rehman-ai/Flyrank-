from contextlib import asynccontextmanager
from datetime import datetime
import asyncio, json
from fastapi import FastAPI, Depends, Header, HTTPException, Request, Response
from fastapi.middleware.cors import CORSMiddleware
from sqlalchemy import func
from sqlalchemy.orm import Session
from .config import settings
from .db import Base, engine, get_db
from .models import Tenant, Widget, Submission
from .schemas import TokenRequest, WidgetCreate, WidgetUpdate
from .security import current_tenant
from .rate_limit import limiter
from .geo import enrich
from . import worker

worker_task = None

@asynccontextmanager
async def lifespan(app: FastAPI):
    global worker_task
    Base.metadata.create_all(bind=engine)
    worker.queue = asyncio.Queue()
    worker_task = asyncio.create_task(worker.side_effect_worker(worker.queue))
    yield
    worker_task.cancel()
    try: await worker_task
    except asyncio.CancelledError: pass

app = FastAPI(title="FlyRank Embeddable Widget & Lead-Capture Platform", version="1.0.0", lifespan=lifespan)
app.add_middleware(CORSMiddleware, allow_origins=[x.strip() for x in settings.cors_allow_origins.split(",") if x.strip()], allow_credentials=False, allow_methods=["GET","POST","PUT","DELETE","OPTIONS"], allow_headers=["*"])

def widget_out(w: Widget):
    return {"id":w.id,"widget_type":w.widget_type,"title":w.title,"description":w.description,"fields":w.fields,"button_text":w.button_text,"display_options":w.display_options,"version":w.version}

@app.get("/health")
def health(db: Session = Depends(get_db)):
    return {"status":"ok","service":"widget-platform","database":"connected"}

@app.post("/auth/token")
def token(body: TokenRequest, db: Session = Depends(get_db)):
    tenant = db.query(Tenant).filter(Tenant.email == body.email, Tenant.api_key == body.api_key).first()
    if not tenant: raise HTTPException(401, "Invalid credentials")
    return {"access_token": tenant.api_key, "token_type":"bearer", "tenant_id":tenant.id}

@app.post("/dev/seed")
def seed(db: Session = Depends(get_db)):
    tenant = db.query(Tenant).filter(Tenant.email=="demo@example.com").first()
    if not tenant:
        tenant = Tenant(email="demo@example.com", api_key="demo-secret-token")
        db.add(tenant); db.commit(); db.refresh(tenant)
    widget = db.query(Widget).filter(Widget.tenant_id==tenant.id).first()
    if not widget:
        widget = Widget(tenant_id=tenant.id, widget_type="signup", title="Get product updates", description="Join our list.", fields=[{"name":"email","label":"Email","type":"email","required":True},{"name":"name","label":"Name","type":"text","required":True}], button_text="Subscribe", display_options={"theme":"minimal"})
        db.add(widget); db.commit(); db.refresh(widget)
    return {"tenant_id":tenant.id,"email":tenant.email,"api_key":tenant.api_key,"widget":widget_out(widget)}

@app.post("/widgets")
def create_widget(body: WidgetCreate, db: Session = Depends(get_db), tenant: Tenant = Depends(current_tenant)):
    w=Widget(tenant_id=tenant.id, **body.model_dump()); db.add(w); db.commit(); db.refresh(w); return widget_out(w)

@app.get("/widgets")
def list_widgets(db: Session = Depends(get_db), tenant: Tenant = Depends(current_tenant)):
    return [widget_out(w) for w in db.query(Widget).filter(Widget.tenant_id==tenant.id).all()]

@app.get("/widgets/{widget_id}")
def get_widget(widget_id: str, db: Session = Depends(get_db), tenant: Tenant = Depends(current_tenant)):
    w=db.query(Widget).filter(Widget.id==widget_id, Widget.tenant_id==tenant.id).first()
    if not w: raise HTTPException(404,"Widget not found")
    return widget_out(w)

@app.put("/widgets/{widget_id}")
def update_widget(widget_id: str, body: WidgetUpdate, db: Session = Depends(get_db), tenant: Tenant = Depends(current_tenant)):
    w=db.query(Widget).filter(Widget.id==widget_id, Widget.tenant_id==tenant.id).first()
    if not w: raise HTTPException(404,"Widget not found")
    for k,v in body.model_dump().items(): setattr(w,k,v)
    w.version += 1; db.commit(); db.refresh(w); return widget_out(w)

@app.delete("/widgets/{widget_id}")
def delete_widget(widget_id: str, db: Session = Depends(get_db), tenant: Tenant = Depends(current_tenant)):
    w=db.query(Widget).filter(Widget.id==widget_id, Widget.tenant_id==tenant.id).first()
    if not w: raise HTTPException(404,"Widget not found")
    db.delete(w); db.commit(); return Response(status_code=204)

@app.get("/widgets/{widget_id}/embed")
def embed(widget_id: str, db: Session = Depends(get_db)):
    w=db.query(Widget).filter(Widget.id==widget_id).first()
    if not w: raise HTTPException(404,"Widget not found")
    return {"snippet":f'<script src="http://localhost:8000/widget.js?id={w.id}&v={w.version}"></script>'}

@app.get("/widgets/{widget_id}/config")
def public_config(widget_id: str, response: Response, db: Session = Depends(get_db)):
    w=db.query(Widget).filter(Widget.id==widget_id).first()
    if not w: raise HTTPException(404,"Widget not found")
    response.headers["Cache-Control"]="public, max-age=60"
    response.headers["Access-Control-Allow-Origin"]="*"
    return widget_out(w)

@app.get("/widget.js")
async def widget_js(id: str, v: int = 1, response: Response = None):
    response.headers["Cache-Control"]="public, max-age=31536000, immutable"
    response.headers["Access-Control-Allow-Origin"]="*"
    js = """(function(){const s=document.currentScript;const id=new URL(s.src).searchParams.get('id');fetch('http://localhost:8000/widgets/'+id+'/config').then(r=>r.json()).then(c=>{const root=document.createElement('div');root.style.maxWidth='420px';root.style.padding='16px';root.style.border='1px solid #ddd';root.style.fontFamily='sans-serif';root.innerHTML='<h3>'+c.title+'</h3><p>'+c.description+'</p>';const f=document.createElement('form');c.fields.forEach(x=>{const i=document.createElement('input');i.name=x.name;i.type=x.type||'text';i.placeholder=x.label;i.required=!!x.required;i.style.display='block';i.style.margin='8px 0';i.style.padding='8px';f.appendChild(i)});const hp=document.createElement('input');hp.name='honeypot';hp.tabIndex=-1;hp.autocomplete='off';hp.style.position='absolute';hp.style.left='-9999px';f.appendChild(hp);const b=document.createElement('button');b.textContent=c.button_text;f.appendChild(b);f.onsubmit=async e=>{e.preventDefault();const data=Object.fromEntries(new FormData(f));data.widget_id=id;const r=await fetch('http://localhost:8000/submissions',{method:'POST',headers:{'Content-Type':'application/json','Origin':location.origin},body:JSON.stringify(data)});alert(r.ok?'Thanks!':'Submission failed');};root.appendChild(f);document.body.appendChild(root)})})();"""
    return Response(js, media_type="application/javascript", headers={"Cache-Control":"public, max-age=31536000, immutable","Access-Control-Allow-Origin":"*"})

@app.options("/submissions")
def submissions_options(response: Response):
    response.headers["Access-Control-Allow-Origin"]="*"; response.headers["Access-Control-Allow-Methods"]="POST, OPTIONS"; response.headers["Access-Control-Allow-Headers"]="Content-Type, Idempotency-Key"; return Response(status_code=204, headers=dict(response.headers))

@app.post("/submissions")
async def submit(request: Request, db: Session = Depends(get_db), idempotency_key: str | None = Header(default=None, alias="Idempotency-Key")):
    raw=await request.body()
    if len(raw)>settings.max_submission_bytes: raise HTTPException(413,"Payload too large")
    try: payload=json.loads(raw)
    except json.JSONDecodeError: raise HTTPException(400,"Invalid JSON")
    if not isinstance(payload,dict): raise HTTPException(400,"JSON object required")
    widget_id=payload.get("widget_id")
    if not isinstance(widget_id,str): raise HTTPException(400,"widget_id is required")
    widget=db.query(Widget).filter(Widget.id==widget_id).first()
    if not widget: raise HTTPException(404,"Widget not found")
    ip=request.client.host if request.client else "unknown"
    if not limiter.allow(f"ip:{ip}") or not limiter.allow(f"widget:{widget_id}"):
        raise HTTPException(429,"Rate limit exceeded")
    if payload.get("honeypot"): return {"status":"accepted"}
    if idempotency_key:
        existing=db.query(Submission).filter(Submission.widget_id==widget_id, Submission.idempotency_key==idempotency_key).first()
        if existing: return {"id":existing.id,"status":"duplicate","created_at":existing.created_at}
    expected={x.get("name") for x in (widget.fields or []) if x.get("name")}
    clean={k:v for k,v in payload.items() if k in expected}
    for field in widget.fields or []:
        name=field.get("name")
        if field.get("required") and not clean.get(name): raise HTTPException(400,f"Missing required field: {name}")
        if name in clean and not isinstance(clean[name],str): raise HTTPException(400,f"Field {name} must be a string")
        if name in clean and len(clean[name])>2000: raise HTTPException(400,f"Field {name} is too long")
    geo=await enrich(ip)
    force_failure=bool(payload.get("simulate_side_effect_failure"))
    sub=Submission(tenant_id=widget.tenant_id, widget_id=widget.id, ip_address=ip, data=clean, country=geo["country"], city=geo["city"], provider=geo["provider"], idempotency_key=idempotency_key)
    db.add(sub)
    try:
        db.commit(); db.refresh(sub)
    except Exception:
        db.rollback(); raise HTTPException(409,"Duplicate idempotency key")
    await worker.enqueue_notification(sub.id, force_failure)
    return {"id":sub.id,"status":"stored","geo":{"country":sub.country,"city":sub.city,"provider":sub.provider}}

@app.get("/dashboard/submissions")
def dashboard_submissions(limit:int=50, db: Session=Depends(get_db), tenant:Tenant=Depends(current_tenant)):
    rows=db.query(Submission).filter(Submission.tenant_id==tenant.id).order_by(Submission.created_at.desc()).limit(min(limit,200)).all()
    return [{"id":r.id,"widget_id":r.widget_id,"data":r.data,"country":r.country,"city":r.city,"provider":r.provider,"created_at":r.created_at} for r in rows]

@app.get("/dashboard/stats")
def dashboard_stats(db:Session=Depends(get_db), tenant:Tenant=Depends(current_tenant)):
    total=db.query(func.count(Submission.id)).filter(Submission.tenant_id==tenant.id).scalar() or 0
    per_widget=db.query(Submission.widget_id,func.count(Submission.id)).filter(Submission.tenant_id==tenant.id).group_by(Submission.widget_id).all()
    geo=db.query(Submission.country,func.count(Submission.id)).filter(Submission.tenant_id==tenant.id,Submission.country.is_not(None)).group_by(Submission.country).all()
    return {"total_submissions":total,"per_widget":{k:v for k,v in per_widget},"geo_breakdown":{k:v for k,v in geo}}
