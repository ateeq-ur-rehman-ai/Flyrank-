from fastapi import Header, HTTPException, Depends
from sqlalchemy.orm import Session
from .models import Tenant
from .db import get_db

def current_tenant(db: Session = Depends(get_db), authorization: str | None = Header(default=None)) -> Tenant:
    if not authorization or not authorization.startswith("Bearer "):
        raise HTTPException(401, "Missing or invalid bearer token")
    token = authorization.removeprefix("Bearer ").strip()
    tenant = db.query(Tenant).filter(Tenant.api_key == token).first()
    if not tenant:
        raise HTTPException(401, "Invalid token")
    return tenant
