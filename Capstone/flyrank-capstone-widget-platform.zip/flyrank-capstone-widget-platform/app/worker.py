import asyncio
from .config import settings

queue = None

async def side_effect_worker(q: asyncio.Queue):
    while True:
        item = await q.get()
        try:
            if settings.side_effect_enabled:
                if item.get("force_failure"):
                    raise RuntimeError("simulated notification failure")
                print(f"[notification] confirmation queued for submission={item['submission_id']}")
        except Exception as exc:
            print(f"[notification] non-critical failure: {exc}")
        finally:
            q.task_done()

async def enqueue_notification(submission_id: str, force_failure: bool = False):
    if queue is None:
        print("[notification] queue unavailable; side effect skipped")
        return
    await queue.put({"submission_id": submission_id, "force_failure": force_failure})
