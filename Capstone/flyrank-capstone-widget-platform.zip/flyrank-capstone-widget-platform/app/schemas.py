from typing import Any, Literal
from pydantic import BaseModel, Field, ConfigDict

class TokenRequest(BaseModel):
    email: str
    api_key: str

class WidgetCreate(BaseModel):
    widget_type: Literal["signup", "contact", "cta", "popover"] = "signup"
    title: str = Field(min_length=1, max_length=120)
    description: str = Field(default="", max_length=500)
    fields: list[dict[str, Any]] = Field(default_factory=lambda: [{"name":"email","label":"Email","type":"email","required":True}])
    button_text: str = Field(default="Submit", min_length=1, max_length=80)
    display_options: dict[str, Any] = Field(default_factory=dict)

class WidgetUpdate(WidgetCreate):
    pass

class SubmissionIn(BaseModel):
    model_config = ConfigDict(extra="allow")
    widget_id: str
    honeypot: str = ""

class GeoResult(BaseModel):
    country: str | None = None
    city: str | None = None
    provider: str | None = None
