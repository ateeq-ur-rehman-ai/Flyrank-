import os
os.environ["DATABASE_URL"] = "sqlite:///./test_widget_platform.db"
os.environ["RATE_LIMIT_MAX_REQUESTS"] = "100"

import pytest
from fastapi.testclient import TestClient
from app.main import app
from app.db import Base, engine
from app.rate_limit import limiter

@pytest.fixture(autouse=True)
def clean_db(monkeypatch):
    Base.metadata.drop_all(engine)
    Base.metadata.create_all(engine)
    limiter.reset()
    async def fake_geo(ip):
        return {"country":"Pakistan","city":"Karachi","provider":"mock-a"}
    monkeypatch.setattr("app.main.enrich", fake_geo)

@pytest.fixture
def client():
    with TestClient(app) as c:
        yield c

def seed(client):
    r=client.post("/dev/seed")
    assert r.status_code==200
    return r.json()

def test_health_and_seed(client):
    assert client.get("/health").status_code==200
    data=seed(client)
    assert data["api_key"]=="demo-secret-token"

def test_submission_validation_and_idempotency(client):
    data=seed(client); wid=data["widget"]["id"]
    bad=client.post("/submissions",json={"widget_id":wid,"name":"Alice"})
    assert bad.status_code==400
    payload={"widget_id":wid,"email":"a@example.com","name":"Alice"}
    first=client.post("/submissions",json=payload,headers={"Idempotency-Key":"abc"})
    assert first.status_code==200
    assert first.json()["geo"]["provider"]=="mock-a"
    second=client.post("/submissions",json=payload,headers={"Idempotency-Key":"abc"})
    assert second.status_code==200 and second.json()["status"]=="duplicate"

def test_honeypot_does_not_store(client):
    data=seed(client); wid=data["widget"]["id"]
    r=client.post("/submissions",json={"widget_id":wid,"email":"bot@example.com","name":"Bot","honeypot":"filled"})
    assert r.status_code==200 and r.json()["status"]=="accepted"
