# FlyRank Capstone — Embeddable Widget & Lead-Capture Platform

A backend-focused embeddable widget platform built for the FlyRank Backend AI Engineering capstone. Customers create tenant-isolated widgets, receive a one-line embed snippet, and collect cross-origin submissions through a hardened public endpoint.

## Architecture

```text
Widget Owner
   │ Bearer auth
   ▼
Widget Management API ──► PostgreSQL
   │
   └──► embed snippet

Customer Website (localhost:3001)
   │ <script src="localhost:8000/widget.js?id=...">
   ▼
Cached Widget JS ──► Cached Public Config
   │
   ▼
POST /submissions (CORS)
   │
   ├─ boundary validation ──► 4xx
   ├─ rate limit/spam ───────► 429/drop
   ├─ geo A ─► geo B ─► no geo
   ├─ PostgreSQL store
   └─ background notification (failure is non-critical)

Widget Owner
   │ Bearer auth
   ▼
Dashboard API ──► submissions + stats
```

## Requirements covered
- Authenticated widget CRUD and tenant isolation.
- One-line embed snippet.
- Public cached config and long-cache widget JS.
- CORS + OPTIONS preflight.
- Boundary validation and 4xx errors.
- Per-IP/per-widget rate limiting.
- Honeypot spam control.
- IP geolocation fallback A → B → no geo.
- Non-blocking notification side effect via background queue.
- Dashboard submissions and analytics.
- Idempotency key handling.
- Environment-only secrets and `.env.example`.

## Run

```bash
git clone <your-public-repo-url>
cd flyrank-capstone-widget-platform
cp .env.example .env
docker compose up --build
```

Seed demo data:

```bash
curl -X POST http://localhost:8000/dev/seed
```

The seed response gives a demo token and widget ID. Get the embed snippet:

```bash
curl http://localhost:8000/widgets/WIDGET_ID/embed
```

Replace `REPLACE_WIDGET_ID` in `customer-site/index.html`, then serve that folder from a second origin:

```bash
python -m http.server 3001 -d customer-site
```

Open `http://localhost:3001`.

## Auth example

```bash
curl -X POST http://localhost:8000/auth/token \
  -H 'Content-Type: application/json' \
  -d '{"email":"demo@example.com","api_key":"demo-secret-token"}'
```

Then use `Authorization: Bearer demo-secret-token` for owner endpoints.

## Submission tests

Valid visitor submission:

```bash
curl -X POST http://localhost:8000/submissions \
  -H 'Content-Type: application/json' \
  -H 'Origin: http://localhost:3001' \
  -H 'Idempotency-Key: demo-001' \
  -d '{"widget_id":"WIDGET_ID","email":"visitor@example.com","name":"Demo Visitor","honeypot":""}'
```

Side-effect failure proof:

```bash
curl -X POST http://localhost:8000/submissions \
  -H 'Content-Type: application/json' \
  -d '{"widget_id":"WIDGET_ID","email":"fail@example.com","name":"Failure Test","simulate_side_effect_failure":true}'
```

Dashboard:

```bash
curl http://localhost:8000/dashboard/submissions -H 'Authorization: Bearer demo-secret-token'
curl http://localhost:8000/dashboard/stats -H 'Authorization: Bearer demo-secret-token'
```

## Tests

```bash
pytest -q
```

## Required files
`README.md`, `capstone.yaml`, `EVIDENCE.md`, `BUILDLOG.md`, `.env.example`, `DESIGN.md`.

## Limitations
The rate limiter is process-local, and the local widget uses localhost URLs. A production deployment would move rate limiting to shared storage, use a real domain/CDN, tighten allowed origins per tenant, and add observability and a larger automated regression suite.
