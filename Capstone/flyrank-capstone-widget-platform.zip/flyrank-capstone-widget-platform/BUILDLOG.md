# BUILDLOG

This project was developed with AI assistance for scaffolding, code review and documentation. Human review is responsible for architecture, requirements mapping, testing and final submission.

## AI-assisted areas
- Initial FastAPI/PostgreSQL project structure.
- Validation, CORS, rate-limit, geo fallback and background-worker scaffolding.
- README/EVIDENCE/capstone manifest drafting.

## Human review / changes
- Reviewed the capstone requirements and kept the implementation within the realistic scope.
- Added tenant isolation, idempotency, deterministic side-effect failure simulation and explicit evidence commands.
- Secrets are environment-only; `.env` is git-ignored.

## Known limitations
- In-memory rate limiter is process-local; a distributed deployment should use Redis or an equivalent shared limiter.
- Geo calls depend on external free APIs during manual development; tests can mock them.
- Widget script uses localhost API URLs for the local capstone demonstration.
