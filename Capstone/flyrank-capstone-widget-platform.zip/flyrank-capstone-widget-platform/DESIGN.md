# Design Document

## Problem
Customers need embeddable signup/contact widgets that can be installed with one script while submissions are validated, protected, enriched and dashboarded.

## Data model
- Tenant: isolated owner with API credential.
- Widget: tenant-owned configuration, fields, display options and version.
- Submission: tenant/widget-linked visitor payload plus IP/geo metadata and idempotency key.

## API surface
- Authenticated widget CRUD: `/widgets`
- Embed snippet: `/widgets/{id}/embed`
- Public cached config: `/widgets/{id}/config`
- Versioned-ish long-cache script: `/widget.js?id=...`
- Public CORS submission: `POST /submissions`
- Dashboard: `/dashboard/submissions`, `/dashboard/stats`

## Layer sketch
HTTP routes → validation/security → business flow → repository/ORM → PostgreSQL
                                  ↘ geo fallback
                                  ↘ background notification queue

## Explicit non-goal
No production CDN, real email provider, advanced form-builder UI, or hosted deployment is included; the capstone brief explicitly allows a local second-origin customer page.
