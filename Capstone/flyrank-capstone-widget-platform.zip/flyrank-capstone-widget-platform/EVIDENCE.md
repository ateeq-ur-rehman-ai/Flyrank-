# EVIDENCE

> Replace/extend the placeholders below with actual terminal output from your machine before submission. The capstone requires one pasted proof per requirement.

| Requirement | Proof command / expected evidence |
|---|---|
| Authenticated CRUD | `curl -i -X POST /widgets` without bearer → 401; with bearer → 200 |
| Tenant isolation | Tenant A requests Tenant B widget → 404 |
| Embed snippet | `GET /widgets/{id}/embed` returns one `<script>` line |
| Cached config | `curl -I /widgets/{id}/config` shows `Cache-Control: public, max-age=60` |
| Versioned/cached JS | `curl -I /widget.js?id={id}` shows long `Cache-Control` |
| Cross-origin CORS | `OPTIONS /submissions` → 204 and CORS headers |
| Validation | malformed JSON → 400; oversized body → 413 |
| Safe storage | valid POST → 200 and dashboard contains submission |
| Rate limiting | rapid requests → 429, later legitimate request succeeds |
| Spam control | non-empty honeypot → accepted without storing |
| Geo fallback | disable A in env → B result; disable both → stored with null geo |
| Safe side effect | `simulate_side_effect_failure=true` → submission still stored/succeeds |
| Idempotency | same `Idempotency-Key` twice → second response says `duplicate` |
| Background job | API logs notification queue processing after successful store |
