# EVIDENCE

Paste your own terminal output here before submission. The FlyRank brief requires checkable proof rather than claims.

## 1. Problem / overview document
- File exists: `My 10x Solution - Sufiyan Hussain.md`

## 2. Five+ concepts
- See README concept table and overview document.

## 3. Clean startup
```text
python seed.py
uvicorn app.main:app --reload
```

## 4. Authentication
```text
POST /auth/token -> access_token
Protected /jobs and /dashboard reject missing/invalid bearer tokens.
```

## 5. Persistence
```text
SQLite database survives application restart.
```

## 6. Caching
```text
First /ai/analyze response: cached=false
Second identical request: cached=true
```

## 7. Reporting/background job
```text
POST /reports/job-search -> {"status":"queued"}
GET /reports/job-search -> {"ready":true,...}
```

## 8. Tests
Run `pytest -q` and paste the real output here.
