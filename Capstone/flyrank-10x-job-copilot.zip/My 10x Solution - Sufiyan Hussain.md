# My 10x Solution - Sufiyan Hussain

## Problem
Job seekers often track applications across spreadsheets, browser tabs, notes, and separate resume versions. Reviewing whether a resume matches a job repeatedly is slow and easy to forget, while reporting progress requires manual counting.

## 10x claim
10x Job Copilot turns a roughly 20-minute manual application-review workflow into about 2 minutes by centralizing applications and reusing cached job/resume analysis.

## Solution
The system is a FastAPI backend with JWT authentication and a persistent SQLite database. Authenticated users can create and track job applications. A narrow `/ai/analyze` endpoint compares job requirements with resume text, returns a match score and missing keywords, caches identical analyses, and records an estimated AI cost. A background task generates a PDF job-search report.

## Concepts implemented
1. **API endpoints** — FastAPI routes for auth, jobs, analysis, dashboard, and reports.
2. **Database** — persistent SQLite tables for users, jobs, cache, and AI cost logs, with indexes.
3. **Authentication** — OAuth2 password login and JWT-protected routes with user ownership checks.
4. **Background jobs** — PDF generation is moved off the request path with FastAPI BackgroundTasks.
5. **Reporting** — ReportLab generates a job-search PDF.
6. **Caching logic** — SHA-256 cache keys reuse identical analysis results.
7. **LLM integration** — one narrow analysis endpoint with validation, grounding in supplied job/resume text, a provider adapter, and a cost log. The default mock is deterministic and free; an optional Gemini provider can be enabled with an environment key.

**Swaps:** none.

## Run
```bash
python -m venv .venv
pip install -r requirements.txt
python seed.py
uvicorn app.main:app --reload
```
Then open `http://127.0.0.1:8000/docs`.

Demo account: `demo@10x.local` / `demo12345`.

## Scope / non-goal
This capstone does not build a mobile app, real payroll, a recruiting marketplace, or a general autonomous agent. The core is intentionally limited to application tracking, one grounded analysis workflow, caching, and reporting.
