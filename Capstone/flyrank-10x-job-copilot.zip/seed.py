import os
os.environ.setdefault('DATABASE_PATH','10x.db')
from app.main import init_db, conn, pwd, now
init_db()
with conn() as c:
    c.execute("INSERT OR IGNORE INTO users(email,password_hash,created_at) VALUES(?,?,?)",('demo@10x.local',pwd.hash('demo12345'),now()))
    u=c.execute("SELECT id FROM users WHERE email=?",('demo@10x.local',)).fetchone()[0]
    if c.execute("SELECT COUNT(*) FROM jobs WHERE user_id=?",(u,)).fetchone()[0]==0:
        c.execute("INSERT INTO jobs(user_id,company,role,url,notes,status,created_at,updated_at) VALUES(?,?,?,?,?,?,?,?)",(u,'FlyRank','Backend AI Engineer','https://example.com','FastAPI Python PostgreSQL Redis LLM','interview',now(),now()))
print('Seeded demo account: demo@10x.local / demo12345')
