# BUILDLOG

This project was assembled with AI assistance. AI was used to accelerate scaffolding, documentation, test drafting, and review of edge cases. The implementation was then checked and adjusted so the author can explain the authentication, tenant filters, cache key, background report task, and database schema.

Notable decisions:
- Chose a job-application copilot because it naturally supports API, DB, auth, background work, reporting, caching, and a narrow AI feature.
- Used SQLite for zero-cost local reproducibility.
- Used a deterministic local analyzer rather than requiring a paid/external LLM key.
- Added explicit user_id filters to protected data queries.

Known limitations:
- SQLite is appropriate for the capstone demo but should be replaced by PostgreSQL for multi-worker production.
- FastAPI BackgroundTasks are not a durable queue; a real deployment should use a persistent worker queue.
- The AI analyzer is deliberately narrow and deterministic, not a full LLM.
