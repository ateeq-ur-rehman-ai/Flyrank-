# 10x Job Copilot

A portfolio-ready backend capstone that makes job application tracking and resume tailoring dramatically faster. It stores applications, protects user data with authentication, runs one narrow grounded AI job with a provider adapter (free deterministic mock by default, optional Gemini API), caching and cost logging, and generates a PDF report in a background task.

## 10x claim
A manual job-search review that takes ~20 minutes can be reduced to about 2 minutes by keeping applications in one place and reusing cached resume/job analysis.

## 5+ program concepts
| Concept | Implementation |
|---|---|
| API endpoints | FastAPI routes in `app/main.py` |
| Database | Persistent SQLite schema + indexes in `init_db()` |
| Authentication | OAuth2 password flow + JWT protected routes |
| Background job | `POST /reports/job-search` queues PDF generation with `BackgroundTasks` |
| Reporting | ReportLab PDF generated in `reports/` |
| Caching | SHA-256 keyed `ai_cache` table avoids repeated analysis |
| LLM integration | Narrow `/ai/analyze` provider adapter; mock by default, optional Gemini, validation and cost log |

No swaps were needed.

## Architecture
```text
Client
  |
  v
FastAPI HTTP layer -> Auth/JWT -> Service logic -> SQLite
                         |             |
                         |             +--> AI analysis -> cache + cost log
                         +--> background task -> PDF report
```

## Run
```bash
python -m venv .venv
# Windows: .venv\\Scripts\\activate
# Linux/macOS: source .venv/bin/activate
pip install -r requirements.txt
python seed.py
uvicorn app.main:app --reload
```

API docs: `http://127.0.0.1:8000/docs`

Demo account: `demo@10x.local` / `demo12345`

## 5-minute demo
1. Open `/docs`.
2. Register or use the demo account and obtain a bearer token from `/auth/token`.
3. Create/list a job with `/jobs`.
4. Call `/ai/analyze` with `Idempotency-Key`; call it again to show `cached: true`.
5. Open `/dashboard` to show application counts and estimated AI cost.
6. Call `/reports/job-search`, then `/reports/job-search` GET to confirm the PDF is ready.

## Security and limitations
Passwords are hashed; protected routes require JWTs. User-owned queries always filter by `user_id`. Secrets come from environment variables. The AI feature is intentionally narrow and grounded. The default provider is a deterministic local mock so the project stays $0 and reproducible; setting `LLM_PROVIDER=gemini` plus `GEMINI_API_KEY` enables a real free-tier Gemini integration. For production, move SQLite to PostgreSQL and use a real durable queue/worker for reports.

## Future ideas
- real LLM provider adapter with hard budget limits
- email delivery of reports
- calendar/interview reminders
- free-tier deployment

## Tests
```bash
pytest -q
```
