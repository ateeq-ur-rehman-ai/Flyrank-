import os, tempfile
os.environ["DATABASE_PATH"]=tempfile.mktemp(suffix=".db")
from fastapi.testclient import TestClient
from app.main import app

client=TestClient(app)
def auth():
    email="test@example.com"
    r=client.post('/auth/register',json={'email':email,'password':'password123'}); assert r.status_code in (201,409)
    r=client.post('/auth/token',data={'username':email,'password':'password123'}); return {'Authorization':'Bearer '+r.json()['access_token']}

def test_auth_and_tenant_isolation():
    h=auth(); r=client.post('/jobs',headers=h,json={'company':'Acme','role':'Python Backend Engineer','notes':'FastAPI PostgreSQL Redis'}); assert r.status_code==201
    assert client.get('/jobs',headers=h).json()[0]['company']=='Acme'

def test_ai_cache_and_report():
    h=auth(); jobs=client.get('/jobs',headers=h).json(); jid=jobs[0]['id']
    resume='Python FastAPI PostgreSQL Redis backend engineering experience'
    r=client.post('/ai/analyze',headers={**h,'Idempotency-Key':'abc'},json={'job_id':jid,'resume_text':resume}); assert r.status_code==200 and r.json()['cached'] is False
    r=client.post('/ai/analyze',headers={**h,'Idempotency-Key':'abc'},json={'job_id':jid,'resume_text':resume}); assert r.status_code==200 and r.json()['cached'] is True
    assert client.post('/reports/job-search',headers=h).status_code==200

def test_validation():
    h=auth(); assert client.post('/jobs',headers=h,json={'company':'','role':'x'}).status_code==422
