import hashlib, os, re, sqlite3, threading, time, json, urllib.request
from datetime import datetime, timedelta, timezone
from pathlib import Path
from typing import Optional
from fastapi import FastAPI, Depends, HTTPException, Header, BackgroundTasks
from fastapi.security import OAuth2PasswordBearer, OAuth2PasswordRequestForm
from jose import jwt, JWTError
from passlib.context import CryptContext
from pydantic import BaseModel, Field, EmailStr
from reportlab.lib.pagesizes import A4
from reportlab.pdfgen import canvas

DB_PATH = os.getenv("DATABASE_PATH", "10x.db")
SECRET_KEY = os.getenv("SECRET_KEY", "dev-only-secret-change-me")
ALGORITHM = "HS256"
BASE = Path(__file__).resolve().parent.parent
REPORT_DIR = BASE / "reports"
REPORT_DIR.mkdir(exist_ok=True)

app = FastAPI(title="10x Job Copilot", version="1.0.0")
oauth2 = OAuth2PasswordBearer(tokenUrl="/auth/token")
pwd = CryptContext(schemes=["bcrypt"], deprecated="auto")
_db_lock = threading.Lock()

class Register(BaseModel):
    email: EmailStr
    password: str = Field(min_length=8, max_length=72)

class JobCreate(BaseModel):
    company: str = Field(min_length=1, max_length=120)
    role: str = Field(min_length=1, max_length=160)
    url: Optional[str] = Field(default=None, max_length=500)
    notes: Optional[str] = Field(default=None, max_length=2000)
    status: str = Field(default="applied", pattern="^(saved|applied|interview|offer|rejected)$")

class AnalyzeRequest(BaseModel):
    job_id: int
    resume_text: str = Field(min_length=50, max_length=12000)


def conn():
    c = sqlite3.connect(DB_PATH, check_same_thread=False)
    c.row_factory = sqlite3.Row
    c.execute("PRAGMA foreign_keys=ON")
    return c


def init_db():
    with _db_lock, conn() as c:
        c.executescript('''
        CREATE TABLE IF NOT EXISTS users (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            email TEXT UNIQUE NOT NULL,
            password_hash TEXT NOT NULL,
            created_at TEXT NOT NULL
        );
        CREATE TABLE IF NOT EXISTS jobs (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id INTEGER NOT NULL,
            company TEXT NOT NULL,
            role TEXT NOT NULL,
            url TEXT,
            notes TEXT,
            status TEXT NOT NULL,
            created_at TEXT NOT NULL,
            updated_at TEXT NOT NULL,
            FOREIGN KEY(user_id) REFERENCES users(id) ON DELETE CASCADE
        );
        CREATE INDEX IF NOT EXISTS idx_jobs_user_status ON jobs(user_id,status);
        CREATE TABLE IF NOT EXISTS ai_cache (
            cache_key TEXT PRIMARY KEY,
            response TEXT NOT NULL,
            created_at TEXT NOT NULL
        );
        CREATE TABLE IF NOT EXISTS ai_cost_log (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id INTEGER NOT NULL,
            job_id INTEGER NOT NULL,
            input_chars INTEGER NOT NULL,
            output_chars INTEGER NOT NULL,
            estimated_cost_usd REAL NOT NULL,
            created_at TEXT NOT NULL
        );
        CREATE INDEX IF NOT EXISTS idx_cost_user ON ai_cost_log(user_id,created_at);
        ''')

@app.on_event("startup")
def startup(): init_db()

def now(): return datetime.now(timezone.utc).isoformat()

def token_for(user_id):
    return jwt.encode({"sub": str(user_id), "exp": datetime.now(timezone.utc)+timedelta(hours=12)}, SECRET_KEY, algorithm=ALGORITHM)

def current_user(token: str = Depends(oauth2)):
    try:
        payload = jwt.decode(token, SECRET_KEY, algorithms=[ALGORITHM])
        uid = int(payload["sub"])
    except (JWTError, KeyError, ValueError):
        raise HTTPException(401, "Invalid or expired token")
    with conn() as c:
        u = c.execute("SELECT id,email FROM users WHERE id=?", (uid,)).fetchone()
    if not u: raise HTTPException(401, "User not found")
    return dict(u)

@app.get("/health")
def health(): return {"status":"ok"}

@app.post("/auth/register", status_code=201)
def register(data: Register):
    with _db_lock, conn() as c:
        try:
            cur=c.execute("INSERT INTO users(email,password_hash,created_at) VALUES(?,?,?)",(data.email.lower(),pwd.hash(data.password),now()))
            return {"id":cur.lastrowid,"email":data.email.lower()}
        except sqlite3.IntegrityError: raise HTTPException(409,"Email already registered")

@app.post("/auth/token")
def login(form: OAuth2PasswordRequestForm=Depends()):
    with conn() as c: u=c.execute("SELECT * FROM users WHERE email=?",(form.username.lower(),)).fetchone()
    if not u or not pwd.verify(form.password,u["password_hash"]): raise HTTPException(401,"Invalid credentials")
    return {"access_token":token_for(u["id"]),"token_type":"bearer"}

@app.post("/jobs", status_code=201)
def create_job(data: JobCreate, user=Depends(current_user)):
    t=now()
    with _db_lock, conn() as c:
        cur=c.execute("INSERT INTO jobs(user_id,company,role,url,notes,status,created_at,updated_at) VALUES(?,?,?,?,?,?,?,?)",(user["id"],data.company,data.role,data.url,data.notes,data.status,t,t))
        return {"id":cur.lastrowid,**data.model_dump()}

@app.get("/jobs")
def list_jobs(user=Depends(current_user)):
    with conn() as c: rows=c.execute("SELECT id,company,role,url,notes,status,created_at,updated_at FROM jobs WHERE user_id=? ORDER BY updated_at DESC",(user["id"],)).fetchall()
    return [dict(r) for r in rows]

@app.patch("/jobs/{job_id}/status")
def update_status(job_id:int,status:str,user=Depends(current_user)):
    if status not in {"saved","applied","interview","offer","rejected"}: raise HTTPException(422,"Invalid status")
    with _db_lock, conn() as c:
        cur=c.execute("UPDATE jobs SET status=?,updated_at=? WHERE id=? AND user_id=?",(status,now(),job_id,user["id"]))
        if cur.rowcount==0: raise HTTPException(404,"Job not found")
    return {"id":job_id,"status":status}

STOPWORDS=set("the a an and or to of for in on with from as is are be this that your you we our at by".split())
def keywords(text):
    words=re.findall(r"[a-zA-Z][a-zA-Z0-9+#.-]{2,}",text.lower())
    return {w for w in words if w not in STOPWORDS}

def local_analysis(job, resume):
    req=keywords(job["role"]+" "+(job["notes"] or ""))
    have=keywords(resume)
    matched=sorted(req & have)[:20]; missing=sorted(req-have)[:20]
    score=round((len(matched)/max(len(req),1))*100)
    return {"job_id":job["id"],"company":job["company"],"role":job["role"],"match_score":score,"matched_keywords":matched,"missing_keywords":missing,"recommendation":"Strong match" if score>=70 else "Tailor resume" if score>=40 else "Low match — prioritize skill-building"}

def llm_analysis(job, resume):
    provider=os.getenv("LLM_PROVIDER","mock").lower()
    api_key=os.getenv("GEMINI_API_KEY")
    if provider == "gemini" and api_key:
        prompt=("Analyze this job/resume pair. Return JSON with match_score 0-100, matched_keywords, "
                "missing_keywords, recommendation. Ground every conclusion in the supplied text.\nJOB: "
                + job["role"]+" "+(job["notes"] or "")+"\nRESUME: "+resume)
        url="https://generativelanguage.googleapis.com/v1beta/models/gemini-2.0-flash:generateContent?key="+api_key
        body=json.dumps({"contents":[{"parts":[{"text":prompt}]}]}).encode()
        req=urllib.request.Request(url,data=body,headers={"Content-Type":"application/json"},method="POST")
        with urllib.request.urlopen(req,timeout=15) as r: payload=json.loads(r.read())
        text=payload["candidates"][0]["content"]["parts"][0]["text"]
        match=re.search(r"\{.*\}",text,re.S)
        if match:
            result=json.loads(match.group(0)); result.update({"job_id":job["id"],"company":job["company"],"role":job["role"]}); return result, "gemini"
    return local_analysis(job,resume), "mock"

@app.post("/ai/analyze")
def ai_analyze(data:AnalyzeRequest,user=Depends(current_user),idempotency_key:Optional[str]=Header(default=None,alias="Idempotency-Key")):
    if not idempotency_key: raise HTTPException(400,"Idempotency-Key header required")
    with conn() as c: job=c.execute("SELECT * FROM jobs WHERE id=? AND user_id=?",(data.job_id,user["id"])).fetchone()
    if not job: raise HTTPException(404,"Job not found")
    raw=f"{data.job_id}|{data.resume_text.strip()}|v1"; key=hashlib.sha256(raw.encode()).hexdigest()
    with conn() as c:
        cached=c.execute("SELECT response FROM ai_cache WHERE cache_key=?",(key,)).fetchone()
    if cached:
        import json
        return {**json.loads(cached["response"]),"cached":True}
    result, provider = llm_analysis(job,data.resume_text)
    result["provider"]=provider
    result["cached"]=False
    response=json.dumps(result)
    # Provider is explicit: mock is deterministic/free; Gemini is optional and key-gated.
    with _db_lock, conn() as c:
        c.execute("INSERT OR IGNORE INTO ai_cache(cache_key,response,created_at) VALUES(?,?,?)",(key,response,now()))
        cost=round((len(data.resume_text)+len(response))/1000000*0.002,8)
        c.execute("INSERT INTO ai_cost_log(user_id,job_id,input_chars,output_chars,estimated_cost_usd,created_at) VALUES(?,?,?,?,?,?)",(user["id"],data.job_id,len(data.resume_text),len(response),cost,now()))
    return result

def make_pdf(user_id):
    with conn() as c:
        user=c.execute("SELECT email FROM users WHERE id=?",(user_id,)).fetchone()
        jobs=c.execute("SELECT status,COUNT(*) n FROM jobs WHERE user_id=? GROUP BY status",(user_id,)).fetchall()
    path=REPORT_DIR/f"job-report-{user_id}.pdf"
    pdf=canvas.Canvas(str(path),pagesize=A4); w,h=A4
    pdf.setFont("Helvetica-Bold",18); pdf.drawString(50,h-60,"10x Job Search Report")
    pdf.setFont("Helvetica",10); pdf.drawString(50,h-80,f"Account: {user['email']} | Generated: {now()[:10]}")
    y=h-120
    for r in jobs: pdf.drawString(70,y,f"{r['status'].title()}: {r['n']}"); y-=22
    pdf.save(); return str(path)

@app.post("/reports/job-search")
def report(background_tasks:BackgroundTasks,user=Depends(current_user)):
    background_tasks.add_task(make_pdf,user["id"])
    return {"status":"queued","message":"PDF report generation started"}

@app.get("/reports/job-search")
def report_status(user=Depends(current_user)):
    path=REPORT_DIR/f"job-report-{user['id']}.pdf"
    return {"ready":path.exists(),"path":str(path) if path.exists() else None}

@app.get("/dashboard")
def dashboard(user=Depends(current_user)):
    with conn() as c:
        rows=c.execute("SELECT status,COUNT(*) n FROM jobs WHERE user_id=? GROUP BY status",(user["id"],)).fetchall()
        cost=c.execute("SELECT COALESCE(SUM(estimated_cost_usd),0) x FROM ai_cost_log WHERE user_id=?",(user["id"],)).fetchone()["x"]
    counts={r["status"]:r["n"] for r in rows}
    return {"total_jobs":sum(counts.values()),"by_status":counts,"estimated_ai_cost_usd":cost}
