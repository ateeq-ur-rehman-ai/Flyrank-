from pydantic import BaseModel, Field, ConfigDict
class TagOutput(BaseModel):
    subject: str
    category: str
    attributes: list[str]=Field(min_length=1,max_length=10)
    caption: str
    confidence: float=Field(ge=0,le=1)
class ReviewIn(BaseModel):
    suggestion_id: int
    action: str=Field(pattern="^(approve|reject)$")
    note: str|None=None
class SuggestionOut(BaseModel):
    image_id:int
    filename:str
    similarity:float
    decision:str
    reason:str
class PostOut(BaseModel):
    post_id:int
    title:str
    suggestions:list[SuggestionOut]
