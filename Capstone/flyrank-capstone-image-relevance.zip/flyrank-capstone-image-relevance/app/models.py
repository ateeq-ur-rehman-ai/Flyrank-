from datetime import datetime
from sqlalchemy import String, Text, Float, Integer, Boolean, DateTime, ForeignKey, Index
from sqlalchemy.orm import Mapped, mapped_column
from app.db import Base

class Image(Base):
    __tablename__="images"
    id: Mapped[int]=mapped_column(primary_key=True)
    filename: Mapped[str]=mapped_column(String(255), unique=True)
    subject: Mapped[str|None]=mapped_column(String(100))
    category: Mapped[str|None]=mapped_column(String(100))
    attributes: Mapped[str|None]=mapped_column(Text)
    caption: Mapped[str|None]=mapped_column(Text)
    confidence: Mapped[float|None]=mapped_column(Float)
    flagged: Mapped[bool]=mapped_column(Boolean, default=False)
    embedding: Mapped[str|None]=mapped_column(Text)
    processed: Mapped[bool]=mapped_column(Boolean, default=False)
    created_at: Mapped[datetime]=mapped_column(DateTime, default=datetime.utcnow)

class Post(Base):
    __tablename__="posts"
    id: Mapped[int]=mapped_column(primary_key=True)
    title: Mapped[str]=mapped_column(String(255))
    content: Mapped[str]=mapped_column(Text)
    embedding: Mapped[str|None]=mapped_column(Text)

class Suggestion(Base):
    __tablename__="suggestions"
    id: Mapped[int]=mapped_column(primary_key=True)
    post_id: Mapped[int]=mapped_column(ForeignKey("posts.id"))
    image_id: Mapped[int]=mapped_column(ForeignKey("images.id"))
    similarity: Mapped[float]=mapped_column(Float)
    decision: Mapped[str]=mapped_column(String(30))
    reason: Mapped[str]=mapped_column(Text)
    created_at: Mapped[datetime]=mapped_column(DateTime, default=datetime.utcnow)
    __table_args__=(Index("ix_suggestion_post","post_id"),)

class Review(Base):
    __tablename__="reviews"
    id: Mapped[int]=mapped_column(primary_key=True)
    suggestion_id: Mapped[int]=mapped_column(ForeignKey("suggestions.id"), unique=True)
    action: Mapped[str]=mapped_column(String(20))
    note: Mapped[str|None]=mapped_column(Text)

class CostLog(Base):
    __tablename__="cost_logs"
    id: Mapped[int]=mapped_column(primary_key=True)
    kind: Mapped[str]=mapped_column(String(40))
    provider: Mapped[str]=mapped_column(String(40))
    units: Mapped[int]=mapped_column(Integer, default=1)
    estimated_usd: Mapped[float]=mapped_column(Float, default=0.0)
    image_id: Mapped[int|None]=mapped_column(ForeignKey("images.id"))
    post_id: Mapped[int|None]=mapped_column(ForeignKey("posts.id"))
    created_at: Mapped[datetime]=mapped_column(DateTime, default=datetime.utcnow)
