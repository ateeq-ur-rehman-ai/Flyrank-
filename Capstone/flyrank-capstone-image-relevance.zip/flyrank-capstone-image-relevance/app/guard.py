from app.config import SIMILARITY_THRESHOLD, CONFIDENCE_THRESHOLD
def guard(post_text, image, similarity):
    p=post_text.lower()
    subject=(image.subject or "").lower()
    # Explicit semantic subject mismatch for the core fox/wolf demonstration.
    if "fox" in p and subject and "fox" not in subject:
        return "REJECTED", "Animal category mismatch: expected fox, detected " + subject
    if "wolf" in p and "wolf" not in subject and image.category=="animal":
        return "REJECTED", "Animal category mismatch: expected wolf, detected " + subject
    if (image.confidence or 0) < CONFIDENCE_THRESHOLD:
        return "REJECTED", "Low-confidence classification flagged for review"
    if similarity < SIMILARITY_THRESHOLD:
        return "REJECTED", f"Similarity {similarity:.3f} is below threshold {SIMILARITY_THRESHOLD:.2f}"
    return "ACCEPTED", "Similarity and confidence cleared the mismatch guard"
