import json, asyncio
from fastapi import FastAPI, Depends, HTTPException
from sqlalchemy.orm import Session
from app.db import Base, engine, get_db
from app.models import Image, Post, Suggestion, Review, CostLog
from app.jobs import process_images
from app.ai import cosine
from app.guard import guard
from app.schemas import ReviewIn, PostOut, SuggestionOut

Base.metadata.create_all(bind=engine)
app=FastAPI(title="FlyRank AI Image Understanding & Content Matching Engine",version="1.0.0")

@app.get("/health")
def health(): return {"status":"ok","service":"image-relevance"}

@app.post("/admin/batch/process")
async def batch_process(db:Session=Depends(get_db)):
    n=await process_images(db)
    return {"processed":n,"status":"completed"}

@app.get("/posts/{post_id}/images",response_model=PostOut)
def ranked(post_id:int,db:Session=Depends(get_db)):
    post=db.get(Post,post_id)
    if not post: raise HTTPException(404,"post not found")
    if not post.embedding:
        raise HTTPException(409,"run batch process first")
    pv=json.loads(post.embedding)
    rows=[]
    for im in db.query(Image).filter(Image.processed==True).all():
        sim=cosine(pv,json.loads(im.embedding))
        decision,reason=guard(post.title+" "+post.content,im,sim)
        rows.append((sim,im,decision,reason))
    rows.sort(key=lambda x:x[0],reverse=True)
    # Persist the top candidates, including rejected candidates, for explainability.
    out=[]
    for sim,im,decision,reason in rows[:10]:
        s=Suggestion(post_id=post.id,image_id=im.id,similarity=sim,decision=decision,reason=reason)
        db.add(s); db.flush()
        out.append(SuggestionOut(image_id=im.id,filename=im.filename,similarity=round(sim,4),decision=decision,reason=reason))
    db.commit()
    return {"post_id":post.id,"title":post.title,"suggestions":out}

@app.post("/reviews")
def review(body:ReviewIn,db:Session=Depends(get_db)):
    if not db.get(Suggestion,body.suggestion_id): raise HTTPException(404,"suggestion not found")
    existing=db.query(Review).filter_by(suggestion_id=body.suggestion_id).first()
    if existing:
        existing.action=body.action; existing.note=body.note
    else: db.add(Review(suggestion_id=body.suggestion_id,action=body.action,note=body.note))
    db.commit()
    return {"status":"recorded","suggestion_id":body.suggestion_id}

@app.get("/admin/eval")
def evaluation(db:Session=Depends(get_db)):
    # Eval set is the 10 posts with explicit expected subjects in seed data.
    posts=db.query(Post).all(); total=0; correct=0
    details=[]
    for p in posts:
        if not p.embedding: continue
        pv=json.loads(p.embedding)
        ranked=[]
        for im in db.query(Image).filter(Image.processed==True).all():
            sim=cosine(pv,json.loads(im.embedding))
            decision,reason=guard(p.title+" "+p.content,im,sim)
            if decision=="ACCEPTED": ranked.append((sim,im))
        ranked.sort(key=lambda x:x[0],reverse=True)
        expected=expected_subject(p.title)
        hit=bool(ranked and ranked[0][1].subject==expected)
        total+=1; correct+=int(hit)
        details.append({"post":p.title,"expected":expected,"top1":ranked[0][1].subject if ranked else None,"correct":hit})
    return {"top1_precision":round(correct/total,4) if total else 0,"correct":correct,"total":total,"details":details}

def expected_subject(title):
    t=title.lower()
    for s in ["fox","wolf","dog","bear","deer","eagle","parrot","owl","penguin","peacock"]:
        if s in t: return "red fox" if s=="fox" else s
    for s in ["rose","sunflower","cactus","pine","tulip","car","bicycle","train","airplane","boat"]:
        if s in t: return s
    return "unknown"

@app.get("/admin/costs")
def costs(db:Session=Depends(get_db)):
    rows=db.query(CostLog).all()
    return {"calls":len(rows),"estimated_usd":round(sum(r.estimated_usd for r in rows),6),
            "by_kind":{k:sum(1 for r in rows if r.kind==k) for k in set(r.kind for r in rows)}}
