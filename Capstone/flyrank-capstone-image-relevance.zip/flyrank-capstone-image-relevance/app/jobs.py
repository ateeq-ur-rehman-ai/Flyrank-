import asyncio, json
from app.ai import vision, embedding
from app.models import Image, Post, CostLog
from app.config import MAX_AI_CALLS_PER_RUN

async def _with_retry(fn, attempts=3):
    last=None
    for attempt in range(attempts):
        try:
            return await fn()
        except Exception as exc:
            last=exc
            if attempt < attempts-1:
                await asyncio.sleep(0.2*(2**attempt))
    raise last

async def process_images(db):
    images=db.query(Image).all()
    count=0
    for im in images:
        if count>=MAX_AI_CALLS_PER_RUN: break
        try:
            tag=await _with_retry(lambda: vision(im.filename))
            im.subject=tag.subject; im.category=tag.category
            im.attributes=json.dumps(tag.attributes); im.caption=tag.caption
            im.confidence=tag.confidence; im.flagged=tag.confidence < 0.70
            im.embedding=json.dumps(embedding(tag.caption))
            im.processed=True
            db.add(CostLog(kind="vision",provider="demo-local",units=1,estimated_usd=0,image_id=im.id))
            db.add(CostLog(kind="embedding",provider="demo-local",units=1,estimated_usd=0,image_id=im.id))
            count+=1
        except Exception as exc:
            im.flagged=True
            print(f"BATCH_FAILURE image={im.filename} error={exc}")
    for p in db.query(Post).all():
        p.embedding=json.dumps(embedding(p.title+" "+p.content))
    db.commit()
    return count
