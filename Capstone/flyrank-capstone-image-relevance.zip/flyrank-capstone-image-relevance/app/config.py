import os
from dotenv import load_dotenv
load_dotenv()
DATABASE_URL=os.getenv("DATABASE_URL","sqlite:///./local.db")
GEMINI_API_KEY=os.getenv("GEMINI_API_KEY","")
GEMINI_MODEL=os.getenv("GEMINI_MODEL","gemini-2.5-flash")
EMBEDDING_MODEL=os.getenv("EMBEDDING_MODEL","gemini-embedding-001")
SIMILARITY_THRESHOLD=float(os.getenv("SIMILARITY_THRESHOLD","0.35"))
CONFIDENCE_THRESHOLD=float(os.getenv("CONFIDENCE_THRESHOLD","0.70"))
MAX_AI_CALLS_PER_RUN=int(os.getenv("MAX_AI_CALLS_PER_RUN","100"))
DEMO_MODE=os.getenv("DEMO_MODE","true").lower()=="true"
