# Corpus attribution

The included 40 tiny SVGs are original synthetic demo assets generated for this repository, so no third-party image license is being asserted for them.

For a production-quality visual corpus, replace these assets with images whose licenses permit the intended use (for example, Unsplash or Pexels), and record the source URL/license/attribution here.
