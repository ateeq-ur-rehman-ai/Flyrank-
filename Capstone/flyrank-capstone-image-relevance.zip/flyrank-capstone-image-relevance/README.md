# FlyRank Capstone — AI Image Understanding & Content Matching Engine

A small, explainable backend that understands an image library, embeds image descriptions and blog posts, ranks candidates, and **refuses wrong matches**.

> Core demo: a red-fox article ranks a fox image first; a wolf candidate is rejected with a category-mismatch explanation.

## Requirements covered
- Structured vision output with Pydantic validation.
- Low-confidence images are flagged.
- Batch processing with an isolated job module and retry-ready provider boundary.
- Embeddings + cosine similarity ranking.
- Mismatch guard with threshold, confidence and subject rules.
- Human-readable rejection / “no confident match” behavior.
- PostgreSQL persistence with indexes and migrations.
- Review API.
- Labeled 20-post evaluation set and top-1 precision endpoint.
- Per-call AI cost log and budget guard.
- Layered architecture, environment-only secrets, documentation and evidence.

## $0 / reproducible mode
The default `DEMO_MODE=true` uses a deterministic local vision/embedding adapter so the repository runs without a credit card or API key. The adapter boundary is ready for a Gemini Flash implementation; production integration should replace the local provider without changing the HTTP or persistence layers.

The included 40-image corpus consists of tiny original SVG demo assets generated for this repository. They are deliberately lightweight and reproducible. For a production corpus, replace them with properly licensed Unsplash/Pexels assets and record attribution.

## Run
```bash
docker compose up --build
docker compose exec api python scripts/seed.py
docker compose exec api python scripts/batch.py
curl http://localhost:8000/health
curl -X POST http://localhost:8000/admin/batch/process
curl http://localhost:8000/posts/1/images
curl http://localhost:8000/admin/eval
curl http://localhost:8000/admin/costs
```

## Expected demo
For `GET /posts/1/images`, the first accepted suggestion is the red fox image. To force a wolf candidate, inspect the returned candidates: the wolf receives `REJECTED` and a reason like `Animal category mismatch: expected fox, detected wolf`.

If every candidate fails the guard, the application should communicate that there is **no confident match** rather than guessing.

## Tests
```bash
pytest -q
```

## Configuration
Copy `.env.example` to `.env`. Never commit `.env` or real API keys.

## Evaluation
The seeded dataset contains 20 labeled posts and 40 images. `GET /admin/eval` reports top-1 precision and the per-post result. The headline number should be copied into this README after running the exact seed + batch commands in the target environment.

## Limitations
The demo provider is deterministic rather than a cloud vision model. Real-world model quality depends on the selected vision model, prompts/schema, image quality and runtime. Confidence is a review signal, not a correctness guarantee. A stronger deployment would add automated regression evaluation, a real vector index, observability, durable job queues and authenticated admin endpoints.

## Required submission files
`README.md`, `capstone.yaml`, `EVIDENCE.md`, `BUILDLOG.md`, `.env.example`, `DESIGN.md`, migration SQL and tests are included.

## License
MIT.
