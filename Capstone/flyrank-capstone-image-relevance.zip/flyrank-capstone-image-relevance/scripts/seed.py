import os, sys
sys.path.append(os.path.dirname(os.path.dirname(__file__)))
from app.db import Base,engine,SessionLocal
from app.models import Image,Post
from app.ai import CATEGORIES
Base.metadata.create_all(bind=engine)
db=SessionLocal()
db.query(Image).delete(); db.query(Post).delete()
# 40 original, tiny SVG demo assets. They are intentionally generated locally so the demo is reproducible at $0.
subjects=list(CATEGORIES.keys())[:20]
for s in subjects:
    for i in range(2):
        db.add(Image(filename=f"{s}-{i+1}.svg"))
posts=[
("Red Fox Behavior","A field guide to the behavior and habitat of red foxes."),
("Wolf Ecology","How gray wolves behave in forest ecosystems."),
("Domestic Dogs","A guide to domestic dogs and canine companionship."),
("Brown Bear Habitat","Brown bears and their forest habitat."),
("Deer Antlers","Deer, antlers and woodland wildlife."),
("Eagle Raptors","Eagles are raptors with powerful wings."),
("Parrot Care","Colorful parrots and tropical birds."),
("Night Owl","Owls are nocturnal forest birds."),
("Penguin Life","Penguins live around icy Antarctic environments."),
("Peacock Feathers","Peacocks are known for colorful feathers."),
("Rose Garden","Roses are flowers commonly grown in gardens."),
("Sunflower Field","Sunflowers are yellow flowers found in fields."),
("Desert Cactus","Cacti are green plants adapted to deserts."),
("Pine Forest","Pine trees are evergreen forest plants."),
("Tulip Garden","Tulips are colorful garden flowers."),
("Road Cars","Cars are vehicles used on roads."),
("Bicycle Tour","Bicycles are human-powered road vehicles."),
("Railway Train","Trains travel along railway tracks."),
("Airplane Travel","Airplanes are aircraft used for air travel."),
("Boat Trip","Boats are vehicles that travel on water."),
]
for t,c in posts: db.add(Post(title=t,content=c))
db.commit()
print("Seeded 40 images across 20 subjects and 20 posts.")
