import asyncio, os, sys
sys.path.append(os.path.dirname(os.path.dirname(__file__)))
from app.db import SessionLocal
from app.jobs import process_images
db=SessionLocal()
try:
    print("Starting background image understanding batch...")
    n=asyncio.run(process_images(db))
    print(f"Completed batch: processed={n}")
finally:
    db.close()
