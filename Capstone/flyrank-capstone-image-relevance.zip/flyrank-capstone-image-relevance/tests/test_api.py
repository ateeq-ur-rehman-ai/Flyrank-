import os
os.environ["DATABASE_URL"]="sqlite:///./test_image_match.db"
os.environ["DEMO_MODE"]="true"
from fastapi.testclient import TestClient
from app.db import Base,engine,SessionLocal
from app.main import app
from scripts.seed import *  # noqa
Base.metadata.drop_all(bind=engine); Base.metadata.create_all(bind=engine)
db=SessionLocal()
db.query(Image).delete(); db.query(Post).delete()
for s in list(CATEGORIES.keys())[:20]:
    for i in range(2): db.add(Image(filename=f"{s}-{i+1}.svg"))
for t,c in posts: db.add(Post(title=t,content=c))
db.commit(); db.close()
client=TestClient(app)
def test_health(): assert client.get("/health").status_code==200
def test_batch_and_fox():
    assert client.post("/admin/batch/process").status_code==200
    r=client.get("/posts/1/images"); assert r.status_code==200
    assert r.json()["suggestions"][0]["decision"]=="ACCEPTED"
    assert "fox" in r.json()["suggestions"][0]["filename"]
def test_eval():
    r=client.get("/admin/eval"); assert r.status_code==200
