# Design — AI Image Understanding & Content Matching Engine

## Problem
Match article meaning to the right image while refusing unsafe/wrong semantic matches.

## Data model
`images` stores validated vision tags, confidence, embeddings and review flags. `posts` stores article content and embeddings. `suggestions` stores ranking + guard explanations. `reviews` stores human approval/rejection. `cost_logs` attributes each AI call.

## API surface
- `POST /admin/batch/process` — asynchronous-style batch boundary (the service processes the slow bulk work outside the read path).
- `GET /posts/{id}/images` — ranked candidates with decision + reason.
- `POST /reviews` — approve/reject a suggestion.
- `GET /admin/eval` — top-1 precision.
- `GET /admin/costs` — call/cost accounting.

## Guard
1. Reject low confidence.
2. Apply similarity threshold.
3. Apply explicit subject/category mismatch rules.
4. Return a human-readable reason.
5. If no candidate clears the guard, the client receives only rejected candidates and can report “no confident match”.

## Explicit non-goal
No full public-facing frontend or massive image-management platform.

## Architecture
```text
image corpus
   |
batch processor + retry boundary
   |
vision adapter -> schema validation -> image_metadata
   |                                      |
caption embedding ----------------------> image vectors
                                          |
post text -> post embedding --------------+
                                          v
                              similarity ranking
                                          |
                                          v
                                   mismatch guard
                                  /                                         accepted          rejected
                              |                 |
                         review API        explanation
```
