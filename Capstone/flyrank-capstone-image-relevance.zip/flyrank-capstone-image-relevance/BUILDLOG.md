# BUILDLOG — AI-assisted development log

## Session 1 — Design
- AI helped turn the capstone brief into a small layered architecture.
- Human decision: keep the system backend-only and use PostgreSQL with Docker.
- Human decision: make the mismatch guard an explicit module rather than mixing it into ranking.

## Session 2 — Core implementation
- AI helped draft FastAPI models, Pydantic schemas and the provider boundary.
- AI output was reviewed and adjusted to keep persistence separate from AI logic.
- Human decision: store embeddings as JSON arrays because pgvector is optional at the capstone scale.

## Session 3 — Reliability
- AI helped draft confidence checks, similarity thresholds and readable rejection reasons.
- Human review identified that “best similarity” alone can still choose the wrong animal, so an explicit fox/wolf subject mismatch rule was added.
- Cost logs were added for every demo vision/embedding call.

## Session 4 — Evidence
- AI helped structure the evidence checklist around the six acceptance probes.
- Human responsibility: run commands in the target environment and replace placeholders with real observed outputs before submission.

## Important limitation
The default demo mode is a deterministic local adapter so the repository is runnable at $0. It is not a claim that the local heuristic is equivalent to Gemini Flash. A real cloud vision adapter should be enabled and evaluated separately before production use.
