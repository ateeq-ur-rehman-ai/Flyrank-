# Evidence

Run these commands on the final machine and paste the actual output below each requirement. Do not claim evidence that was not observed.

## 1. Layered architecture
**Proof:** `DESIGN.md` architecture diagram + `app/ai.py`, `app/guard.py`, `app/jobs.py`, `app/main.py`.

## 2. Boundary validation
**Proof command:**
```bash
curl -i -X POST http://localhost:8000/reviews -H 'content-type: application/json' -d '{}'
```
Expected: HTTP 422, not 500.

## 3. Background batch + retries
**Proof command:**
```bash
docker compose exec api python scripts/batch.py
```
Expected: JSON showing 40 processed. Provider failures are isolated behind `app/ai.py`; production provider calls should add exponential retry at that boundary.

## 4. Real persistence + indexes
**Proof:** `migrations/001_initial.sql`; Docker PostgreSQL service in `docker-compose.yml`.

## 5. Idempotency where it matters
**Proof:** Review endpoint uses a unique `suggestion_id`; repeat review updates the same record rather than creating another review.

## 6. Secrets clean
**Proof:** `.env` is ignored; `.env.example` contains placeholders only; source code does not contain a real API key.

## 7. AI cost tracking
**Proof commands:**
```bash
curl http://localhost:8000/admin/costs
```
Expected: one zero-cost log entry per demo vision/embedding call.

## Acceptance probe 1 — schema-valid tags + low confidence
The seeded corpus is deterministic and high-confidence. To demonstrate the low-confidence path, add an `unknown-1.svg` filename and rerun the batch; it receives confidence `0.45` and `flagged=true`.

## Acceptance probe 2 — fox ranks first
```bash
curl http://localhost:8000/posts/1/images
```

## Acceptance probe 3 — wolf rejected for fox
The ranked response includes wolf candidates with `decision=REJECTED` and an explicit category mismatch reason.

## Acceptance probe 4 — no confident match
Create a post whose content is unrelated to the corpus and query it. All candidates below the threshold should be rejected with reasons.

## Acceptance probe 5 — evaluation
```bash
curl http://localhost:8000/admin/eval
```
Copy the actual `top1_precision` into the final README after the run.

## Acceptance probe 6 — cost log
```bash
curl http://localhost:8000/admin/costs
```
