# FlyRank Capstone — Social Media Studio

A backend-first social campaign publisher implementing the FlyRank **Multi-Platform Social Campaign Publisher** brief. The current portal note says the live version is Social Media Studio and the old fake-server brief remains valid if the missing server is replaced; this repo therefore includes a small local fake platform server so the core never touches real social accounts.

## What ships
- Blog post → Instagram 1080×1080 and X 1600×900 image variants.
- Shared + platform-specific caption fragments.
- `SocialPublisher` adapter contract + Fake Instagram/X adapters.
- Idempotency keys persisted in SQLite and sent to the platform.
- 429/Retry-After retry path.
- Durable scheduled posts stored in DB; worker resumes after restart.
- AES-GCM encrypted tokens with random IV; plaintext never stored/logged.
- HMAC-signed delivery webhook; forged events return 400.
- Automated tests for dimensions and exactly-once persistence.

## Run
```bash
python -m venv .venv
# activate it, then:
pip install -r requirements.txt
cp .env.example .env
python seed.py
uvicorn mock_platform.main:app --port 9000
# second terminal
uvicorn app.main:app --port 8000
```
Docker alternative: `docker compose up --build`.

Set a token (demo token accepted by mock):
```bash
curl -X POST http://localhost:8000/tokens -H 'content-type: application/json' -d '{"platform":"instagram","token":"mock-instagram-demo"}'
curl -X POST http://localhost:8000/tokens -H 'content-type: application/json' -d '{"platform":"x","token":"mock-x-demo"}'
```

Create a campaign using `media/source.jpg` and an ISO UTC `scheduled_at` in the future or now. Then call `/worker/run` to force the durable worker for a demo.

## Reliability demo
1. Create one campaign for both platforms.
2. Call `/worker/run` twice. The persistent idempotency key means the mock server receives one logical post per platform.
3. Restart the app; queued/scheduled rows remain in SQLite.
4. Send a webhook with a bad `X-Signature` → 400 and unchanged status.
5. Send a valid HMAC payload → status changes only after verification.

### Note on the brief's 429 probe
The mock server is intentionally tiny and deterministic. To exercise a 429, add a test/admin switch that returns `429` with `Retry-After`; the adapter already honors that header. This keeps the core free of any real platform dependency.

## Architecture
```text
Blog Post
  ├── Caption Composer (shared + platform fragments)
  └── Image Variant Pipeline (1080² / 1600×900)
                ↓
          Campaign + SocialPostEntry-like rows
                ↓ durable DB
             Worker
                ↓
       SocialPublisher interface
          ├── FakeInstagramPublisher
          └── FakeXPublisher
                ↓
        Local Fake Platform
                ↓ signed delivery event
      POST /webhook/social-delivery
                ↓ HMAC verification
        queued → publishing → published/failed
```

## Limitations
This is a $0 capstone implementation. The fake platform is included locally because the portal's old brief referenced a starter that was not shipped. Production hardening would move from SQLite to PostgreSQL, use a real queue (e.g. BullMQ/Redis), implement a dedicated OAuth callback flow, and use a proper job lease/visibility timeout. No real social credentials are required or used.
