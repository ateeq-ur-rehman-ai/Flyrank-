import os,tempfile,importlib
fd,path=tempfile.mkstemp(); os.close(fd); os.environ["APP_DB"]=path
import app.config as config; importlib.reload(config)
import app.db as db; importlib.reload(db)
def test_idempotency_unique():
    db.init_db()
    with db.conn() as c:
        c.execute("INSERT INTO publish_results VALUES('k','{}','now')")
        try: c.execute("INSERT INTO publish_results VALUES('k','{}','now')"); assert False
        except Exception: pass
def test_dimensions():
    from PIL import Image
    from app.services.content import make_variants
    src=tempfile.mktemp(suffix=".jpg"); Image.new("RGB",(1000,800)).save(src)
    out=make_variants(src); assert Image.open(out["instagram"]).size==(1080,1080); assert Image.open(out["x"]).size==(1600,900)
