import base64, hashlib, hmac, os
from cryptography.hazmat.primitives.ciphers.aead import AESGCM
from app.config import settings

def key_bytes(): return hashlib.sha256(settings.secret.encode()).digest()
def encrypt(value:str)->str:
    nonce=os.urandom(12); ct=AESGCM(key_bytes()).encrypt(nonce,value.encode(),None)
    return base64.b64encode(nonce+ct).decode()
def decrypt(value:str)->str:
    raw=base64.b64decode(value); return AESGCM(key_bytes()).decrypt(raw[:12],raw[12:],None).decode()
def sign(payload:bytes)->str: return hmac.new(settings.webhook_secret.encode(),payload,hashlib.sha256).hexdigest()
def verify(payload:bytes, signature:str)->bool: return hmac.compare_digest(sign(payload),signature)
