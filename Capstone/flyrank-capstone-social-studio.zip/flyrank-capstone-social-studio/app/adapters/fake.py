import httpx, time
from app.config import settings
class FakePublisher:
    def __init__(self,platform,token): self.platform=platform; self.token=token
    def publish(self,*,caption,image_path,idempotency_key):
        with open(image_path,'rb') as f:
            files={'image':('image.jpg',f,'image/jpeg')}; data={'platform':self.platform,'caption':caption}
            for attempt in range(4):
                r=httpx.post(f'{settings.mock_url}/v1/publish',headers={'Authorization':f'Bearer {self.token}','Idempotency-Key':idempotency_key},data=data,files=files,timeout=10)
                if r.status_code==429:
                    wait=int(r.headers.get('Retry-After','1')); time.sleep(min(wait,2)); f.seek(0); continue
                r.raise_for_status(); return r.json()
            raise RuntimeError('rate limit retries exhausted')
