from typing import Protocol
class SocialPublisher(Protocol):
    platform:str
    def publish(self, *, caption:str, image_path:str, idempotency_key:str)->dict: ...
