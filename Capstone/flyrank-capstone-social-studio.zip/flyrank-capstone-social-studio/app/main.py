import uuid, datetime as dt, threading, json
from fastapi import FastAPI, HTTPException, Header, Request
from app.db import init_db,conn
from app.schemas import CampaignIn,TokenIn
from app.security import encrypt,verify
from app.services.content import make_variants
from app.services.prompts import compose_caption
from app.worker import loop,run_once
app=FastAPI(title='FlyRank Social Media Studio')
stop=threading.Event()
@app.on_event('startup')
def startup(): init_db(); threading.Thread(target=loop,args=(stop,),daemon=True).start()
@app.on_event('shutdown')
def shutdown(): stop.set()
@app.get('/health')
def health(): return {'ok':True}
@app.post('/tokens')
def set_token(x:TokenIn):
    with conn() as c: c.execute("INSERT INTO platform_tokens(platform,ciphertext,updated_at) VALUES(?,?,?) ON CONFLICT(platform) DO UPDATE SET ciphertext=excluded.ciphertext,updated_at=excluded.updated_at",(x.platform,encrypt(x.token),dt.datetime.now(dt.timezone.utc).isoformat()))
    return {'stored':True,'platform':x.platform}
@app.post('/campaigns')
def create(x:CampaignIn):
    cid=str(uuid.uuid4()); created=dt.datetime.now(dt.timezone.utc).isoformat(); variants=make_variants(x.source_image)
    with conn() as c:
        c.execute("INSERT INTO campaigns VALUES(?,?,?,?,?,?)",(cid,x.title,x.body,str(x.url),x.source_image,created))
        for platform in x.platforms:
            pid=str(uuid.uuid4()); idem=f'{cid}:{platform}'; cap=compose_caption(platform,x.title,x.body,str(x.url))
            c.execute("INSERT INTO social_posts VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?)",(pid,cid,platform,cap,variants[platform],'queued',x.scheduled_at,idem,None,0,None,created,created))
    return {'campaign_id':cid,'posts':variants}
@app.get('/campaigns')
def campaigns():
    with conn() as c: return [dict(r) for r in c.execute('SELECT * FROM social_posts ORDER BY created_at DESC').fetchall()]
@app.post('/worker/run')
def worker(): run_once(); return {'ok':True}
@app.post('/webhook/social-delivery')
async def webhook(request:Request,x_signature:str=Header(default='')):
    body=await request.body()
    if not verify(body,x_signature): raise HTTPException(400,'invalid signature')
    event=json.loads(body); eid=event['event_id']
    with conn() as c:
        if c.execute('SELECT 1 FROM webhook_events WHERE event_id=?',(eid,)).fetchone(): return {'duplicate':True}
        c.execute('INSERT INTO webhook_events VALUES(?,?)',(eid,dt.datetime.now(dt.timezone.utc).isoformat()))
        status=event['status']; c.execute("UPDATE social_posts SET status=?,updated_at=?,last_error=? WHERE external_id=?",(status,dt.datetime.now(dt.timezone.utc).isoformat(),event.get('error'),event['post_id']))
    return {'accepted':True}
@app.get('/campaigns/{campaign_id}')
def campaign(campaign_id:str):
    with conn() as c:
        r=c.execute('SELECT * FROM campaigns WHERE id=?',(campaign_id,)).fetchone(); posts=c.execute('SELECT * FROM social_posts WHERE campaign_id=?',(campaign_id,)).fetchall()
    if not r: raise HTTPException(404,'not found')
    return {'campaign':dict(r),'posts':[dict(x) for x in posts]}
