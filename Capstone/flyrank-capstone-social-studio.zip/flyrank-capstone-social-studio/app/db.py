import sqlite3, os, threading
from app.config import settings
_lock=threading.Lock()
def conn():
    os.makedirs(os.path.dirname(settings.db) or '.', exist_ok=True)
    c=sqlite3.connect(settings.db, check_same_thread=False)
    c.row_factory=sqlite3.Row
    return c
def init_db():
    with _lock, conn() as c:
        c.executescript('''
        CREATE TABLE IF NOT EXISTS campaigns(id TEXT PRIMARY KEY,title TEXT NOT NULL,body TEXT NOT NULL,url TEXT NOT NULL,source_image TEXT NOT NULL,created_at TEXT NOT NULL);
        CREATE TABLE IF NOT EXISTS social_posts(id TEXT PRIMARY KEY,campaign_id TEXT NOT NULL,platform TEXT NOT NULL,caption TEXT NOT NULL,image_path TEXT NOT NULL,status TEXT NOT NULL,scheduled_at TEXT NOT NULL,idempotency_key TEXT NOT NULL UNIQUE,external_id TEXT,attempts INTEGER NOT NULL DEFAULT 0,last_error TEXT,created_at TEXT NOT NULL,updated_at TEXT NOT NULL,FOREIGN KEY(campaign_id) REFERENCES campaigns(id));
        CREATE INDEX IF NOT EXISTS idx_posts_due ON social_posts(status,scheduled_at);
        CREATE INDEX IF NOT EXISTS idx_posts_campaign ON social_posts(campaign_id);
        CREATE TABLE IF NOT EXISTS platform_tokens(platform TEXT PRIMARY KEY,ciphertext TEXT NOT NULL,updated_at TEXT NOT NULL);
        CREATE TABLE IF NOT EXISTS webhook_events(event_id TEXT PRIMARY KEY,received_at TEXT NOT NULL);
        CREATE TABLE IF NOT EXISTS publish_results(idempotency_key TEXT PRIMARY KEY,response_json TEXT NOT NULL,created_at TEXT NOT NULL);
        CREATE TABLE IF NOT EXISTS worker_jobs(id TEXT PRIMARY KEY,post_id TEXT NOT NULL,status TEXT NOT NULL,attempts INTEGER NOT NULL DEFAULT 0,next_run_at TEXT NOT NULL,last_error TEXT);
        ''')
