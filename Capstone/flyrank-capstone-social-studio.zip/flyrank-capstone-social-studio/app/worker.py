import threading,time,datetime as dt,uuid
from app.db import conn
from app.adapters.fake import FakePublisher
from app.security import decrypt
from app.config import settings

def now(): return dt.datetime.now(dt.timezone.utc).isoformat()
def run_once():
    with conn() as c:
        rows=c.execute("SELECT * FROM social_posts WHERE status IN ('queued','failed') AND scheduled_at<=? AND attempts<5 ORDER BY scheduled_at",(now(),)).fetchall()
    for p in rows:
        try:
            with conn() as c:
                c.execute("UPDATE social_posts SET status='publishing',attempts=attempts+1,updated_at=? WHERE id=? AND status IN ('queued','failed')",(now(),p['id']))
                tok=c.execute("SELECT ciphertext FROM platform_tokens WHERE platform=?",(p['platform'],)).fetchone()
            if not tok: raise RuntimeError('No encrypted token configured')
            result=FakePublisher(p['platform'],decrypt(tok['ciphertext'])).publish(caption=p['caption'],image_path=p['image_path'],idempotency_key=p['idempotency_key'])
            with conn() as c: c.execute("UPDATE social_posts SET external_id=?,updated_at=? WHERE id=?",(result['id'],now(),p['id']))
        except Exception as e:
            with conn() as c: c.execute("UPDATE social_posts SET status='failed',last_error=?,updated_at=? WHERE id=?",(str(e)[:500],now(),p['id']))
def loop(stop):
    while not stop.is_set(): run_once(); stop.wait(settings.worker_interval)
