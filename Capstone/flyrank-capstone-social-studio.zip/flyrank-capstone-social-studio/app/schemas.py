from pydantic import BaseModel, Field, HttpUrl
from typing import Literal
class CampaignIn(BaseModel):
    title:str=Field(min_length=1,max_length=200); body:str=Field(min_length=1,max_length=10000); url:HttpUrl; source_image:str
    scheduled_at:str
    platforms:list[Literal['instagram','x']]=Field(min_length=1)
class TokenIn(BaseModel): platform:Literal['instagram','x']; token:str=Field(min_length=1)
class PublishIn(BaseModel): post_id:str
