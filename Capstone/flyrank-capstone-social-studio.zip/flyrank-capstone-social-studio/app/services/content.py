from PIL import Image, ImageOps, ImageDraw
from pathlib import Path
import uuid
from app.services.prompts import compose_caption
OUT=Path('media/generated'); OUT.mkdir(parents=True,exist_ok=True)
SPECS={'instagram':(1080,1080),'x':(1600,900)}
def make_variants(source:str):
    img=Image.open(source).convert('RGB')
    result={}
    for platform,size in SPECS.items():
        out=ImageOps.fit(img,size,method=Image.Resampling.LANCZOS,centering=(.5,.5))
        # subtle safe-zone marker-free branding area; actual subject remains centered by fit()
        path=OUT/f'{uuid.uuid4().hex}_{platform}.jpg'; out.save(path,quality=90)
        result[platform]=str(path)
    return result
