SHARED='Brand voice: concise, useful, credible, human. Content summary: {title} — {body}. Link: {url}'
PLATFORM={'instagram':'Instagram rules: conversational, 1–3 short paragraphs, invite discussion, optional hashtags.','x':'X rules: concise, punchy, front-load the value, fit comfortably in one post.'}
def compose_caption(platform,title,body,url):
    return f"{SHARED.format(title=title,body=body,url=url)}\n{PLATFORM[platform]}\n\n{title} — {url}"
