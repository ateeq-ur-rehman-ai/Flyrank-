import os
from dataclasses import dataclass
@dataclass(frozen=True)
class Settings:
    db: str = os.getenv("APP_DB", "./social_studio.db")
    secret: str = os.getenv("APP_SECRET", "change-me-to-a-32-byte-secret")
    mock_url: str = os.getenv("MOCK_PLATFORM_URL", "http://localhost:9000")
    webhook_secret: str = os.getenv("WEBHOOK_SECRET", "change-me-webhook-secret")
    webhook_url: str = os.getenv("APP_WEBHOOK_URL", "http://localhost:8000/webhook/social-delivery")
    worker_interval: float = float(os.getenv("WORKER_INTERVAL_SECONDS", "2"))
settings=Settings()
