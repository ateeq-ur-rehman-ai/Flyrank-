from fastapi import FastAPI,Header,UploadFile,File,Form,HTTPException,Response
import os, httpx, time
from app.security import sign
import uuid, json
app=FastAPI(title='FlyRank Fake Social Platform')
FAIL_429=False
posts={}; idem={}; rate={}
@app.post('/oauth/token')
def token(platform:str): return {'access_token':f'mock-{platform}-token','token_type':'bearer'}
@app.post('/v1/publish')
def publish(platform:str=Form(...),caption:str=Form(...),image:UploadFile=File(...),authorization:str=Header(default=''),idempotency_key:str=Header(default='')):
    global FAIL_429
    if FAIL_429:
        FAIL_429=False
        return Response('rate limited',status_code=429,headers={'Retry-After':'1'})
    if not authorization.startswith('Bearer mock-'): raise HTTPException(401,'bad token')
    if not idempotency_key: raise HTTPException(400,'Idempotency-Key required')
    if idempotency_key in idem: return idem[idempotency_key]
    # deterministic test switch: header may be used by tests to force 429
    pid=str(uuid.uuid4()); out={'id':pid,'platform':platform,'status':'accepted'}; idem[idempotency_key]=out; posts[pid]=out
    payload=json.dumps({'event_id':str(uuid.uuid4()),'post_id':pid,'status':'published'}).encode(); sig=sign(payload)
    try:
        httpx.post(os.getenv('APP_WEBHOOK_URL','http://localhost:8000/webhook/social-delivery'),content=payload,headers={'X-Signature':sig},timeout=5)
    except Exception: pass
    return Response(payload,media_type='application/json',headers={'X-Delivery-Signature':sig,'X-Delivery-Status':'published'})
@app.post('/admin/rate-limit-once')
def rate_limit_once():
    global FAIL_429; FAIL_429=True; return {'next_publish':'429 Retry-After: 1'}
@app.post('/admin/reset')
def reset(): posts.clear(); idem.clear(); return {'ok':True}
