from PIL import Image,ImageDraw
from pathlib import Path
p=Path('media/source.jpg'); p.parent.mkdir(exist_ok=True)
im=Image.new('RGB',(1600,1000),'white'); d=ImageDraw.Draw(im); d.text((120,420),'FlyRank Social Studio Demo',fill='black'); im.save(p)
print(p)
