# Design

## Explicit non-goal
No real Instagram/X publishing in the core build. The system is evaluated against a local fake platform.

## Data model
- campaigns: source content and schedule parent.
- social_posts: one row per campaign/platform, status, idempotency key, external ID, attempts.
- platform_tokens: encrypted credentials.
- webhook_events: replay/deduplication store.
- publish_results: exactly-once persistence demonstration.

## Trust boundary
Only HMAC-verified delivery webhooks can change a post to `published`/`failed`.
