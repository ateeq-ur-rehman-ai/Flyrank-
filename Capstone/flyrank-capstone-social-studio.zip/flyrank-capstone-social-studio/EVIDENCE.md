# Evidence

> Replace/augment these with your own terminal captures before submission. Do not claim a probe you did not run.

| Definition-of-Done item | Proof to capture |
|---|---|
| Image dimensions | `pytest -q` output + inspect generated files with Pillow |
| Distinct captions | `GET /campaigns/{id}` showing different platform captions |
| Adapter layer | `app/adapters/base.py` + `app/adapters/fake.py` |
| Idempotency | two worker runs + one external ID per post |
| 429 handling | mock configured to return 429 + `Retry-After`, then successful retry |
| Durable scheduling | schedule future post, restart app, run worker, observe completion |
| Encrypted tokens | inspect `platform_tokens.ciphertext`; no plaintext token |
| Forged webhook | bad `X-Signature` returns 400 |
| Valid webhook | valid HMAC changes status |
| Automated tests | `pytest -q` |
