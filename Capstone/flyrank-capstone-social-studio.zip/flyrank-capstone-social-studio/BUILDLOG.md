# BUILDLOG

This project was AI-assisted. The implementation was reviewed and adjusted by the author.

- Phase 1: translated the brief into campaign/post/token/webhook tables and adapter boundaries.
- Phase 2: implemented Pillow image variants and composable caption fragments.
- Phase 3: implemented fake-platform adapters, persistent idempotency keys, retry handling, and AES-GCM token storage.
- Phase 4: implemented a DB-backed worker and HMAC webhook verification.
- AI assistance was used for scaffolding and test/documentation drafting; the author must verify every acceptance probe and replace placeholder evidence with real output before submission.
