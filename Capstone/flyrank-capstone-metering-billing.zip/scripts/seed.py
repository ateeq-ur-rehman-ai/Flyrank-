from app.main import init_db
init_db(); print('Seed complete: tenant=demo, Free=1000 API calls/100k AI tokens, Pro=10k/1M')
