# Design

## Problem
Provide a small SaaS billing backend that meters API calls and AI tokens exactly once, enforces monthly quotas, calculates integer-based money, and mirrors Stripe test-mode subscription state through verified/deduplicated webhooks.

## Data model
`tenants -> subscriptions`, `tenants -> usage_events`, and `plans -> tenants`. Usage events carry an idempotency key with a unique tenant/key constraint.

## API
- `POST /generate` — dummy billable action; requires `Idempotency-Key`.
- `GET /usage/{tenant_id}` — monthly usage, limits and cost.
- `POST /checkout` — Stripe test Checkout adapter.
- `POST /webhooks/stripe` — signed, idempotent subscription sync.
- `POST /jobs/reconcile` — background reconciliation placeholder.

## Money
All calculations use integer microcents. Fresh input tokens, cached input tokens and output+reasoning tokens are priced separately; cached input is a subset of input, not additive.

## Non-goal
No invoicing, proration, or overage billing in core scope.
