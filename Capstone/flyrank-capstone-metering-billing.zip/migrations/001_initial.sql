CREATE TABLE plans (id TEXT PRIMARY KEY, api_calls INTEGER NOT NULL, ai_tokens INTEGER NOT NULL);
CREATE TABLE tenants (id TEXT PRIMARY KEY, plan_id TEXT NOT NULL REFERENCES plans(id), status TEXT NOT NULL);
CREATE TABLE subscriptions (id TEXT PRIMARY KEY, tenant_id TEXT NOT NULL REFERENCES tenants(id), stripe_subscription_id TEXT UNIQUE, status TEXT NOT NULL);
CREATE TABLE usage_events (id INTEGER PRIMARY KEY AUTOINCREMENT, tenant_id TEXT NOT NULL REFERENCES tenants(id), api_calls INTEGER NOT NULL, ai_tokens INTEGER NOT NULL, input_tokens INTEGER NOT NULL, cached_input_tokens INTEGER NOT NULL, output_tokens INTEGER NOT NULL, reasoning_tokens INTEGER NOT NULL, idempotency_key TEXT NOT NULL, created_at TEXT NOT NULL, UNIQUE(tenant_id,idempotency_key));
CREATE TABLE webhook_events (id TEXT PRIMARY KEY, event_type TEXT NOT NULL, processed_at TEXT NOT NULL);
CREATE INDEX usage_events_tenant_time_idx ON usage_events(tenant_id,created_at);
