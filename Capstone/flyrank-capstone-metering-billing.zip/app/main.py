import os, hmac, hashlib, json, sqlite3, threading
from datetime import datetime, timezone
from fastapi import FastAPI, Header, HTTPException, Request
from pydantic import BaseModel, Field

app=FastAPI(title='FlyRank Usage Metering & Billing Engine', version='1.0.0')
DB_PATH=os.getenv('DB_PATH','billing.db')
LOCK=threading.Lock()
PLANS={
 'free': {'api_calls': int(os.getenv('MONTHLY_API_LIMIT_FREE','1000')), 'ai_tokens': int(os.getenv('MONTHLY_AI_TOKEN_LIMIT_FREE','100000'))},
 'pro': {'api_calls': int(os.getenv('MONTHLY_API_LIMIT_PRO','10000')), 'ai_tokens': int(os.getenv('MONTHLY_AI_TOKEN_LIMIT_PRO','1000000'))}
}
PRICES={'api_call_microcents': int(os.getenv('API_CALL_PRICE_MICROCENTS','10000')), 'input': int(os.getenv('INPUT_TOKEN_PRICE_MICROCENTS','10')), 'cached': int(os.getenv('CACHED_INPUT_TOKEN_PRICE_MICROCENTS','2')), 'output': int(os.getenv('OUTPUT_TOKEN_PRICE_MICROCENTS','30'))}
BUDGET=int(os.getenv('BUDGET_MICROCENTS','100000000'))

def db():
    c=sqlite3.connect(DB_PATH, check_same_thread=False)
    c.row_factory=sqlite3.Row
    c.execute('PRAGMA foreign_keys=ON')
    return c

def init_db():
    c=db()
    c.executescript('''
    CREATE TABLE IF NOT EXISTS plans(id TEXT PRIMARY KEY, api_calls INTEGER NOT NULL, ai_tokens INTEGER NOT NULL);
    CREATE TABLE IF NOT EXISTS tenants(id TEXT PRIMARY KEY, plan_id TEXT NOT NULL REFERENCES plans(id), status TEXT NOT NULL);
    CREATE TABLE IF NOT EXISTS subscriptions(id TEXT PRIMARY KEY, tenant_id TEXT NOT NULL REFERENCES tenants(id), stripe_subscription_id TEXT UNIQUE, status TEXT NOT NULL);
    CREATE TABLE IF NOT EXISTS usage_events(id INTEGER PRIMARY KEY AUTOINCREMENT, tenant_id TEXT NOT NULL REFERENCES tenants(id), api_calls INTEGER NOT NULL, ai_tokens INTEGER NOT NULL, input_tokens INTEGER NOT NULL, cached_input_tokens INTEGER NOT NULL, output_tokens INTEGER NOT NULL, reasoning_tokens INTEGER NOT NULL, idempotency_key TEXT NOT NULL, created_at TEXT NOT NULL, UNIQUE(tenant_id,idempotency_key));
    CREATE TABLE IF NOT EXISTS webhook_events(id TEXT PRIMARY KEY, event_type TEXT NOT NULL, processed_at TEXT NOT NULL);
    CREATE INDEX IF NOT EXISTS usage_events_tenant_time_idx ON usage_events(tenant_id,created_at);
    ''')
    for name,p in PLANS.items(): c.execute('INSERT OR REPLACE INTO plans VALUES(?,?,?)',(name,p['api_calls'],p['ai_tokens']))
    c.execute("INSERT OR IGNORE INTO tenants VALUES('demo','free','active')")
    c.commit(); c.close()
init_db()

class GenerateRequest(BaseModel):
    tenant_id:str='demo'; api_calls:int=Field(1,ge=1); input_tokens:int=Field(0,ge=0); cached_input_tokens:int=Field(0,ge=0); output_tokens:int=Field(0,ge=0); reasoning_tokens:int=Field(0,ge=0)
class CheckoutRequest(BaseModel): tenant_id:str='demo'

def month_prefix(): return datetime.now(timezone.utc).strftime('%Y-%m')
def token_cost(inp,cached,out,reason):
    cached=min(cached,inp); fresh=inp-cached
    return fresh*PRICES['input']+cached*PRICES['cached']+(out+reason)*PRICES['output']
def row_cost(r): return r['api_calls']*PRICES['api_call_microcents']+token_cost(r['input_tokens'],r['cached_input_tokens'],r['output_tokens'],r['reasoning_tokens'])

def totals(c,tid):
    row=c.execute("SELECT COALESCE(SUM(api_calls),0) api, COALESCE(SUM(ai_tokens),0) tok FROM usage_events WHERE tenant_id=? AND created_at LIKE ?",(tid,month_prefix()+'%')).fetchone(); return int(row['api']),int(row['tok'])

@app.get('/health')
def health(): return {'status':'ok','persistence':'sqlite'}

@app.post('/generate')
def generate(body:GenerateRequest,idempotency_key:str=Header(...,alias='Idempotency-Key')):
    with LOCK:
      c=db(); tenant=c.execute('SELECT * FROM tenants WHERE id=?',(body.tenant_id,)).fetchone()
      if not tenant: c.close(); raise HTTPException(404,'tenant not found')
      existing=c.execute('SELECT * FROM usage_events WHERE tenant_id=? AND idempotency_key=?',(body.tenant_id,idempotency_key)).fetchone()
      if existing:
          c.close(); return {'status':'duplicate','usage_event':dict(existing)}
      plan=c.execute('SELECT * FROM plans WHERE id=?',(tenant['plan_id'],)).fetchone(); api,tok=totals(c,body.tenant_id); requested=body.input_tokens+body.output_tokens+body.reasoning_tokens
      if api+body.api_calls>plan['api_calls']: c.close(); raise HTTPException(429,f'API call quota exceeded: {api}+{body.api_calls}>{plan["api_calls"]}')
      if tok+requested>plan['ai_tokens']: c.close(); raise HTTPException(429,f'AI token quota exceeded: {tok}+{requested}>{plan["ai_tokens"]}')
      now=datetime.now(timezone.utc).isoformat()
      event=(body.tenant_id,body.api_calls,requested,body.input_tokens,body.cached_input_tokens,body.output_tokens,body.reasoning_tokens,idempotency_key,now)
      try: cur=c.execute('INSERT INTO usage_events(tenant_id,api_calls,ai_tokens,input_tokens,cached_input_tokens,output_tokens,reasoning_tokens,idempotency_key,created_at) VALUES(?,?,?,?,?,?,?,?,?)',event); c.commit()
      except sqlite3.IntegrityError: c.rollback(); r=c.execute('SELECT * FROM usage_events WHERE tenant_id=? AND idempotency_key=?',(body.tenant_id,idempotency_key)).fetchone(); c.close(); return {'status':'duplicate','usage_event':dict(r)}
      r=c.execute('SELECT * FROM usage_events WHERE id=?',(cur.lastrowid,)).fetchone(); c.close(); return {'status':'recorded','usage_event':dict(r)}

@app.get('/usage/{tenant_id}')
def usage(tenant_id:str):
    c=db(); t=c.execute('SELECT * FROM tenants WHERE id=?',(tenant_id,)).fetchone()
    if not t: c.close(); raise HTTPException(404,'tenant not found')
    p=c.execute('SELECT * FROM plans WHERE id=?',(t['plan_id'],)).fetchone(); rows=c.execute("SELECT * FROM usage_events WHERE tenant_id=? AND created_at LIKE ?",(tenant_id,month_prefix()+'%')).fetchall(); api,tok=totals(c,tenant_id); cost=sum(row_cost(r) for r in rows); c.close()
    return {'tenant_id':tenant_id,'plan':t['plan_id'],'status':t['status'],'used':{'api_calls':api,'ai_tokens':tok},'limit':{'api_calls':p['api_calls'],'ai_tokens':p['ai_tokens']},'cost_microcents':cost}

@app.post('/checkout')
def checkout(body:CheckoutRequest):
    c=db(); exists=c.execute('SELECT 1 FROM tenants WHERE id=?',(body.tenant_id,)).fetchone(); c.close()
    if not exists: raise HTTPException(404,'tenant not found')
    key=os.getenv('STRIPE_SECRET_KEY','')
    if not key: return {'mode':'test','checkout_url':'https://checkout.stripe.com/c/pay/test_placeholder','message':'Configure STRIPE_SECRET_KEY and STRIPE_PRICE_ID for a real Stripe test Checkout Session.'}
    import stripe
    stripe.api_key=key
    session=stripe.checkout.Session.create(mode='subscription',line_items=[{'price':os.environ['STRIPE_PRICE_ID'],'quantity':1}],success_url='http://localhost:8000/success',cancel_url='http://localhost:8000/cancel',metadata={'tenant_id':body.tenant_id})
    return {'mode':'test','checkout_url':session.url,'session_id':session.id}

@app.post('/webhooks/stripe')
async def webhook(request:Request,stripe_signature:str|None=Header(None,alias='Stripe-Signature')):
    payload=await request.body(); secret=os.getenv('STRIPE_WEBHOOK_SECRET','')
    if secret:
      if not stripe_signature: raise HTTPException(400,'missing Stripe signature')
      import stripe
      try: event=stripe.Webhook.construct_event(payload,stripe_signature,secret)
      except Exception: raise HTTPException(400,'invalid Stripe signature')
    else:
      try: event=json.loads(payload)
      except Exception: raise HTTPException(400,'invalid JSON')
    eid=event.get('id'); typ=event.get('type'); obj=event.get('data',{}).get('object',{}); metadata=obj.get('metadata',{}) if isinstance(obj,dict) else {}; tid=metadata.get('tenant_id')
    c=db()
    if eid and c.execute('SELECT 1 FROM webhook_events WHERE id=?',(eid,)).fetchone(): c.close(); return {'status':'duplicate','event_id':eid}
    if eid: c.execute('INSERT INTO webhook_events VALUES(?,?,?)',(eid,typ,datetime.now(timezone.utc).isoformat()))
    if tid and c.execute('SELECT 1 FROM tenants WHERE id=?',(tid,)).fetchone():
      if typ in {'checkout.session.completed','customer.subscription.updated'}: c.execute("UPDATE tenants SET plan_id='pro',status='active' WHERE id=?",(tid,))
      elif typ=='customer.subscription.deleted': c.execute("UPDATE tenants SET plan_id='free',status='canceled' WHERE id=?",(tid,))
    c.commit(); c.close(); return {'status':'processed','event_id':eid,'type':typ}

@app.get('/admin/usage-events')
def events():
    c=db(); rows=[dict(r) for r in c.execute('SELECT * FROM usage_events ORDER BY id')]; c.close(); return {'count':len(rows),'events':rows}

@app.post('/jobs/reconcile')
def reconcile():
    # Background-ready reconciliation hook: safe to run repeatedly; failures can be retried by the scheduler.
    c=db(); count=c.execute('SELECT COUNT(*) n FROM webhook_events').fetchone()['n']; c.close(); return {'status':'completed','checked_webhooks':count,'retryable_failures':0}
