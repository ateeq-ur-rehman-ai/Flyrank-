# FlyRank Capstone — Usage Metering & Billing Engine

A correctness-first SaaS billing backend implementing idempotent usage metering, monthly quotas, integer money math, Stripe test-mode subscription synchronization, and evidence-friendly APIs.

## Architecture
```text
Client -> POST /generate -> validation -> idempotency -> quota -> cost/budget -> usage_events
                                      |
                                      +-> GET /usage -> monthly rollup
Stripe Checkout -> signed webhook -> verify -> deduplicate -> tenant plan/status
Background reconciliation job -> retry/check webhook state
```

## Plans
| Plan | API calls/month | AI tokens/month |
|---|---:|---:|
| Free | 1,000 | 100,000 |
| Pro | 10,000 | 1,000,000 |

## Run
```bash
cp .env.example .env
docker compose up --build
docker compose exec api python scripts/seed.py
```
API: `http://localhost:8000`

## Test
```bash
pytest -q
```

## Demo
```bash
curl -X POST http://localhost:8000/generate -H 'Content-Type: application/json' -H 'Idempotency-Key: demo-1' -d '{"tenant_id":"demo","api_calls":1,"input_tokens":100,"cached_input_tokens":20,"output_tokens":50,"reasoning_tokens":10}'
curl -X POST http://localhost:8000/generate -H 'Content-Type: application/json' -H 'Idempotency-Key: demo-1' -d '{"tenant_id":"demo","api_calls":1}'
curl http://localhost:8000/usage/demo
```

## Stripe test mode
Set `STRIPE_SECRET_KEY`, `STRIPE_PRICE_ID`, and `STRIPE_WEBHOOK_SECRET` in `.env`. Use Stripe CLI locally with `stripe listen --forward-to localhost:8000/webhooks/stripe` and `stripe trigger checkout.session.completed`. Never use live mode or commit secrets.

## Limitations
The included Checkout endpoint is a safe local adapter when Stripe credentials are absent. For a live Stripe test-mode run, configure the test credentials and wire a real Checkout Session creation using the Stripe SDK. The database migration is included; the compact demo state uses in-memory metering so acceptance behavior is runnable without external setup. Production deployment should move MeterService persistence into PostgreSQL transactions and use Stripe's official signature verification against the raw body.
