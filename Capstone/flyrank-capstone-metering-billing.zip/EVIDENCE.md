# Evidence

> Replace/append these with real terminal transcripts from your environment before submission. Claims without evidence do not count.

## 1. Exactly-once metering
```text
First POST with Idempotency-Key demo-1 -> 200 recorded
Second identical POST -> 200 duplicate
GET /admin/usage-events -> count=1
```

## 2. Quota boundary
```text
1000 API calls accepted for Free plan
next call -> HTTP 429
message: API call quota exceeded
```

## 3. Cost math
```text
api=1, fresh input=80, cached input=20, output=50, reasoning=10
expected microcents = 10000 + 800 + 40 + 1800 = 12640
```

## 4. Stripe
```text
Webhook with invalid signature -> HTTP 400 when STRIPE_WEBHOOK_SECRET is configured
Replay same event id -> status=duplicate
checkout.session.completed -> tenant plan becomes pro
```

## 5. Persistence / migration
```text
migrations/001_initial.sql defines plans, tenants, subscriptions, usage_events and tenant/time indexes.
```

## 6. Shared engineering requirements
- Layered concerns: API functions, billing helpers and persistence migration are separated.
- Boundary validation: Pydantic rejects malformed quantities with 422.
- Background job: `/jobs/reconcile` is the reconciliation hook; production deployment should run it asynchronously on a scheduler.
- Real persistence: PostgreSQL migration included.
- Idempotency: tenant + idempotency key is unique in the schema and deduplication is demonstrated by API behavior.
- Secrets: environment variables only; `.env` ignored.
