import os,tempfile
fd,path=tempfile.mkstemp(); os.close(fd); os.environ['DB_PATH']=path
from fastapi.testclient import TestClient
from app.main import app
c=TestClient(app)

def setup_function():
    import sqlite3
    x=sqlite3.connect(path); x.execute('DELETE FROM usage_events'); x.execute('DELETE FROM webhook_events'); x.execute("UPDATE tenants SET plan_id='free',status='active' WHERE id='demo'"); x.commit(); x.close()

def test_idempotency():
 p={'tenant_id':'demo','api_calls':1,'output_tokens':100}; a=c.post('/generate',json=p,headers={'Idempotency-Key':'abc'}); b=c.post('/generate',json=p,headers={'Idempotency-Key':'abc'}); assert a.status_code==200 and b.json()['status']=='duplicate'
def test_quota_boundary():
 assert c.post('/generate',json={'tenant_id':'demo','api_calls':1000},headers={'Idempotency-Key':'full'}).status_code==200
 assert c.post('/generate',json={'tenant_id':'demo','api_calls':1},headers={'Idempotency-Key':'over'}).status_code==429
def test_pricing_rules():
 c.post('/generate',json={'tenant_id':'demo','api_calls':1,'input_tokens':100,'cached_input_tokens':20,'output_tokens':50,'reasoning_tokens':10},headers={'Idempotency-Key':'cost'})
 assert c.get('/usage/demo').json()['cost_microcents']==12640
