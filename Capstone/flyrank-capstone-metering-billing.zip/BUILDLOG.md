# BUILDLOG

## AI assistance
AI was used as a coding collaborator for scaffolding FastAPI routes, schema design, test cases, README wording and edge-case review.

## Human review / corrections
- Ensured cached input tokens are treated as a subset of total input, not double-counted.
- Reasoning tokens are priced as output tokens.
- Money is represented as integer microcents, never floating point.
- Idempotency is keyed by tenant + request key.
- Stripe secrets are environment-only.
- The demo keeps a local adapter path so the project can be exercised without a payment account; Stripe test-mode integration is documented separately.

## Known gap
The compact submission keeps the executable demo metering state in memory while providing the required PostgreSQL migration. Before claiming full production readiness, move the MeterService writes/rollups to transactional PostgreSQL persistence and replace the local Checkout adapter with the Stripe SDK Checkout Session call.
