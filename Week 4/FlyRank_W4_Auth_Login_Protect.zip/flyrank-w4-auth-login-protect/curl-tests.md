# Quick Test Sheet

Replace `PASTE_ACCESS_TOKEN` with the JWT returned by `/auth/login`.

1. `GET /public/info` → 200
2. `GET /protected/profile` without token → 401
3. `POST /auth/signup` with email/password → 201
4. `POST /auth/login` with correct credentials → 200 + access_token
5. `GET /protected/profile` with valid token → 200
6. `GET /protected/profile` with modified token → 401
7. `GET /protected/dashboard` with valid token → 200
8. `POST /auth/logout` with valid token → 204
