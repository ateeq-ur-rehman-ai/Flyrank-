# FlyRank Week 4 — Auth · Login & Protect

A secure Express API using Supabase Auth. It supports sign up, login, logout, JWT bearer-token verification, reusable authentication middleware, protected routes, and Swagger UI.

## Stack

- Node.js
- Express
- Supabase Auth
- `@supabase/supabase-js`
- Swagger UI
- Git / GitHub

## 1. Setup

Install Node.js, then install dependencies:

```bash
npm install
```

Create a Supabase project and get the Project URL and anon key from Project Settings → API.

Copy `.env.example` to `.env` and fill in:

```env
SUPABASE_URL=your_project_url
SUPABASE_KEY=your_anon_key
PORT=3000
```

For this practice assignment, disable email confirmation in Supabase under Authentication → Sign In / Providers → Email so a new account can log in immediately.

**Never put a `service_role` key in this project and never commit `.env`.**

## 2. Run

```bash
npm start
```

Server:

`http://localhost:3000`

Swagger:

`http://localhost:3000/docs`

## 3. API Reference

| Method | Endpoint | Auth | Purpose |
|---|---|---|---|
| POST | `/auth/signup` | No | Create user |
| POST | `/auth/login` | No | Login and return access/refresh tokens |
| POST | `/auth/logout` | Yes | Accept logout request from authenticated user |
| GET | `/protected/profile` | Yes | Return authenticated user's safe profile |
| GET | `/protected/dashboard` | Yes | Example second protected route |
| GET | `/public/info` | No | Public information |

Protected routes require:

```text
Authorization: Bearer <access_token>
```

## 4. Test with curl

### Public route

```bash
curl -i http://localhost:3000/public/info
```

Expected: `200`

### Protected route without token

```bash
curl -i http://localhost:3000/protected/profile
```

Expected: `401`

### Sign up

```bash
curl -i -X POST http://localhost:3000/auth/signup \
  -H "Content-Type: application/json" \
  -d '{"email":"test@example.com","password":"password123"}'
```

Expected: `201`

### Login

```bash
curl -i -X POST http://localhost:3000/auth/login \
  -H "Content-Type: application/json" \
  -d '{"email":"test@example.com","password":"password123"}'
```

Copy the returned `access_token`.

### Protected profile

```bash
curl -i http://localhost:3000/protected/profile \
  -H "Authorization: Bearer PASTE_ACCESS_TOKEN_HERE"
```

Expected: `200`

Changing one character in the token should produce `401`.

### Protected dashboard

```bash
curl -i http://localhost:3000/protected/dashboard \
  -H "Authorization: Bearer PASTE_ACCESS_TOKEN_HERE"
```

Expected: `200`

### Logout

```bash
curl -i -X POST http://localhost:3000/auth/logout \
  -H "Authorization: Bearer PASTE_ACCESS_TOKEN_HERE"
```

Expected: `204`

## 5. Swagger

Open:

`http://localhost:3000/docs`

Use **Authorize**, paste the JWT, then use **Try it out** on `/protected/profile` and `/protected/dashboard`.

The protected routes are configured with an OpenAPI HTTP bearer security scheme, so Swagger displays the lock icon.

## 6. Security notes

- Passwords are never stored or hashed by this API; Supabase Auth handles credentials.
- The server verifies access tokens through `supabase.auth.getUser(token)`.
- Missing, malformed, invalid, or expired tokens return `401`.
- Missing signup/login fields return `400`.
- Successful signup returns `201`.
- Successful login/profile reads return `200`.
- Logout returns `204`.
- `.env` is ignored by Git.
- Only `.env.example` with placeholder values should be committed.

### Logout limitation

JWT access tokens are stateless. This implementation verifies the bearer token and returns `204`; the client must discard its access and refresh tokens. A previously issued access JWT may remain valid until expiry. If immediate server-side token revocation is required, use a server-side revocation/session strategy rather than pretending a stateless JWT has been instantly invalidated.

## 7. Required commits

Use one clean commit per stage:

```text
Stage 0: setup server and supabase client
Stage 1: signup and login routes working
Stage 2: public route and unverified protected route
Stage 3: profile route token verification
Stage 4: auth middleware and logout endpoint
Stage 5: Swagger UI documentation with bearer auth
Stage 6: publish to GitHub and write README
```

## 8. Submission checklist

- [ ] Server starts with `npm start`
- [ ] `.env` is git-ignored
- [ ] `.env.example` is committed
- [ ] Signup works with Supabase
- [ ] Login returns an access token
- [ ] Public route returns `200`
- [ ] Protected route rejects missing token with `401`
- [ ] Protected route verifies valid JWT
- [ ] Tampered token returns `401`
- [ ] Reusable middleware protects multiple routes
- [ ] Logout returns `204`
- [ ] Swagger `/docs` has bearer authorization
- [ ] Public GitHub repository
- [ ] At least 6 clean commits
- [ ] Swagger screenshot added to this README
