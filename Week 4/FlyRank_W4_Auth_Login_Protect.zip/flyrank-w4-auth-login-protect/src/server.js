const express = require("express");
const swaggerUi = require("swagger-ui-express");
const supabase = require("./supabase");
const requireAuth = require("./authMiddleware");

const app = express();
const PORT = Number(process.env.PORT || 3000);

app.use(express.json());

const openapi = {
  openapi: "3.0.3",
  info: {
    title: "FlyRank W4 Auth API",
    version: "1.0.0",
    description: "Secure authentication API using Supabase Auth and bearer JWT verification."
  },
  servers: [{ url: `http://localhost:${PORT}` }],
  components: {
    securitySchemes: {
      bearerAuth: {
        type: "http",
        scheme: "bearer",
        bearerFormat: "JWT"
      }
    },
    schemas: {
      Credentials: {
        type: "object",
        required: ["email", "password"],
        properties: {
          email: { type: "string", format: "email", example: "test@example.com" },
          password: { type: "string", format: "password", example: "password123" }
        }
      }
    }
  },
  paths: {
    "/auth/signup": {
      post: {
        summary: "Create a new user",
        requestBody: {
          required: true,
          content: { "application/json": { schema: { "$ref": "#/components/schemas/Credentials" } } }
        },
        responses: {
          "201": { description: "User created" },
          "400": { description: "Missing email or password" }
        }
      }
    },
    "/auth/login": {
      post: {
        summary: "Log in and receive JWT",
        requestBody: {
          required: true,
          content: { "application/json": { schema: { "$ref": "#/components/schemas/Credentials" } } }
        },
        responses: {
          "200": { description: "Login successful" },
          "400": { description: "Missing email or password" },
          "401": { description: "Invalid login credentials" }
        }
      }
    },
    "/auth/logout": {
      post: {
        summary: "End the authenticated client's session",
        security: [{ bearerAuth: [] }],
        responses: {
          "204": { description: "Logout accepted" },
          "401": { description: "Missing or invalid token" }
        }
      }
    },
    "/protected/profile": {
      get: {
        summary: "Read the authenticated user's profile",
        security: [{ bearerAuth: [] }],
        responses: {
          "200": { description: "User profile" },
          "401": { description: "Missing or invalid token" }
        }
      }
    },
    "/protected/dashboard": {
      get: {
        summary: "Example second protected route",
        security: [{ bearerAuth: [] }],
        responses: {
          "200": { description: "Protected dashboard" },
          "401": { description: "Missing or invalid token" }
        }
      }
    },
    "/public/info": {
      get: {
        summary: "Read public information",
        responses: {
          "200": { description: "Public information" }
        }
      }
    }
  }
};

app.get("/public/info", (req, res) => {
  res.status(200).json({
    message: "Welcome stranger! This info is public."
  });
});

app.post("/auth/signup", async (req, res) => {
  const { email, password } = req.body || {};

  if (!email || !password) {
    return res.status(400).json({ error: "Email and password are required" });
  }

  const { data, error } = await supabase.auth.signUp({ email, password });

  if (error) {
    return res.status(400).json({ error: error.message });
  }

  return res.status(201).json({ user: data.user });
});

app.post("/auth/login", async (req, res) => {
  const { email, password } = req.body || {};

  if (!email || !password) {
    return res.status(400).json({ error: "Email and password are required" });
  }

  const { data, error } = await supabase.auth.signInWithPassword({
    email,
    password
  });

  if (error || !data.session) {
    return res.status(401).json({ error: "Invalid login credentials" });
  }

  return res.status(200).json({
    access_token: data.session.access_token,
    refresh_token: data.session.refresh_token,
    user: data.user
  });
});

app.get("/protected/profile", requireAuth, (req, res) => {
  return res.status(200).json({
    id: req.user.id,
    email: req.user.email,
    created_at: req.user.created_at
  });
});

app.get("/protected/dashboard", requireAuth, (req, res) => {
  return res.status(200).json({
    message: "Welcome to the protected dashboard.",
    user_id: req.user.id
  });
});

app.post("/auth/logout", requireAuth, async (req, res) => {
  // JWT access tokens are stateless. We verify the token before accepting logout.
  // The client should discard its access/refresh tokens after receiving 204.
  return res.status(204).send();
});

app.get("/docs/openapi.json", (req, res) => {
  res.json(openapi);
});

app.use("/docs", swaggerUi.serve, swaggerUi.setup(openapi));

app.get("/", (req, res) => {
  res.json({
    name: "FlyRank W4 Auth API",
    docs: "/docs"
  });
});

app.use((err, req, res, next) => {
  console.error(err);
  res.status(500).json({ error: "Internal server error" });
});

app.listen(PORT, () => {
  console.log(`Server running and connected to Supabase on http://localhost:${PORT}`);
  console.log(`Swagger UI: http://localhost:${PORT}/docs`);
});
