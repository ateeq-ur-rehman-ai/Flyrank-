# FlyRank Week 4 — Empty but Live

A near-blank portfolio landing page prepared for the Week 4 build milestone.

## Local preview

Open `index.html` directly in a browser, or run:

```bash
python -m http.server 8000
```

Then visit `http://localhost:8000`.

## Deployment

This is a static site and can be deployed to GitHub Pages, Netlify, Cloudflare Pages, Vercel, or Render.

### GitHub Pages

1. Create a public GitHub repository.
2. Upload `index.html`.
3. Go to **Settings → Pages**.
4. Select the main branch and root folder.
5. Save and wait for the generated Pages URL.
6. Open that URL on your phone and capture a screenshot.

## Week 4 checklist

- [ ] Public repository created
- [ ] Static page deployed
- [ ] Live URL opened on a second device/phone
- [ ] Screenshot captured
- [ ] Identity kit added to Claude Project
- [ ] Case studies added to Claude Project
- [ ] Content map added to Claude Project
